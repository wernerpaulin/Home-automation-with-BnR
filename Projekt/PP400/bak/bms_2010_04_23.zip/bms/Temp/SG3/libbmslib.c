#include	<bur\plctypes.h>

_FUNDEF(DatObjUpdate);
_FUNDEF(IrrigValveMgr);
_FUNDEF(DayOfYear);
_FUNDEF(IsLeapYear);
_FUNDEF(Hyst2p);
_FUNDEF(GetTrendDatObjName);
_FUNDEF(DateOfDay);
