#include	<bur\plctypes.h>

void DatObjUpdate(void) {};
void _DatObjUpdate(void) {};
void IrrigValveMgr(void) {};
void _IrrigValveMgr(void) {};
void DayOfYear(void) {};
void _DayOfYear(void) {};
void IsLeapYear(void) {};
void _IsLeapYear(void) {};
void Hyst2p(void) {};
void _Hyst2p(void) {};
void GetTrendDatObjName(void) {};
void _GetTrendDatObjName(void) {};
void DateOfDay(void) {};
void _DateOfDay(void) {};
