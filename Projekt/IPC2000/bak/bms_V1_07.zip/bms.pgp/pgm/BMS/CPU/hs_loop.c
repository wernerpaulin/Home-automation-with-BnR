/*********************************************************************************************
*  Copyright: 2002 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Managment System                                                    *
*    Purpose    loop control of heating system                                               *
*                                                                                            *
*    Filename   hs_loop.c                                                                    *
*--------------------------------------------------------------------------------------------*
*  Description :                                                                             *
*    heating system loop controller                                                          *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  Structures  :                                                                             *
*   hsLoopInf_s                                                                              *
*             .actFeedTemp				 actual feed temperature after mixer                 *
*             .eStop                     starts emergency stop handling immediately          *
*             .cmdService                service interface for feed pipe pump                *
*             .lcHeatingInf         	                                                     *
*                        .enable         enable for loop controll of heating                 *
*                        .enableFiringLevel enable firing device if mixer opend enough       *
*                        .setTempOffset  offset to set temperature of heating characteristic *
*                        .lcParInf                                                           *
*                              .w        set value                                           *    
*                              .x        actual value                                        *
*                              .e        control deviation                                   *
*                              .eMax     max. control deviation for anti windup calculation  *
*                              .y        controller output value                             *
*                              .kp       proportional amplification                          *
*                              .ki       integral correction value                           *
*                              .tn       integral action time                                *
*                              .kd       differential amplification - not used               *
*                              .intPart  actual integral part                                *
*                              .diffPart differential part - not used                        *
*                              .loLimit  lower limit of int. part and controller output      *
*                              .hiLimit  upper limit of int. part and controller output      *
*                        .delayTime      actual delay time of heating circulation pump       *
*                        .delayTimeOut   delay timeout of heating circulation pump           *
*                        .minDutyCycle   minimum duty cycle within boiler pump must be       *
*                                        activated at least once                             *
*                        .offDutyTimer   counts as long as heating circulation pump is       *
*                                        switched off will be reseted as soon as pump is     * 
*                                        switched on                                         *
*                        .dutyRequest    request to switch on boiler pump                    *
*                        .antifreezeOverride override enable if outside temperature too low  *
*             .lcHotWaterInf    		                                                     *
*                        .enable         enable for loop controll of hot water management    *
*                        .setTemp        set temperature for hot water management            *
*             .lcMixerInf    		                                                         *
*                        .cmdHoming      signal to readjust 0% position                      *
*                        .setPosition    desired set postion in %                            *
*                        .oldSetPosition set position at start of movement in %              *
*                        .actPosition    actual postion                                      *
*                        .startPosition  start position before movement starts in %          *
*                        .dir            calculated time to reach desired set position       *
*                        .fullyOpenTime  time needed to open mixer completely                *
*                        .deadTime       time before mixer start real movement               *
*                        .posTimer       timer for position control of mixer                 *
*                        .setPosTime     calculated time to reach desired set position       *
*                        .cmdService     service interface for mixer                         *
*                        .servPosition   desired set postion in % if service mode is active  *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  History :                                                                                 *
*  Version       Datum         Autor                                                         *
*  01.00         16.03.02      W. Paulin     Created                                         *
*  01.01         19.10.02      W. Paulin     ECO functions implemented                       *
*  01.02         07.12.02      W. Paulin     RawTempIsValid() implemented                    *
*  01.03         28.12.02      W. Paulin     release of heating circulation pump impl.       *
*  01.04         31.12.02      W. Paulin     message if closed loop is active                *
*  01.05         19.01.03      W. Paulin     antifreezeOverride implemented                  *
*  01.06         25.12.03      W. Paulin     force homing of mixer every day                 *
*                                            new anti windup method for PI controller        *
*                                            continous PID input calculation                 *
*********************************************************************************************/

#include <bur/plctypes.h>
#include <bms_gn.h>
#include <bms_io.h>


_LOCAL RTInfo_typ 			fRTInfo;
_LOCAL UDINT	  			cycT;
_LOCAL UINT 				status;
_LOCAL dataObjInf_s			dataObjHsLoopInf;
_LOCAL dataObjInf_s 		dataObjOutFeedTemp;
_LOCAL dataObjInf_s 		dataObjLinFire;

_LOCAL DatObjCreate_typ  	fDatObjCreate;
_LOCAL DatObjDelete_typ  	fDatObjDelete;
_LOCAL DatObjWrite_typ		fDatObjWrite;
_LOCAL DatObjInfo_typ		fDatObjInfo;

_LOCAL USINT 				newMinute;
_LOCAL USINT 				oldMinute;

_LOCAL UDINT				cntHoming;

_LOCAL USINT				heatingCirculationPumpRelease;


_INIT void hs_loopini(void)
{
 fRTInfo.enable = 1; 
 RTInfo(&fRTInfo);
 
 cycT = fRTInfo.cycle_time / 1000;					/* transform cycle time us -> ms */

#if 0 
#warning: It is not necessary to store HsLoopInf_s all current parameters will be set during runtime 
 /* get current heating loop control parameter or create new one if neccessary */
 do
 {
  status = NewDataObject( &fDatObjCreate, &fDatObjDelete, HS_LOOP_INFO_DO_NAME, doUSRROM, 0, &HsLoopInf, sizeof(HsLoopInf), &dataObjHsLoopInf);
 } while (status == ERR_FUB_BUSY);
 if (status != ERR_OK) VisuInterface.heatingAlarm[HEATING_HS_LOOP_DO_ERROR] = 1;
#endif
 
 /* get chart of feed temperature according to outside temperature /Begin */
 fDatObjInfo.enable = 1;
 fDatObjInfo.pName = (UDINT)CHART_OUTSIDE_FEED_TEMP_DO_NAME;
 
 DatObjInfo(&fDatObjInfo);										/* get schedule */
 
 if (fDatObjInfo.status == ERR_OK)								/* error ? */
   {
    dataObjOutFeedTemp.pData     = fDatObjInfo.pDatObjMem;		/* pointer to chart */
    dataObjOutFeedTemp.doIdent   = fDatObjInfo.ident;			/* ident of data object containing chart */
    dataObjOutFeedTemp.doLength  = fDatObjInfo.len;				/* length of data in data object */
    dataObjOutFeedTemp.doMemType = fDatObjInfo.MemType;			/* memory of data object containing chart */
    dataObjOutFeedTemp.doOption  = fDatObjInfo.Option;			/* additional options of data object containing chart */
   }
 else
   {
    memset( &dataObjOutFeedTemp, 0, sizeof(dataObjOutFeedTemp) );
    VisuInterface.heatingAlarm[HEATING_OUTSIDE_FEED_DO_ERROR] = 1;
   }
 /* get chart of feed temperature according to outside temperature /End */


 /* get chart for linarisation of temperature sensors firing device, boiler and feed temperature /Begin */
 fDatObjInfo.enable = 1;
 fDatObjInfo.pName = (UDINT)CHART_LINEAR_FIRING_TEMP_DO_NAME;
 
 DatObjInfo(&fDatObjInfo);										/* get schedule */
 
 if (fDatObjInfo.status == ERR_OK)								/* error ? */
   {
    dataObjLinFire.pData     = fDatObjInfo.pDatObjMem;			/* pointer to chart */
    dataObjLinFire.doIdent   = fDatObjInfo.ident;				/* ident of data object containing chart */
    dataObjLinFire.doLength  = fDatObjInfo.len;					/* length of data in data object */
    dataObjLinFire.doMemType = fDatObjInfo.MemType;				/* memory of data object containing chart */
    dataObjLinFire.doOption  = fDatObjInfo.Option;				/* additional options of data object containing chart */
   }
 else
   {
    memset( &dataObjLinFire, 0, sizeof(dataObjLinFire) );
    VisuInterface.heatingAlarm[HEATING_LIN_FIRE_DO_ERROR] = 1;
   }
 /* get chart for linarisation of temperature sensors firing device, boiler and feed temperature /End */

 HsLoopInf.cmdService           = SERVICE_MODE_OFF;
 HsLoopInf.lcHotWaterInf.enable = 0;

 HsLoopInf.lcHeatingInf.enable           = 0;
 HsLoopInf.lcHeatingInf.lcParInf.eMax    = HS_HEATING_MIXER_LC_PAR_E_MAX;
 HsLoopInf.lcHeatingInf.lcParInf.kp 	 = HS_HEATING_MIXER_LC_PAR_KP;
 HsLoopInf.lcHeatingInf.lcParInf.tn 	 = HS_HEATING_MIXER_LC_PAR_TN;	
 HsLoopInf.lcHeatingInf.lcParInf.ki      = 0; /* will be calculated at runtime */
 HsLoopInf.lcHeatingInf.lcParInf.loLimit = HS_HEATING_MIXER_LC_PAR_LOW_LIMIT;
 HsLoopInf.lcHeatingInf.lcParInf.hiLimit = HS_HEATING_MIXER_LC_PAR_HIGH_LIMIT;
 HsLoopInf.lcHeatingInf.delayTimeOut     = HS_HEATING_CIRCULATION_PUMP_DELAY_TIME;
 HsLoopInf.lcHeatingInf.minDutyCycle     = HS_HEATING_CIRCULATION_PUMP_MIN_DUTY_CYCLE;
 HsLoopInf.lcHeatingInf.enableFiringLevel = ENABLE_FIRING_LEVEL;

 
 HsLoopInf.lcMixerInf.fullyOpenTime      = HS_HEATING_MIXER_FULLY_OPEN_TIME;
 HsLoopInf.lcMixerInf.deadTime           = HS_MIXER_DEAD_TIME_OFFSET;
 HsLoopInf.lcMixerInf.cmdHoming          = HS_MIXER_DO_HOMING;						/* start homing after power up to get correct actual position */
 HsLoopInf.lcMixerInf.cmdService         = SERVICE_MODE_OFF;
}

_CYCLIC void hs_loopcyc(void)
{
 /* generate new minute flag */
 getTimeFlags(&CurrentTime, 0, 0, &newMinute, &oldMinute, 0, 0);

 /* convert meassured resistance to linear temperature */
 if ( RawTempIsValid(iActFeedTemp) )
   {
    if (dataObjLinFire.pData)
      {
       HsLoopInf.actFeedTemp = getChartValueY( 1 / (1/((REAL)iActFeedTemp/10) - 1/(REAL)FEED_PARALLEL_RESISTANCE), 
                                                (xyChartElement_s *)dataObjLinFire.pData, 
                                                dataObjLinFire.doLength / sizeof(xyChartElement_s) );
      }
    else
      {
       /* if no chart found -> use linear default formular */
       HsLoopInf.actFeedTemp = calcY( 1 / (1/((REAL)iActFeedTemp/10) - 1/(REAL)FEED_PARALLEL_RESISTANCE), 
                                       HS_LIN_FIRE_TEMP_DEF_K, 
                                       HS_LIN_FIRE_TEMP_DEF_D );
      }
   }

 /***********************************************************************************************************************/
 /*** HEATING CONTROL                                                                                                 ***/
 /***********************************************************************************************************************/
 /* protect heating circuit for damage caused by freezing heating water if outside temperature is too low */
 if ( 
      ((HsMgrInf.outsideTemp            <= HS_HEATING_CRITICAL_FREEZING_OUTSIDE_TEMPERATURE)     &&
       (HsLoopInf.actFeedTemp           <= HS_HEATING_CRITICAL_FREEZING_FEED_TEMPERATURE))       ||
       (HsEcoInf.livingRoomTemp.actTemp <= HS_HEATING_CRITICAL_FREEZING_LIVING_ROOM_TEMPERATURE)
    )
   {
    HsLoopInf.lcHeatingInf.antifreezeOverride = 1;
    VisuInterface.heatingAlarm[HEATING_ANTI_FREEZE_OVERRIDE_ACTIVE] = 1;
   }
 else
   {
    HsLoopInf.lcHeatingInf.antifreezeOverride = 0;
    VisuInterface.heatingAlarm[HEATING_ANTI_FREEZE_OVERRIDE_ACTIVE] = 0;
   }


 /* get required feed temperature according to outside temperature */
 if (dataObjOutFeedTemp.pData)
   {
    /* use average temperature if eco option enables */
    if ( (HsEcoInf.outsideTemp.enable) && (HsMgrInf.activeHeatingMode == HEATING_MODE_AUTO) )
      {
       HsLoopInf.lcHeatingInf.lcParInf.w = getChartValueY( HsEcoInf.outsideTemp.movAvTemp, 	/* average outside temperature */
                                                           (xyChartElement_s *)dataObjOutFeedTemp.pData, 
                                                           dataObjOutFeedTemp.doLength / sizeof(xyChartElement_s) );
      }
    else
      {
       HsLoopInf.lcHeatingInf.lcParInf.w = getChartValueY( HsMgrInf.outsideTemp, 			/* real outside temperature */
                                                           (xyChartElement_s *)dataObjOutFeedTemp.pData, 
                                                           dataObjOutFeedTemp.doLength / sizeof(xyChartElement_s) );
      }
   }
 else
   {
    /* use average temperature if eco option enables */
    if ( (HsEcoInf.outsideTemp.enable) && (HsMgrInf.activeHeatingMode == HEATING_MODE_AUTO) )
      {
       /* if no chart found -> use linear default formular */
       HsLoopInf.lcHeatingInf.lcParInf.w = calcY( HsEcoInf.outsideTemp.movAvTemp, HS_OUTSIDE_FEED_TEMP_DEF_K, HS_OUTSIDE_FEED_TEMP_DEF_D );
      }
    else
      {
       /* if no chart found -> use linear default formular */
       HsLoopInf.lcHeatingInf.lcParInf.w = calcY( HsMgrInf.outsideTemp, HS_OUTSIDE_FEED_TEMP_DEF_K, HS_OUTSIDE_FEED_TEMP_DEF_D );
      }
   }
  
 /* adjust feed temperature with offset given by day/night and user */
 HsLoopInf.lcHeatingInf.lcParInf.w += HsLoopInf.lcHeatingInf.setTempOffset;
   
 /* get actual value of feed temperature */
 HsLoopInf.lcHeatingInf.lcParInf.x  = HsLoopInf.actFeedTemp;

 /* calculate control deviation only for visualization and trending */
 HsLoopInf.lcHeatingInf.lcParInf.e = HsLoopInf.lcHeatingInf.lcParInf.w - HsLoopInf.lcHeatingInf.lcParInf.x;

 /* convert integral action time in integral amplification, according cycle time of controller */
 if (HsLoopInf.lcHeatingInf.lcParInf.tn == 0)
   {
    HsLoopInf.lcHeatingInf.lcParInf.ki      = 0;
    HsLoopInf.lcHeatingInf.lcParInf.intPart = 0;
   }
 else
   {
    HsLoopInf.lcHeatingInf.lcParInf.ki = 1 / (HsLoopInf.lcHeatingInf.lcParInf.tn * 1000 / cycT); 
   }


 /* start heating according to enable from HsMgr and if eco function of livingroom temperature is enabled if release is given */
 if (
     ((   HsLoopInf.lcHeatingInf.enable  == 1) && 
      ( ((HsEcoInf.livingRoomTemp.enable == 1) && (HsMgrInf.activeHeatingMode == HEATING_MODE_AUTO)) ? (HsEcoInf.livingRoomTemp.release) : (1) ) &&
      ( ((HsEcoInf.noon.enable           == 1) && (HsMgrInf.activeHeatingMode == HEATING_MODE_AUTO)) ? (HsEcoInf.noon.release)           : (1) ) &&
      ( ((HsEcoInf.firing.enable         == 1) && (HsMgrInf.activeHeatingMode == HEATING_MODE_AUTO)) ? (HsEcoInf.firing.release)         : (1) ))
     ||
     (HsLoopInf.lcHeatingInf.antifreezeOverride == 1)
    )
   {
    /* closed loop controller /Begin */
    lcPI( HsLoopInf.lcHeatingInf.lcParInf.w, 					/* set value                              */
          HsLoopInf.lcHeatingInf.lcParInf.x,					/* actual value                           */
         &HsLoopInf.lcHeatingInf.lcParInf.e, 					/* control deviation                      */
          HsLoopInf.lcHeatingInf.lcParInf.eMax,					/* max. control deviation for anti windup */
         &HsLoopInf.lcHeatingInf.lcParInf.y, 					/* controller output                      */
          HsLoopInf.lcHeatingInf.lcParInf.kp, 					/* propotional amplification              */
          HsLoopInf.lcHeatingInf.lcParInf.ki,					/* integral amplification                 */
         &HsLoopInf.lcHeatingInf.lcParInf.intPart, 				/* actual integral part                   */
          HsLoopInf.lcHeatingInf.lcParInf.loLimit, 				/* lower limit for output                 */
          HsLoopInf.lcHeatingInf.lcParInf.hiLimit );            /* higher limit for output                */
    /* closed loop controller /End */
    
    /* enable firing device if necessary (feed temperature is not hot enough anymore) */
    if (HsLoopInf.lcHeatingInf.lcParInf.y >= HsLoopInf.lcHeatingInf.enableFiringLevel)
      {
       /* start firing device only if not hot enough */
       if ( (HsFireInf.firingInf.actTemp - HsLoopInf.actFeedTemp) < HS_FIRING_MIN_DELTA_TEMP )
         {
          HsFireInf.firingInf.enable  = 1;
         }

       /* make sure in case of firing request, that set temperature is higher than requested temperature -> otherwise no heating effect */
       HsFireInf.firingInf.setTemp = HsLoopInf.lcHeatingInf.lcParInf.w + HS_FIRING_MIN_DELTA_TEMP;		/* necessary temperature */
      }
    else
      {
       HsFireInf.firingInf.enable = 0;
      }      

    heatingCirculationPumpRelease = 1;
    VisuInterface.messageAlarm[HEATING_HEATING_ON] = 1;
   }
 else
   {
    HsFireInf.firingInf.enable    = 0;
    heatingCirculationPumpRelease = 0;
    VisuInterface.messageAlarm[HEATING_HEATING_ON] = 0;
   }
     
 /* show set temperature only if controller is enabled */
 if ( (HsFireInf.firingInf.enable == 1) || (HsFireInf.boilerInf.enable == 1) )
   VisuInterface.hsFiringSetValueStatus = VisuInterface.hsFiringSetValueStatus & VC_ELEMENT_VISIBLE;
 else
   VisuInterface.hsFiringSetValueStatus = VisuInterface.hsFiringSetValueStatus | VC_ELEMENT_INVISIBLE;
   
   
   
 /***********************************************************************************************************************/
 /*** HOT WATER CONTROL                                                                                                 ***/
 /***********************************************************************************************************************/
 HsFireInf.boilerInf.setTemp = HsLoopInf.lcHotWaterInf.setTemp;
 if (HsLoopInf.lcHotWaterInf.enable)
   HsFireInf.boilerInf.enable  = 1;
 else
   HsFireInf.boilerInf.enable  = 0;
 
 /* show set temperature only if controller is enabled */
 if (HsFireInf.boilerInf.enable == 1)
   VisuInterface.hsBoilerSetValueStatus = VisuInterface.hsBoilerSetValueStatus & VC_ELEMENT_VISIBLE;
 else
   VisuInterface.hsBoilerSetValueStatus = VisuInterface.hsBoilerSetValueStatus | VC_ELEMENT_INVISIBLE;
 
 
 
 /***********************************************************************************************************************/
 /*** MIXER CONTROL                                                                                                   ***/
 /***********************************************************************************************************************/
 /* open mixer only if actual temperature of firing device is at least feed temperature or higher to allow faster heating up of firing device */
 if ( (HsLoopInf.lcHeatingInf.enable || HsLoopInf.lcHeatingInf.antifreezeOverride) && 
      (HsFireInf.firingInf.actTemp >= HsLoopInf.actFeedTemp) )
   {
    /* get new set postion for mixer according to controller output */
    HsLoopInf.lcMixerInf.setPosition = (USINT)HsLoopInf.lcHeatingInf.lcParInf.y;
   }
 else
   {
    HsLoopInf.lcMixerInf.setPosition = 0;					/* close mixer if heating controller is disabled */
   }

 /* force homing of mixer every day at 0:00am o'clock midnight */
 if ( (CurrentTime.hour               ==  0) &&
      (CurrentTime.minute             ==  0) &&
      (CurrentTime.second             ==  0) &&
      (HsLoopInf.lcMixerInf.cmdHoming == HS_MIXER_HOMING_DONE) )
    {
     HsLoopInf.lcMixerInf.cmdHoming = HS_MIXER_DO_HOMING;
     cntHoming++;
    }

 /***********************************************************************************************************************/
 /*** SERVICE OPERATION - MIXER                                                                                       ***/
 /***********************************************************************************************************************/
 /* evaluate service command given by user */
 applyUserInput( &VisuInterface.hsMixerModeSelect, 
                  MAX_SERVICE_MODES, 
                  SERVICE_MODE_OFF,
                 &VisuInterface.hsMixerModeTimer, 
                  USER_INPUT_APPLY_DELAY, 
                 &VisuInterface.hsNewMixerMode, 
                 &HsLoopInf.lcMixerInf.cmdService, 
                  0,
                  cycT );


 /* overide target postion in case of service mode */
 if (HsLoopInf.lcMixerInf.cmdService == SERVICE_MODE_SWITCH_ON)
   {
    HsLoopInf.lcMixerInf.setPosition = HsLoopInf.lcMixerInf.servPosition;
   }
 else if (HsLoopInf.lcMixerInf.cmdService == SERVICE_MODE_SWITCH_OFF)
   {
    HsLoopInf.lcMixerInf.setPosition = 0;							/* close mixer by service operation */
   }

 /* status of homing procedure to keep button on visu pressed */
 if (HsLoopInf.lcMixerInf.cmdHoming == HS_MIXER_HOMING_DONE)
   {
    VisuInterface.mixerHomingStatus = 0;
   }
 else
   {
    VisuInterface.mixerHomingStatus = 1;
   } 
 
 /* control mixer according commands or set values */
 mixerControl( &HsLoopInf.lcMixerInf.cmdHoming, 
                HsLoopInf.lcMixerInf.setPosition, 
               &HsLoopInf.lcMixerInf.oldSetPosition, 
               &HsLoopInf.lcMixerInf.actPosition, 
               &HsLoopInf.lcMixerInf.startPosition, 
                HsLoopInf.lcMixerInf.fullyOpenTime, 
                HsLoopInf.lcMixerInf.deadTime, 
               &HsLoopInf.lcMixerInf.posTimer, 
               &HsLoopInf.lcMixerInf.setPosTime, 
               &HsLoopInf.lcMixerInf.dir,
                cycT );

 /* connected mixer control output with hardware /Begin */
 if (HsLoopInf.lcMixerInf.dir == HS_MIXER_OPEN)
   {
    oMixerClose = HS_SWITCH_OFF;
    oMixerOpen  = HS_SWITCH_ON;
   }
 else if (HsLoopInf.lcMixerInf.dir == HS_MIXER_CLOSE)
   {
    oMixerClose = HS_SWITCH_ON;
    oMixerOpen  = HS_SWITCH_OFF;
   }
 else
   {
    oMixerClose = HS_SWITCH_OFF;
    oMixerOpen  = HS_SWITCH_OFF;
   }
 /* connected mixer control output with hardware /Begin */

 
 
 /***********************************************************************************************************************/
 /*** HEATING CIRCULATION PUMP CONTROL                                                                                ***/
 /***********************************************************************************************************************/
 /* switch heating circulation pump on if heating controller is enabled and released or if pump was not running since some time */
 /* make sure that pump is always on if outside temperature is below critical temperature to freeze heating circuit */
 if ( 
      ((HsLoopInf.lcHeatingInf.enable || HsLoopInf.lcHeatingInf.antifreezeOverride) && (heatingCirculationPumpRelease)) || 
      (HsLoopInf.lcHeatingInf.dutyRequest) ||
      (HsMgrInf.outsideTemp <= HS_HEATING_CRITICAL_FREEZING_OUTSIDE_TEMPERATURE)
    )
   {
    oHeatingCirculationPump 		   = HS_SWITCH_ON;
    HsLoopInf.lcHeatingInf.delayTime   = 0;
    HsLoopInf.lcHeatingInf.dutyRequest = 0;
   }

 /* switch boiler heating circulation off after certain delay time */
 if (HsLoopInf.lcHeatingInf.delayTime >= HsLoopInf.lcHeatingInf.delayTimeOut) 
   oHeatingCirculationPump = HS_SWITCH_OFF;
 else
   HsLoopInf.lcHeatingInf.delayTime += newMinute; 


 /* take care that heating circulation pump is running frequently /Begin */
 if (oHeatingCirculationPump == HS_SWITCH_ON)
   HsLoopInf.lcHeatingInf.offDutyTimer = 0;
 else
   HsLoopInf.lcHeatingInf.offDutyTimer += newMinute;
 
 if (HsLoopInf.lcHeatingInf.offDutyTimer >= HsLoopInf.lcHeatingInf.minDutyCycle)
   HsLoopInf.lcHeatingInf.dutyRequest = 1;
 /* take care that heating circulationis running frequently /End */


 /* generate warning message for visualization /Begin */
 if (HsLoopInf.lcHeatingInf.dutyRequest)
   VisuInterface.messageAlarm[HEATING_CIRCULATION_PUMP_DUTY_REQUEST] = 1;
 else if (oHeatingCirculationPump == 0)
   VisuInterface.messageAlarm[HEATING_CIRCULATION_PUMP_DUTY_REQUEST] = 0;
 /* generate warning message for visualization /End */


 /***********************************************************************************************************************/
 /*** SERVICE OPERATION - HEATING CIRCULATION PUMP                                                                    ***/
 /***********************************************************************************************************************/
 /* evaluate service command given by user */
 applyUserInput( &VisuInterface.hsCircPumpModeSelect, 
                  MAX_SERVICE_MODES, 
                  SERVICE_MODE_OFF,
                 &VisuInterface.hsCircPumpModeTimer, 
                  USER_INPUT_APPLY_DELAY, 
                 &VisuInterface.hsNewCircPumpMode, 
                 &HsLoopInf.cmdService,
                  0, 
                  cycT );
 
 if (HsLoopInf.cmdService == SERVICE_MODE_SWITCH_ON)
   oHeatingCirculationPump = HS_SWITCH_ON;
 else if (HsLoopInf.cmdService == SERVICE_MODE_SWITCH_OFF)
   oHeatingCirculationPump = HS_SWITCH_OFF;


 
 /***********************************************************************************************************************/
 /*** ALARM GENERATION                                                                                                ***/
 /***********************************************************************************************************************/
 if ( (RawTempIsValid(iActFeedTemp) == 0) && (VisuInterface.heatingAlarm[HEATING_NO_CONNECTION_CANIO] == 0) )
   VisuInterface.heatingAlarm[HEATING_FLOW_PIPE_TEMPERATUR_SENSOR_BROKEN] = 1;
 else
   VisuInterface.heatingAlarm[HEATING_FLOW_PIPE_TEMPERATUR_SENSOR_BROKEN] = 0;

 
 
 /***********************************************************************************************************************/
 /*** STATISTICS                                                                                                      ***/
 /***********************************************************************************************************************/
 if ( (oHeatingCirculationPump == 1) && (newMinute == 1) )	
   BMSstatistic.heatingStatistic.onTimeHeatingCirculationPump++;			/* statistics: on time of heating circulation pump */


        

#if 0 
#warning: It is not necessary to store HsLoopInf_s all current parameters will be set during runtime 
 /***********************************************************************************************************************/
 /*** SAVE DATA                                                                                                       ***/
 /***********************************************************************************************************************/
 /* save info structure every minute /Begin */
 if (newMinute == 1)
   {
    fDatObjWrite.enable  = 1;
    fDatObjWrite.ident   = dataObjHsLoopInf.doIdent;
    fDatObjWrite.Offset  = 0;
    fDatObjWrite.pSource = (UDINT)&HsLoopInf;
    fDatObjWrite.len     = sizeof(HsLoopInf);
    
    DatObjWrite(&fDatObjWrite);
    
    if (fDatObjWrite.status != ERR_OK)
      {
       dataObjHsLoopInf.nbWrErr++;
       dataObjHsLoopInf.lstWrErr = fDatObjWrite.status;
       VisuInterface.heatingAlarm[HEATING_HS_LOOP_DO_ERROR] = 1;
       ERRxwarning(fDatObjWrite.status, 0, "write HsLoopInf");
      }
   }
 /* save info structure every minute /End */
#endif
 
 /***********************************************************************************************************************/
 /*** EMERGENCY STOP HANDLING (overrides everything!)                                                                 ***/
 /***********************************************************************************************************************/
 if (HsLoopInf.eStop)
   {
    oHeatingCirculationPump = HS_SWITCH_OFF;
    oMixerOpen              = HS_SWITCH_OFF;
    oMixerClose             = HS_SWITCH_OFF;
   }
}

