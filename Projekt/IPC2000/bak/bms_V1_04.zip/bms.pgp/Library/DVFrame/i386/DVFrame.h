/* Automation Studio Generated Header File, Format Version 1.00 */
/* do not change */
#ifndef DVFRAME_H_
#define DVFRAME_H_
#define _WEAK	__attribute__((__weak__))

#include <bur/plc.h>



/* Constants */
_WEAK const unsigned long ARG_BAUD = 0;
_WEAK const unsigned long ARG_EVSEND_TASKEVENT = 18;
_WEAK const unsigned long ARG_EVSEND_TASKIDENT = 14;
_WEAK const unsigned long ARG_MISC = 16;
_WEAK const unsigned long ARG_PVPOLLADR = 15;
_WEAK const unsigned long ARG_TXPVPOLLADR = 17;
_WEAK const unsigned long MISC_RECEIVE_ALL = 2;
_WEAK const unsigned short frmERR_DEVICEDESCRIPTION = 8252;
_WEAK const unsigned short frmERR_FUB_ENABLE_FALSE = 65534;
_WEAK const unsigned short frmERR_INPUTERROR = 8079;
_WEAK const unsigned short frmERR_INVALIDBUFFER = 8072;
_WEAK const unsigned short frmERR_IOCTL_NOTSUPPORTED = 8257;
_WEAK const unsigned short frmERR_IOCTL_NOTVALID = 8073;
_WEAK const unsigned short frmERR_MAXOPEN = 8254;
_WEAK const unsigned short frmERR_MODEDESCRIPTION = 8253;
_WEAK const unsigned short frmERR_NOBUFFER = 8071;
_WEAK const unsigned short frmERR_NOINPUT = 60;
_WEAK const unsigned short frmERR_NORESOURCES = 8258;
_WEAK const unsigned short frmERR_NOTOPENED = 8251;
_WEAK const unsigned short frmERR_OK = 0;
_WEAK const unsigned short frmERR_PA_DB_SB = 8256;
_WEAK const unsigned short frmERR_TRANSMITOVERRUN = 8078;


/* Datatypes */
typedef struct XOPENCONFIG
{
	unsigned short idle;
	unsigned short delimc;
	unsigned char delim[2];
	unsigned short tx_cnt;
	unsigned short rx_cnt;
	unsigned short tx_len;
	unsigned short rx_len;
	unsigned short argc;
	unsigned long argv;
} XOPENCONFIG;



/* Datatypes of function blocks */
typedef struct FRM_xopen
{
	/* VAR_INPUT (analogous) */
	unsigned long device;
	unsigned long mode;
	unsigned long config;
	/* VAR_OUTPUT (analogous) */
	unsigned short status;
	unsigned long ident;
	/* VAR (analogous) */
	plcstring internal[27+1];
	/* VAR_INPUT (digital) */
	plcbit enable;
} FRM_xopen_typ;

typedef struct FRM_read
{
	/* VAR_INPUT (analogous) */
	unsigned long ident;
	/* VAR_OUTPUT (analogous) */
	unsigned short status;
	unsigned long buffer;
	unsigned short buflng;
	/* VAR (analogous) */
	plcstring internal[27+1];
	/* VAR_INPUT (digital) */
	plcbit enable;
} FRM_read_typ;

typedef struct FRM_write
{
	/* VAR_INPUT (analogous) */
	unsigned long ident;
	unsigned long buffer;
	unsigned short buflng;
	/* VAR_OUTPUT (analogous) */
	unsigned short status;
	/* VAR (analogous) */
	plcstring internal[27+1];
	/* VAR_INPUT (digital) */
	plcbit enable;
} FRM_write_typ;

typedef struct FRM_close
{
	/* VAR_INPUT (analogous) */
	unsigned long ident;
	/* VAR_OUTPUT (analogous) */
	unsigned short status;
	/* VAR (analogous) */
	plcstring internal[27+1];
	/* VAR_INPUT (digital) */
	plcbit enable;
} FRM_close_typ;

typedef struct FRM_rbuf
{
	/* VAR_INPUT (analogous) */
	unsigned long ident;
	unsigned long buffer;
	unsigned short buflng;
	/* VAR_OUTPUT (analogous) */
	unsigned short status;
	/* VAR (analogous) */
	plcstring internal[27+1];
	/* VAR_INPUT (digital) */
	plcbit enable;
} FRM_rbuf_typ;

typedef struct FRM_gbuf
{
	/* VAR_INPUT (analogous) */
	unsigned long ident;
	/* VAR_OUTPUT (analogous) */
	unsigned short status;
	unsigned long buffer;
	unsigned short buflng;
	/* VAR (analogous) */
	plcstring internal[27+1];
	/* VAR_INPUT (digital) */
	plcbit enable;
} FRM_gbuf_typ;

typedef struct FRM_robuf
{
	/* VAR_INPUT (analogous) */
	unsigned long ident;
	unsigned long buffer;
	unsigned short buflng;
	/* VAR_OUTPUT (analogous) */
	unsigned short status;
	/* VAR (analogous) */
	plcstring internal[27+1];
	/* VAR_INPUT (digital) */
	plcbit enable;
} FRM_robuf_typ;

typedef struct FRM_ctrl
{
	/* VAR_INPUT (analogous) */
	unsigned long ident;
	unsigned short ioctrl;
	unsigned long inarg;
	/* VAR_OUTPUT (analogous) */
	unsigned short status;
	unsigned long outarg;
	/* VAR (analogous) */
	plcstring internal[43+1];
	/* VAR_INPUT (digital) */
	plcbit enable;
} FRM_ctrl_typ;

typedef struct FRM_mode
{
	/* VAR_INPUT (analogous) */
	unsigned long ident;
	unsigned long mode;
	/* VAR_OUTPUT (analogous) */
	unsigned short status;
	/* VAR (analogous) */
	plcstring internal[27+1];
	/* VAR_INPUT (digital) */
	plcbit enable;
} FRM_mode_typ;



/* Prototyping of functions and function blocks */
void FRM_xopen(FRM_xopen_typ* inst);
void FRM_read(FRM_read_typ* inst);
void FRM_write(FRM_write_typ* inst);
void FRM_close(FRM_close_typ* inst);
void FRM_rbuf(FRM_rbuf_typ* inst);
void FRM_gbuf(FRM_gbuf_typ* inst);
void FRM_robuf(FRM_robuf_typ* inst);
void FRM_ctrl(FRM_ctrl_typ* inst);
void FRM_mode(FRM_mode_typ* inst);



#endif /* DVFRAME_H_ */