/*********************************************************************************************
*  Copyright: 2005 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Management System Auxiliary Library                                 *
*    Purpose    general include file                                                         *
*                                                                                            *
*    Filename   bms_aux_gn.h                                                                 *
*********************************************************************************************/

#ifndef _BMS_AUX_GN_H_
#define _BMS_AUX_GN_H_

#include <bur/plctypes.h>
#include <astime.h>
#include <bms_aux.h>


#endif