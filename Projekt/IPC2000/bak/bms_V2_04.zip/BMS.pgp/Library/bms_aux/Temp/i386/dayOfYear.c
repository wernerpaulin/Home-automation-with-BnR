#include	<bur\plc.h>

void dayOfYear(void) {};
