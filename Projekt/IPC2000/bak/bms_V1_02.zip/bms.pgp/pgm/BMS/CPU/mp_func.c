/*********************************************************************************************
*  Copyright: 2001 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Managment System                                                    *
*    Purpose    additional functions for general BMS purpose                                 *
*                                                                                            *
*    Filename   mp_func.c                                                                    *
*********************************************************************************************/

#include <bur/plctypes.h>
#include <bms_gn.h>

/****************************************************************************
**********                    	getTimeFlags()                     **********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     generates time flags: newHour, newMinute, newSecond                   *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       pCurrentTime : pointer to current time                              *
*       pOldHour     : pointer to old hour flag                             *
*       pOldMinute   : pointer to old minute flag                           *
*       pOldSecond   : pointer to old second flag                           *
*                                                                           *
*    Output:                                                                *
*       pNewHour     : pointer to new hour flag                             *
*       pNewMinute   : pointer to new minute flag                           *
*       pNewSecond   : pointer to new second flag                           *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       06.07.01    W. Paulin     created 							*
****************************************************************************/
void getTimeFlags(DTStructure *pCurrentTime, USINT *pNewHour, USINT *pOldHour, USINT *pNewMinute, USINT *pOldMinute, USINT *pNewSecond, USINT *pOldSecond)
{
 if (!pCurrentTime) return;
 
 if ((pNewHour) && (pOldHour))
   {
    /* generate flag indication - new hour /Begin */
    if (pCurrentTime->hour != *pOldHour)
      {
       *pNewHour = 1;
       *pOldHour= pCurrentTime->hour;
      }
    else
      *pNewHour = 0;
    /* generate flag indication - new hour /End */
   }

 if ((pNewMinute) && (pOldMinute))
   {
    /* generate flag indication - new minute /Begin */
    if (pCurrentTime->minute != *pOldMinute)
      {
       *pNewMinute = 1;
       *pOldMinute = pCurrentTime->minute;
      }
    else
      *pNewMinute = 0;
    /* generate flag indication - new minute /End */
   }


 if ((pNewSecond) && (pOldSecond))
   {
    /* generate flag indication - new second /Begin */
    if (pCurrentTime->second != *pOldSecond)
      {
       *pNewSecond = 1;
       *pOldSecond = pCurrentTime->second;
      }
    else
      *pNewSecond = 0;
    /* generate flag indication - new second /End */
   }
}


/****************************************************************************
**********               	 	DateWithinBeginEnd()   	           **********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     Checks if current date is with begin end range.                       *
*     Calculation is done in months and days.                               *
*     new year is taken in consideration                                    *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       pBegin	     : pointer to date and time stamp of begin              *
*       pEnd	     : pointer to date and time stamp of end                *
*       pCurrentTime : pointer to current time                              *
*                                                                           *
*    Output:                                                                *
*       return value : in range or not in range                             *
*                      0 ...not in range                                    *
*                      1 ...in range                                        *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       10.07.01    W. Paulin     created 							*
****************************************************************************/
UINT DateWithinBeginEnd(DTStructure *pBegin, DTStructure *pEnd, DTStructure *pCurrentTime)
{
 USINT timeSpanWithinOneYear = 0;

 /* two possibilities: */
 if ( (pEnd->month > pBegin->month) || ((pEnd->month == pBegin->month) && (pEnd->day >= pBegin->day)) )
   timeSpanWithinOneYear = 1;		/* 1.) Begin is earlier than End (only month and date) -> time span is within one year */
 else
   timeSpanWithinOneYear = 0;		/* 2.) Begin is after end (regarding month and date) -> time span is over new year */
 
 if (timeSpanWithinOneYear)
   {
    if (pCurrentTime->month < pBegin->month) 
      return(DATE_OUT_OF_RANGE);
    else if ( (pCurrentTime->month == pBegin->month) && (pCurrentTime->day < pBegin->day) ) /* same month but day not yet reached */
      return(DATE_OUT_OF_RANGE);


    if (pCurrentTime->month > pEnd->month)
      return(DATE_OUT_OF_RANGE);
    else if ( (pCurrentTime->month == pEnd->month) && (pCurrentTime->day > pEnd->day) ) 	/* same month but day already passed */
      return(DATE_OUT_OF_RANGE);
   }
 else
   {
    if ( (pCurrentTime->month < pBegin->month) && (pCurrentTime->month > pEnd->month) )
      return(DATE_OUT_OF_RANGE);
    else if ( (pCurrentTime->month == pBegin->month) && (pCurrentTime->day < pBegin->day) ) /* same month but day not yet reached */
      return(DATE_OUT_OF_RANGE);
    else if ( (pCurrentTime->month == pEnd->month) && (pCurrentTime->day > pEnd->day) ) 	/* same month but day already passed */
      return(DATE_OUT_OF_RANGE);
   }
 
 return(DATE_IN_RANGE);
}


/****************************************************************************
**********               	 	DateIsValid()   	 	           **********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     Checks if given date is valid                                         *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       pBegin	     : pointer to date stamp of begin                       *
*       pEnd	     : pointer to date stamp of end                         *
*                                                                           *
*    Output:                                                                *
*       return value : in range or not in range                             *
*                      0 ...DATE_INVALID                                    *
*                      1 ...DATE_VALID                                      *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       24.02.02    W. Paulin     created 							*
*   01.01       23.06.02    W. Paulin     ignore year - not relevant		*
****************************************************************************/
UINT DateIsValid(DTStructure *pBegin, DTStructure *pEnd)
{
 if ( (pBegin->day == 0) || (pBegin->month == 0) || 				/* ignore year */
      (pEnd->day   == 0) || (pEnd->month   == 0) )					/* ignote year */
   {
    return(DATE_INVALID);
   }
 else
   {
    return(DATE_VALID);
   }
} 




/****************************************************************************
**********               	 	TimeWithinBeginEnd()   	           **********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     Checks if current time is with begin end range.                       *
*     Calculation is done in hours and minute.                              *
*     midnight is taken in consideration                                    *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       pBegin	     : pointer to time stamp of begin                       *
*       pEnd	     : pointer to time stamp of end                         *
*       pCurrentTime : pointer to current time                              *
*                                                                           *
*    Output:                                                                *
*       return value : in range or not in range                             *
*                      0 ...not in range                                    *
*                      1 ...in range                                        *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       24.02.02    W. Paulin     created 							*
****************************************************************************/
UINT TimeWithinBeginEnd(time_s *pBegin, time_s *pEnd, DTStructure *pCurrentTime)
{
 USINT timeSpanWithinOneDay = 0;

 /* two possibilities: */
 if ( (pEnd->hour > pBegin->hour) || ((pEnd->hour == pBegin->hour) && (pEnd->minute >= pBegin->minute)) )
   timeSpanWithinOneDay = 1;		/* 1.) Begin is earlier than End (only hour and minute) -> time span is within one day */
 else
   timeSpanWithinOneDay = 0;		/* 2.) Begin is after end (regarding hour and minute) -> time span is over new day */
 
 if (timeSpanWithinOneDay)
   {
    if (pCurrentTime->hour < pBegin->hour) 
      return(TIME_OUT_OF_RANGE);
    else if ( (pCurrentTime->hour == pBegin->hour) && (pCurrentTime->minute < pBegin->minute) ) /* same hour but minute not yet reached */
      return(TIME_OUT_OF_RANGE);


    if (pCurrentTime->hour > pEnd->hour)
      return(TIME_OUT_OF_RANGE);
    else if ( (pCurrentTime->hour == pEnd->hour) && (pCurrentTime->minute > pEnd->minute) ) 	/* same hour but minute already passed */
      return(TIME_OUT_OF_RANGE);
   }
 else
   {
    if ( (pCurrentTime->hour < pBegin->hour) && (pCurrentTime->hour > pEnd->hour) )
      return(TIME_OUT_OF_RANGE);
    else if ( (pCurrentTime->hour == pBegin->hour) && (pCurrentTime->minute < pBegin->minute) ) /* same hour but minute not yet reached */
      return(TIME_OUT_OF_RANGE);
    else if ( (pCurrentTime->hour == pEnd->hour) && (pCurrentTime->minute > pEnd->minute) ) 	/* same hour but minute already passed */
      return(TIME_OUT_OF_RANGE);
   }
 
 return(TIME_IN_RANGE);
}


/****************************************************************************
**********               	 	TimeIsValid()   	 	           **********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     Checks if given time is valid:                                        *
*     from 00:00 to 00:00                                                   *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       pBegin	     : pointer to time stamp of begin                       *
*       pEnd	     : pointer to time stamp of end                         *
*                                                                           *
*    Output:                                                                *
*       return value : in range or not in range                             *
*                      0 ...TIME_INVALID                                    *
*                      1 ...TIME_VALID                                      *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       24.02.02    W. Paulin     created 							*
****************************************************************************/
UINT TimeIsValid(time_s *pBegin, time_s *pEnd)
{
 if ( (pBegin->hour == 0) && (pBegin->minute == 0) &&
      (pEnd->hour   == 0) && (pEnd->minute   == 0) )
   {
    return(TIME_INVALID);
   }
 else
   {
    return(TIME_VALID);
   }
} 


/****************************************************************************
**********                    DayWithinBeginEnd()    	           **********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     Checks if current day is with begin end range.                        *
*     Calculation is done in days.                                          *
*     new week is taken in consideration                                    *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       pBegin	     : pointer to day of begin                              *
*       pEnd	     : pointer to day of end                                 *
*       pCurrentTime : pointer to current time                              *
*                                                                           *
*    Output:                                                                *
*       return value : in range or not in range                             *
*                      0 ...not in range                                    *
*                      1 ...in range                                        *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       03.03.01    W. Paulin     created 							*
****************************************************************************/
UINT DayWithinBeginEnd(USINT *pBegin, USINT *pEnd, DTStructure *pCurrentTime)
{
 USINT timeSpanWithinOneWeek = 0;

 /* three possibilities: */
 if (*pEnd > *pBegin)
   timeSpanWithinOneWeek = 1;		/* 1.) Begin is earlier than End -> time span is within one week */
 else if (*pEnd < *pBegin)
   timeSpanWithinOneWeek = 0;		/* 2.) Begin is after End -> time span is over new week */
 else
   return(DAY_IN_RANGE);			/* 3.) Begin is equal to End -> every day is in range */

 
 if (timeSpanWithinOneWeek)
   {
    if (pCurrentTime->wday < *pBegin) 
      return(DAY_OUT_OF_RANGE);
    else if (pCurrentTime->wday > *pEnd)
      return(DAY_OUT_OF_RANGE);
   }
 else
   {
    if (pCurrentTime->wday > *pBegin) 
      return(DAY_OUT_OF_RANGE);
    else if (pCurrentTime->wday < *pEnd)
      return(DAY_OUT_OF_RANGE);
   }
 
 return(DAY_IN_RANGE);
}




/****************************************************************************
**********         				 NewDataObject()   	 		        *********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     Creates a data object. If object already exists and length does not   *
*     match, data object will be deleted and again created                  *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       pfDatObjCreate   : pointer to ALIAS structure of FUB                *
*       pfDatObjDelete   : pointer to ALIAS structure of FUB                *
*       pFileName        : pointer to name of file                          *
*       memType          : memory type which should be used                 *
*       option           : options related to DatObjCreate() FUB            *
*       pData            : pointer to data which should be copied to object *
*                          (new module) or will be written (module exits)   *
*       sizeOfData       : size of given data                               *
*       pDataObjInf      : pointer to info structure of data object         *
*                                                                           *
*     Output:                                                               *
*       status                                                              *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       16.03.02    W. Paulin     created 							*
*   01.01       04.05.02    W. Paulin     bugfix: no local fDatObjDelete	*
*                                         length of data objects are        *
*                                         multible of 4 is taken in         *
*                                         consideration                     *
****************************************************************************/
UINT NewDataObject(DatObjCreate_typ *pfDatObjCreate, DatObjDelete_typ *pfDatObjDelete, USINT *pFileName, USINT memType, UDINT option, void *pData, UDINT sizeOfData, dataObjInf_s *pDataObjInf)
{
 DatObjInfo_typ 	fDatObjInfo;
 USINT 				addSize;
 
 fDatObjInfo.enable = 1;
 fDatObjInfo.pName = (UDINT)pFileName;
 
 DatObjInfo(&fDatObjInfo);													/* get information about data object */
 
 /* take care about length of data modules which are always a multible of 4 -> adjust size if necessary to avoid length mismatch */
 addSize = (USINT)(sizeOfData % 4);

 if (addSize != 0) 
   sizeOfData += 4 - addSize;
 
 /* check if data object already exists and length does match */
 if ( (fDatObjInfo.status == ERR_OK) && (sizeOfData == fDatObjInfo.len) )
   {
    pDataObjInf->pData     = fDatObjInfo.pDatObjMem;						/* pointer to information */
    pDataObjInf->doIdent   = fDatObjInfo.ident;								/* ident of data object */
    pDataObjInf->doLength  = fDatObjInfo.len;								/* length of data in data object */
    pDataObjInf->doMemType = fDatObjInfo.MemType;							/* memory type of data object */
    pDataObjInf->doOption  = fDatObjInfo.Option;							/* additional options of data object */
    
    memcpy( pData, (void*)pDataObjInf->pData, sizeOfData );					/* initalize information structure */
    
    return(ERR_OK);
   }
 else if ( ((fDatObjInfo.status == ERR_OK) && (sizeOfData != fDatObjInfo.len)) || (pfDatObjDelete->enable == 1) )
   {
    /* delete data object if length doesn't match - keep calling FUB due to asynchronous behaviour */
    if (pfDatObjDelete->enable == 0)
      {
       pfDatObjDelete->enable = 1;
       pfDatObjDelete->ident  = fDatObjInfo.ident;
      }

    DatObjDelete(pfDatObjDelete);
       
    if (pfDatObjDelete->status == ERR_OK)
      {
       pfDatObjDelete->enable = 0;
       return(ERR_FUB_BUSY);												/* creation of data object not yet finished */
      }
    else
      {
       return(pfDatObjDelete->status);
      }
   }
 else
   {
    /* data object does not exists - never has or just deleted */    
    pfDatObjCreate->enable   = 1;
    pfDatObjCreate->pName    = (UDINT)pFileName;
    pfDatObjCreate->len      = sizeOfData;

    pfDatObjCreate->MemType  = memType;
    pfDatObjCreate->Option   = option;
    pfDatObjCreate->pCpyData = (UDINT)pData;
    
    DatObjCreate(pfDatObjCreate);

    if (pfDatObjCreate->status == ERR_OK)
      { 
       pDataObjInf->pData     = pfDatObjCreate->pDatObjMem;				/* pointer to segment information */
       pDataObjInf->doIdent   = pfDatObjCreate->ident;						/* ident of data object containing schedule */
       pDataObjInf->doLength  = pfDatObjCreate->len;						/* length of data in data object */
       pDataObjInf->doMemType = pfDatObjCreate->MemType;					/* memory of data object containing schedule */
       pDataObjInf->doOption  = pfDatObjCreate->Option;					/* additional options of data object containing schedule */
      }
    
    return(pfDatObjCreate->status);
   }

 return(ERR_OK);
}


/****************************************************************************
**********         				getChartValueY()  	 		        *********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     Evaluates a value corresponding to a given value corresponding to a   *
*     given chart.                                                          *
*     Between to known values will be interpolated lineary.                 *
*     Outside the table will be extrapolated lineary according to last      *
*     known values                                                          *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       inValueX         : given value in X direction                       *
*       pChartElement    : pointer to chart table                           *
*       nbEntries        : number of entries                                *
*                                                                           *
*     Output:                                                               *
*       desired value                                                       *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       16.03.02    W. Paulin     created 							*
****************************************************************************/
REAL getChartValueY(REAL inValueX, xyChartElement_s *pChartElement, UDINT nbEntries)
{
 UDINT elementIndex    = 0;
 UDINT oddElementIndex = 0;
 UDINT searchMin       = 0;
 UDINT searchMax       = 0;
 REAL  k = 0;
 REAL  d = 0;
 
 if (nbEntries < 2) return(0);								/* chart must contain at least two values */
 
 if (inValueX < pChartElement[0].x)							/* 1. inValueX is out of lower range of chart */
   {
    /* get characteristic of chart according to the very first to values */
    k = calcK(pChartElement[0].x, pChartElement[0].y, pChartElement[1].x, pChartElement[1].y);
    d = calcD(pChartElement[0].x, pChartElement[0].y, pChartElement[1].x, pChartElement[1].y);
   }
 else if (inValueX > pChartElement[nbEntries - 2].x) 		/* 2. inValue is out of higher range of chart */
   {
    /* get characteristic of chart according to the very last to values */
    k = calcK(pChartElement[nbEntries - 2].x, pChartElement[nbEntries - 2].y, pChartElement[nbEntries - 1].x, pChartElement[nbEntries - 1].y);
    d = calcD(pChartElement[nbEntries - 2].x, pChartElement[nbEntries - 2].y, pChartElement[nbEntries - 1].x, pChartElement[nbEntries - 1].y);
   }
 else														/* 3. inValue is within chart */
   {
#ifdef SLOW
    for (elementIndex = 0; elementIndex < nbEntries - 1; elementIndex++)
     {
      /* find pairs of coordinats in which desired inValueX will be find */
      if ( (inValueX >= pChartElement[elementIndex].x) && (inValueX <= pChartElement[elementIndex + 1].x) )
        {
         /* get characteristic of chart according to surrounding x/y pairs */
         k = calcK(pChartElement[elementIndex].x, pChartElement[elementIndex].y, pChartElement[elementIndex + 1].x, pChartElement[elementIndex + 1].y);
         d = calcD(pChartElement[elementIndex].x, pChartElement[elementIndex].y, pChartElement[elementIndex + 1].x, pChartElement[elementIndex + 1].y);
         break;
        }
     } 
#endif
   
   elementIndex = nbEntries / 2;
   searchMin    = 0;
   searchMax    = nbEntries;
   while(1)
     {
      /* find pairs of coordinats in which desired inValueX will be find */
      if ( (inValueX >= pChartElement[elementIndex].x) && (inValueX <= pChartElement[elementIndex + 1].x) )
        {
         /* get characteristic of chart according to surrounding x/y pairs */
         k = calcK(pChartElement[elementIndex].x, pChartElement[elementIndex].y, pChartElement[elementIndex + 1].x, pChartElement[elementIndex + 1].y);
         d = calcD(pChartElement[elementIndex].x, pChartElement[elementIndex].y, pChartElement[elementIndex + 1].x, pChartElement[elementIndex + 1].y);
         break;
        }
      else
        {
         oddElementIndex = elementIndex & 0x00000001; 				/* if LSB is set -> current index is odd */
     
         if (inValueX > pChartElement[elementIndex].x)
           {
            if (oddElementIndex) 
              elementIndex--;

            searchMin    = elementIndex;
            elementIndex = elementIndex + (searchMax - elementIndex) / 2;
           }
         else
           {
            if (elementIndex == 1)
              elementIndex--;
            else if (oddElementIndex) 
              elementIndex++;

            searchMax    = elementIndex;
            elementIndex = elementIndex - (elementIndex - searchMin) / 2;
           }
        }
     } 
     
   } 
   
 return( calcY(inValueX, k, d) ); 							/* calculate y and say good bye... */
}



/* gets k of linear equation: y = k*x + d */
REAL calcK(REAL x1, REAL y1, REAL x2, REAL y2)
{
 REAL k;
 
 if (x1 == x2) return(0);
 
 k = (y1 - y2) / (x1 - x2);
 
 return(k);
}

/* gets d of linear equation: y = k*x + d */
REAL calcD(REAL x1, REAL y1, REAL x2, REAL y2)
{
 REAL d;
 
 if (x1 == x2) return(0);

 d = ((y2*x1) - (y1*x2)) / (x1 - x2);
 
 return(d);
}


/* gets y of linear equation: y = k*x + d */
REAL calcY(REAL x, REAL k, REAL d)
{
 REAL y;
 
 y = k*x + d;
 
 return(y);
}




/****************************************************************************
**********         				applyUserInput()  	 		        *********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     This function applies a given user input after a certain delay        *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       pSelect          : pointer to flag indicating a new selection       *
*       maxSelect        : maximum possible selection                       *
*       firstSelect      : first selection                                  *
*       pTimer           : pointer to timer to calculate delay              *
*       delay            : delay in to apply user input                     *
*       pTempSelect      : pointer to temporary new selection               *
*       pApplySelect     : pointer selection after delay applied from       *
*                          pTempSelect                                      *
*       pNewSelection    : pointer to variable which will be set when ever  *
*                          a new selection recognized                       *
*       cycT             : cycle time of calling task                       *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       04.05.02    W. Paulin     created 							*
*   01.01       12.07.02    W. Paulin     set ne selection only once        *
*   01.02       13.07.02    W. Paulin     new parameter: pNewSelection      *
****************************************************************************/
void applyUserInput(USINT *pSelect, USINT maxSelect, USINT firstSelect, UDINT *pTimer, UDINT delay, USINT *pTempSelect, USINT *pApplySelect, USINT *pNewSelection, UDINT cycT)
{
 /* nil pointer check */
 if ((!pSelect) || (!pTimer) || (!pTempSelect) || (!pApplySelect))
   return;
 
 /* generate new selection caused by user input /Begin */
 if (*pSelect == 1)
   {
    if (++(*pTempSelect) >= maxSelect)
      *pTempSelect = firstSelect;

    *pSelect = 0;								/* reset selection indication flag */
    *pTimer  = cycT;							/* new selection -> restart timer for delay */

    if (pNewSelection)							/* set flag only if given - ignore nil pointer */
      *pNewSelection = 1;
   }
 /* generate new selection caused by user input /End */

 /* apply new user input after certain delay to avoid jitter /Begin */
 if (*pTimer >= delay)
   {
    *pApplySelect = *pTempSelect;
    *pTimer  = 0;								/* set new selection only once */
   }
 else if (*pTimer > 0)
   {
    *pTimer += cycT;
   }
 /* apply new user input after certain delay to avoid jitter /Begin */

 return;
}

/****************************************************************************
**********         					round()  	 			        *********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     This function rounds a REAL value to the next integer value           *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       value            : REAL value to be rounded                         *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       08.06.02    W. Paulin     created 							*
*   01.01       01.12.02    W. Paulin     negative values supported			*
****************************************************************************/
DINT round(REAL value)
{
 if (value >= 0)
   return( ((value - (DINT)value) >=  0.5) ? (++((DINT)value)) : ((DINT)value) );
 else
   return( ((value - (DINT)value) <= -0.5) ? (--((DINT)value)) : ((DINT)value) );
}


/****************************************************************************
**********         					absREAL()  	 			        *********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     This function calculate the absolute value of a given REAL value      *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       value            : REAL value to be rounded                         *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       06.07.02    W. Paulin     created 							*
****************************************************************************/
REAL absREAL(REAL value)
{
 return( (value > 0) ? (value) : (value * (-1)) );
}



/****************************************************************************
**********         			   getDayOfYear()   			        *********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     This function determine the day of this year                          *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       pDate           : pointer to date as DTStructure                    *
*                                                                           *
*     Return:                                                               *
*        	            : day of year                                       *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       16.06.02    W. Paulin     created 							*
****************************************************************************/
UINT getDayOfYear(DTStructure *pDate)
{
 UINT monthIndex     = 0;
 /* number days per month - without leap year - starting at index #1 */
 USINT dayPerMonth[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
 UINT dayOfYear      = 0;

 /* plausibility */
 if ( (pDate->month == 0) || (pDate->month > 12) || (pDate->day == 0) || (pDate->day > 31) )
   return(0);
 
 /* count all days before this month */
 for (monthIndex = 1; monthIndex < pDate->month; monthIndex++)
   dayOfYear += dayPerMonth[monthIndex];
   
 /* count all days of this month */    
 dayOfYear += pDate->day;
 
 /* if year is a leap year and february has been already passed -> add one day because of 29th of feb. */
 if ( (isLeapYear(pDate->year)) && (pDate->month > 2) )
   dayOfYear++;

 return(dayOfYear);   
}




/****************************************************************************
**********         				  isLeapYear()   			        *********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     This function determine whether given year is a leap year             *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       year            : year to checked                                   *
*                                                                           *
*     Return:                                                               *
*       0	            : year is no leap year                              *
*       1	            : year is a leap year                               *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       16.06.02    W. Paulin     created 							*
****************************************************************************/
UINT isLeapYear(UINT year)
{
 if (
     ( ((year % 4)   == 0) && ((year % 100) != 0) ) || ((year % 400) == 0) 
    )
   {
    return(1);
   }
 else
   {
    return(0);
   }    
}


/****************************************************************************
**********         				      movAv()   			        *********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     This function calculates average of a value                           *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       pBufferInf      : pointer to buffer info structure                  *
*       newValue        : new value to be inserted into buffer              *
*       pMovAvValue     : pointer to average value                          *
*                                                                           *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       05.10.02    W. Paulin     created 							*
****************************************************************************/
void movAv( bufferInf_s *pBufferInf, REAL newValue, REAL *pMovAvValue )
{
 /* substract old value in buffer from sum */
 pBufferInf->sumValue -= pBufferInf->pBuffer[pBufferInf->index];
 
 /* add new value to sum */
 pBufferInf->sumValue += newValue;
 
 /* insert new value to buffer */
 pBufferInf->pBuffer[pBufferInf->index] = newValue;
 
 /* calculate new sum */
 *pMovAvValue = pBufferInf->sumValue / pBufferInf->nbElements;
 
 /* index handling according ringbuffer */
 if ( (++pBufferInf->index) >= pBufferInf->nbElements ) pBufferInf->index = 0;
}


/* power; base^n */
DINT myPow(DINT base, DINT n)
{
 DINT i, p;
 
 p = 1;
 for (i = 1; i <= n; ++i)
   p = p * base;
 
 return(p);
}


/****************************************************************************
**********               	 	RawTempIsValid()   	 	           **********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     Checks if given raw value of temperature is valid                     *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       temp	     : raw value of temperature module                      *
*                                                                           *
*    Output:                                                                *
*       return value : in range or not in range                             *
*                      0 ...RAW_TEMP_INVALID                                *
*                      1 ...RAW_TEMP_VALID                                  *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       07.12.02    W. Paulin     created 							*
****************************************************************************/
UINT RawTempIsValid(UINT rawTemp)
{
 if ( (rawTemp == 0) || (rawTemp == 0x7FFF) || (rawTemp == 0x8000) || (rawTemp == 0x8001) )
   {
    return(RAW_TEMP_INVALID);
   }
 else
   {
    return(RAW_TEMP_VALID);
   }
} 
