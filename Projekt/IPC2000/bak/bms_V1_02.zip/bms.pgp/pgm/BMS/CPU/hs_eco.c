/*********************************************************************************************
*  Copyright: 2002 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Managment System                                                    *
*    Purpose    economic operation of heating system                                         *
*                                                                                            *
*    Filename   hs_eco.c                                                                     *
*--------------------------------------------------------------------------------------------*
*  Description :                                                                             *
*    economic operation of heating system                                                    *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  Structures  :                                                                             *
*   hsEcoInf_s                                                                               *
*             .outsideTemp                   moving average of outside temperature           *
*                        .enable             enables using of this eco function              *
*                        .cmdMovAvBuffer     command and status of average buffer            *
*                        .movAvBufferInf     info structure of moving average buffer         *
*                             .pBuffer       pointer to buffer                               *
*                             .index         actual write index                              *
*                             .nbElements    number elements of moving average buffer        *
*                             .sumValue      summery value of all elements                   *
*                        .movAvTemp          moving average temperature                      *
*             .livingRoomTemp                temperature of living room enables heating      *
*                        .enable             enables using of this eco function              *
*                        .release            release closed loop for heating control         *
*                        .actTemp            actual value of living room temperature         *
*                        .setTemp            set value of living room temperature            *
*                        .actTempHystHigh    high hysteresis of actual temperature           *
*                        .actTempHystLow     low hysteresis of actual temperature            *
*             .firing                        firing off if set temperature too low           *
*                        .enable             enables using of this eco function              *
*                        .release            release firing device                           *
*                        .minSetTemp         minimum set temperature of firing device        *
*                        .setTempHyst        hysteresis of set temperature                   *
*                        .toggleDelayTimer   timer to toggle release of firing device        *
*                        .toggleDelay        delay time to toggle release of firing device   *
*                        .lcOutput           output of 2 point closed loop controler         *
*             .noon                          high temperature at noon disables heating       *
*                        .enable             enables using of this eco function              *
*                        .release            release closed loop for heating control         *
*                        .minTemp            minimum at noon to switch of heating            *
*                        .setTempHyst        hysteresis of set temperature                   *
*                        .offTimer           timer switch off heating                        *
*                        .offTime            time to switch off heating                      *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  History :                                                                                 *
*  Version       Datum         Autor                                                         *
*  01.00         05.10.02      W. Paulin     created                                         *
*  01.01         07.12.02      W. Paulin     RawTempIsValid() implemented                    *
*  01.02         24.12.02      W. Paulin     separate output value for lc2Point()            *
*********************************************************************************************/
#include <bur/plctypes.h>
#include <bms_gn.h>
#include <bms_io.h>


_LOCAL RTInfo_typ       fRTInfo;
_LOCAL UDINT			cycT;

_LOCAL USINT 			newHour;
_LOCAL USINT 			oldHour;
_LOCAL USINT 			newMinute;
_LOCAL USINT 			oldMinute;

_LOCAL UINT				status;
_LOCAL UDINT			loopIndex;
_LOCAL USINT			waitInitCount;

_LOCAL dataObjInf_s		dataObjHsEcoInf;
_LOCAL dataObjInf_s		dataObjLinRoom;

_LOCAL DatObjInfo_typ   fDatObjInfo; 
_LOCAL DatObjCreate_typ fDatObjCreate;
_LOCAL DatObjDelete_typ fDatObjDelete;
_LOCAL DatObjWrite_typ  fDatObjWrite;

_LOCAL REAL				oldLivingRoomTemp;


_INIT void hs_ecoini(void)
{
 fRTInfo.enable = 1; 
 RTInfo(&fRTInfo);
 
 cycT = fRTInfo.cycle_time / 1000;					/* transform cycle time us -> ms */


 /* get chart for linarisation of room temperature sensor /Begin */
 fDatObjInfo.enable = 1;
 fDatObjInfo.pName = (UDINT)CHART_LINEAR_ROOM_TEMP_DO_NAME;
 
 DatObjInfo(&fDatObjInfo);										/* get schedule */
 
 if (fDatObjInfo.status == ERR_OK)								/* error ? */
   {
    dataObjLinRoom.pData     = fDatObjInfo.pDatObjMem;			/* pointer to chart */
    dataObjLinRoom.doIdent   = fDatObjInfo.ident;				/* ident of data object containing chart */
    dataObjLinRoom.doLength  = fDatObjInfo.len;					/* length of data in data object */
    dataObjLinRoom.doMemType = fDatObjInfo.MemType;				/* memory of data object containing chart */
    dataObjLinRoom.doOption  = fDatObjInfo.Option;				/* additional options of data object containing chart */
   }
 else
   {
    memset( &dataObjLinRoom, 0, sizeof(dataObjLinRoom) );
    VisuInterface.heatingAlarm[HEATING_LIN_ROOM_DO_ERROR] = 1;
   }
 /* get chart for linarisation of room temperature sensor /End */

 
 /* get current heating economic parameter or create new one if neccessary /Begin */
 do
 {
  status = NewDataObject( &fDatObjCreate, &fDatObjDelete, HS_ECO_INFO_DO_NAME, doUSRROM, 0, &HsEcoInf, sizeof(HsEcoInf), &dataObjHsEcoInf);
 } while (status == ERR_FUB_BUSY);
 if (status != ERR_OK) VisuInterface.heatingAlarm[HEATING_HS_ECO_DO_ERROR] = 1;
 /* get current heating economic parameter or create new one if neccessary /Begin */

 
 /* set up environment for moving average calculation of outside temperature /Begin */
 HsEcoInf.outsideTemp.movAvBufferInf.nbElements = HS_ECO_OUTSIDE_TEMP_MOV_AV_ELEMENTS;
 status = TMP_alloc(HsEcoInf.outsideTemp.movAvBufferInf.nbElements * sizeof(REAL), (void**)&HsEcoInf.outsideTemp.movAvBufferInf.pBuffer);
 if (status) 
   {
    HsEcoInf.outsideTemp.movAvBufferInf.pBuffer = 0;
    HsEcoInf.outsideTemp.cmdMovAvBuffer         = MOV_AV_NOT_PREPARED;
   }
 else
   {
    memset( HsEcoInf.outsideTemp.movAvBufferInf.pBuffer, 0, HsEcoInf.outsideTemp.movAvBufferInf.nbElements * sizeof(REAL));
    HsEcoInf.outsideTemp.cmdMovAvBuffer         = MOV_AV_PREPARED;  
   }
 /* set up environment for moving average calculation of outside temperature /End */

 /* set up environment for living room temperature /Begin */
 HsEcoInf.livingRoomTemp.actTempHystHigh = HS_ECO_LIVING_ROOM_ACT_TEMP_HYSTERESIS_HIGH;
 HsEcoInf.livingRoomTemp.actTempHystLow  = HS_ECO_LIVING_ROOM_ACT_TEMP_HYSTERESIS_LOW;
 /* set up environment for living room temperature /End */

 /* set up environment for minimum set temperature of firing device /Begin */
 HsEcoInf.firing.minSetTemp       = HS_ECO_FIRING_MIN_SET_TEMPERATURE;
 HsEcoInf.firing.setTempHyst      = HS_ECO_FIRING_SET_TEMP_HYSTERESIS;
 HsEcoInf.firing.toggleDelayTimer = 0;
 HsEcoInf.firing.toggleDelay      = HS_ECO_FIRING_TOGGLE_DELAY_TIME;
 /* set up environment for minimum set temperature of firing device /End */
 
 
 /* set up environment for minimum temperature at noon /Begin */
 if (HsEcoInf.noon.minTemp == 0) 
   HsEcoInf.noon.minTemp = HS_ECO_NOON_DEF_MIN_TEMP;     
 
 HsEcoInf.noon.offTimer = HsEcoInf.noon.offTime;
 /* set up environment for minimum temperature at noon /End */
}


_CYCLIC void hs_ecocyc(void)
{
 /* generate new minute flag */
 getTimeFlags(&CurrentTime, &newHour, &oldHour, &newMinute, &oldMinute, 0, 0);


 /* convert meassured resistance to linear temperature */
 if ( RawTempIsValid(iLivingRoomTemp) )
   {
    if (dataObjLinRoom.pData)
      {
       /* get resistance of NTC with total resistance */
       HsEcoInf.livingRoomTemp.actTemp = getChartValueY( 1 / ( 1/((REAL)iLivingRoomTemp/10) - 1/(REAL)ROOM_PARALLEL_RESISTANCE ), 
                                                         (xyChartElement_s *)dataObjLinRoom.pData, 
                                                         dataObjLinRoom.doLength / sizeof(xyChartElement_s) );
      }
    else
      {
       /* if no chart found -> use linear default formular */
       HsEcoInf.livingRoomTemp.actTemp = calcY( 1 / ( 1/((REAL)iLivingRoomTemp/10) - 1/(REAL)ROOM_PARALLEL_RESISTANCE ),  
                                                HS_LIN_ROOM_TEMP_DEF_K, 
                                                HS_LIN_ROOM_TEMP_DEF_D );
      }
   }

 /* evaluate tendency of living room temperature - with hysteresis */
 if ( 
     (newMinute) && 
     ( 
      ( ((HsEcoInf.livingRoomTemp.actTemp - oldLivingRoomTemp) > 0) ? (HsEcoInf.livingRoomTemp.actTemp - oldLivingRoomTemp) : 
                                                                      (oldLivingRoomTemp - HsEcoInf.livingRoomTemp.actTemp) ) >= HS_TENDENCY_TEMP_HYSTERESIS
      )
    )
   {
    if (HsEcoInf.livingRoomTemp.actTemp > oldLivingRoomTemp)
      VisuInterface.livingRoomTempTendency = 1;					/* temperature is rising */
    else
      VisuInterface.livingRoomTempTendency = 0;					/* temperature is falling */
    
    oldLivingRoomTemp = HsEcoInf.livingRoomTemp.actTemp;
   }


 /***********************************************************************************************************************/
 /*** MOVING AVERAGE FILTER OF OUTSIDE TEMPERATURE                                                                    ***/
 /***********************************************************************************************************************/
 /* initialize moving average buffer once to avoid average error in the first buffer cycle - wait 2 cycles to make sure that temperature arrived from CAN-Bus */
 if ( (HsEcoInf.outsideTemp.cmdMovAvBuffer == MOV_AV_DO_INIT) && (waitInitCount >= 2) )
   {
    for (loopIndex = 0; loopIndex < HsEcoInf.outsideTemp.movAvBufferInf.nbElements; loopIndex++)
    {
     HsEcoInf.outsideTemp.movAvBufferInf.pBuffer[loopIndex] = HsMgrInf.outsideTemp;
    }
    
    HsEcoInf.outsideTemp.movAvTemp               = HsMgrInf.outsideTemp;
    HsEcoInf.outsideTemp.movAvBufferInf.index    = 0;
    HsEcoInf.outsideTemp.movAvBufferInf.sumValue = HsEcoInf.outsideTemp.movAvTemp * HsEcoInf.outsideTemp.movAvBufferInf.nbElements;
    HsEcoInf.outsideTemp.cmdMovAvBuffer          = MOV_AV_OPERATIONAL;
   }
 else if (HsEcoInf.outsideTemp.cmdMovAvBuffer != MOV_AV_DO_INIT)
   {
    waitInitCount = 0;
   } 
 else
   {
    waitInitCount++;
   }
  
 /* calculate moving average value of outside temperature */
 if ( (newMinute) && (HsEcoInf.outsideTemp.cmdMovAvBuffer == MOV_AV_OPERATIONAL) )
   {
    movAv( &HsEcoInf.outsideTemp.movAvBufferInf, HsMgrInf.outsideTemp, &HsEcoInf.outsideTemp.movAvTemp );
   }
   

 
 /***********************************************************************************************************************/
 /*** CONSIDER LIVING ROOM TEMPERATURE TO ENABLE HEATING                                                              ***/
 /***********************************************************************************************************************/
 lc2Point(HsEcoInf.livingRoomTemp.setTemp + HsLoopInf.lcHeatingInf.setTempOffset, HsEcoInf.livingRoomTemp.actTemp, HsEcoInf.livingRoomTemp.actTempHystHigh, HsEcoInf.livingRoomTemp.actTempHystLow, &HsEcoInf.livingRoomTemp.release);


 /***********************************************************************************************************************/
 /*** LOW SET TEMPERATURE OF FIRING DEVICE DISABLES IT FOR A CERTAIN TIME                                              ***/
 /***********************************************************************************************************************/
 /* disable closed loop control if heating for a certain time in case of low firing set temperature, because temperature difference between */
 /* radiator and environment is too small to allow heat exchange */
 lc2Point(HsEcoInf.firing.minSetTemp, HsFireInf.firingInf.setTemp, HsEcoInf.firing.setTempHyst, HsEcoInf.firing.setTempHyst, &HsEcoInf.firing.lcOutput);
 if (HsEcoInf.firing.lcOutput > 0) 						/* HsEcoInf.firing.minSetTemp > HsFireInf.firingInf.setTemp -> setTemp too low */
   {
    HsEcoInf.firing.toggleDelayTimer += newMinute;
   }
 else
   {
    HsEcoInf.firing.toggleDelayTimer = 0;
    HsEcoInf.firing.release          = 1;
   }

 /* toogle release again after certain delay*/
 if (HsEcoInf.firing.toggleDelayTimer >= HsEcoInf.firing.toggleDelay)
   {
    if (HsEcoInf.firing.release == 1)
      HsEcoInf.firing.release = 0;
    else
      HsEcoInf.firing.release = 1;
      
    HsEcoInf.firing.toggleDelayTimer = 0;
   }

 /***********************************************************************************************************************/
 /*** HIGH OUTSIDE TEMPERATURE AT LUNCH TIME DISABLES HEATING FOR SEVERAL HOURS                                       ***/
 /***********************************************************************************************************************/
#warning: TEST Ausschalten der Heizung wenn es mittags zu warm ist
 if (HsEcoInf.noon.enable == 0)									/* while not enabled by user set timer to be elapsed */
   HsEcoInf.noon.offTimer = HsEcoInf.noon.offTime;

 if ((CurrentTime.hour == 12) && (newHour))						/* at 12 o'clock check temperature if high enough */
   {
    if (HsMgrInf.outsideTemp >= HsEcoInf.noon.minTemp)
      {
       HsEcoInf.noon.offTimer = 0;
      }
   }
 
 if (CurrentTime.hour < 12)										/* before 12 o'clock this eco function has no influence */
   {
    HsEcoInf.noon.release = 1;
   }
 else
   {
    if (HsEcoInf.noon.offTimer >= HsEcoInf.noon.offTime)		/* after 12 o'clock wait offTime until release will be given */
      {
       HsEcoInf.noon.release   = 1;
      }
    else
      {
       HsEcoInf.noon.release   = 0;
       HsEcoInf.noon.offTimer += newMinute;
      }
   }
     
   

 /***********************************************************************************************************************/
 /*** SAVE DATA                                                                                                       ***/
 /***********************************************************************************************************************/
 /* save info structure if input was done and new minute started /Begin */
 if ( (VisuInterface.hsEcoInputCompletion) && (newMinute) )
   {
    fDatObjWrite.enable  = 1;
    fDatObjWrite.ident   = dataObjHsEcoInf.doIdent;
    fDatObjWrite.Offset  = 0;
    fDatObjWrite.pSource = (UDINT)&HsEcoInf;
    fDatObjWrite.len     = sizeof(HsEcoInf);
    
    DatObjWrite(&fDatObjWrite);
    
    if (fDatObjWrite.status != ERR_OK)
      {
       dataObjHsEcoInf.nbWrErr++;
       dataObjHsEcoInf.lstWrErr = fDatObjWrite.status;
       VisuInterface.heatingAlarm[HEATING_HS_ECO_DO_ERROR] = 1;
       ERRxwarning(fDatObjWrite.status, 0, "write HsEcoInf");
      }

    VisuInterface.hsEcoInputCompletion = 0;
   }
 /* save info structure if input was done and new minute started /End */
}

