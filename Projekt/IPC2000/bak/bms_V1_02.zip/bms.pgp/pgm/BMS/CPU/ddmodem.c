/*********************************************************************************************
*  Copyright: 2001 by BERNECKER + RAINER Industrie-Elektronik Ges.m.b.H                      *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Any System                                                                   *
*    Purpose    Device Driver for Modems used for remote control of PCC                      *
*                                                                                            *
*    Filename   ddmodem.c                                                                    *
*--------------------------------------------------------------------------------------------*
*  Description :                                                                             *
*     This task will read out a configuration datamodule for a modem and sends given AT      *
*     commands to the modem                                                                  *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  Interface :                                                                               *
*   - nameOfModemCfgFile                                                                     *
*     name of configuration file containing AT command for Modem will be given by user       *
*                                                                                            *
*   - nameOfSelectedModem                                                                    *
*     will be read out of configuration file                                                 *
*                                                                                            *
*   - newModemCfgFile                                                                        *
*     new configuration file for modem selected                                              *
*                                                                                            *
*   - modemCfgState                                                                          *
*     if all done O.K. it is set to MODEM_INIT_OK. Otherwise see MODEM_CONFIGURATION_STATES  *
*     for details                                                                            *
*                                                                                            *
*********************************************************************************************/

#include <bur/plctypes.h>
#include <bms_gn.h>

/* local variables */
_LOCAL  USINT           ifOpen;
_LOCAL  USINT           responseBuffer[64];
_LOCAL  USINT           catTxBuffer[64];

_LOCAL  UINT            sModemCfg;
_LOCAL  UINT            status;
_LOCAL  UINT            atCommandLen;
_LOCAL  UINT            frmCloseStatus;

_LOCAL  UDINT           cycT;
_LOCAL  UDINT           responseTimer;
_LOCAL  UDINT           responseTimeOut;
_LOCAL  UDINT           loopIndex;
_LOCAL  UDINT           pATcommand;

_LOCAL  DatObjInfo_typ  fDatObjInfo;
_LOCAL  RTInfo_typ      fRTInfo;
_LOCAL  FRM_write_typ   fFRM_write;
_LOCAL  FRM_read_typ    fFRM_read;
_LOCAL  FRM_ctrl_typ    fFRM_ctrl;
_LOCAL  FRM_xopen_typ   fFRM_xopen;
_LOCAL  FRM_rbuf_typ    fFRM_rbuf;
_LOCAL  FRM_close_typ   fFRM_close;

_LOCAL  INADevOpen_typ  fINADevOpen;
_LOCAL  INADevClose_typ fINADevClose;

_LOCAL  USINT           *pStateModemCfg;
_LOCAL  USINT           stateModemCfgString[64];

/* macro definitions */
#define OK_NOT_FOUND    0
#define OK_FOUND        1

/* constants */
enum STATE_MACHINE_MODEM_CONFIGURATION
{
 STATE_FIND_CFG_FILE = 0,
 STATE_FIND_MODEM,
 STATE_WAIT_FIND_MODEM,
 STATE_SEND_AT_COMMAND,
 STATE_WAIT_SEND_AT_COMMAND,
};

                    
 
/* prototyping */
UINT findOK(USINT *pBuffer, UDINT sizeOfBuffer);


_INIT void ddmodemini()
{
 /* load default modem configuration and configure connected modem */
 strcpy( &VisuInterface.nameOfModemCfgFile[0], "elsa56k" ); /* initialize a default name for modem configuration file */
 VisuInterface.modemCfgState = MODEM_CFG_DONE;                            
 sModemCfg = STATE_FIND_CFG_FILE;                           /* initialize state machine */
                    
 fRTInfo.enable = 1;
 RTInfo(&fRTInfo);
 cycT = fRTInfo.cycle_time / 1000;                          /* get cycle time in ms */
            
 responseTimer = 0;
 responseTimeOut = 2000;                                    /* time out for response of modem in ms */
 
 if (fRTInfo.init_reason != INIT_REASON_DOWNLOAD)
   VisuInterface.newModemCfgFile = 1;						/* try modem configuration after start-up but not after download in order to avoid loosing connection */
    
 memset( &responseBuffer[0], 0, sizeof(responseBuffer) );    
}


_CYCLIC void ddmodemcyc()
{
 if (pStateModemCfg) 
   strcpy( &stateModemCfgString[0], pStateModemCfg);        /* state information for watch */

 if (VisuInterface.newModemCfgFile == 1)
   {
    switch (sModemCfg)
    {
     /********************************************************************************************************************/
     /*** FIND CONFIGURATION FILE                                                                                        */
     /********************************************************************************************************************/
     case STATE_FIND_CFG_FILE:
       pStateModemCfg = "STATE_FIND_CFG_FILE";
       strcpy( &VisuInterface.nameOfSelectedModem[0], "??????????" );
                          
       fDatObjInfo.enable = 1;
       fDatObjInfo.pName = (UDINT)&VisuInterface.nameOfModemCfgFile[0];
                    
       DatObjInfo(&fDatObjInfo);
                    
       if (fDatObjInfo.status != 0)                                                     /* stop configuration in case of error */
         {
          sModemCfg                     = STATE_FIND_CFG_FILE;
          VisuInterface.modemCfgState   = MODEM_CFG_NOT_FOUND;
          VisuInterface.newModemCfgFile = 0;
         }      
       else                                                                             /* configuration found */
         {
          strcpy( &VisuInterface.nameOfSelectedModem[0], (USINT*)fDatObjInfo.pDatObjMem );
          VisuInterface.modemCfgState = MODEM_CFG_FOUND;
          sModemCfg = STATE_FIND_MODEM;
         }      
     break;                 
                    
     /********************************************************************************************************************/
     /*** FIND CONNECTED MODEM                                                                                           */
     /********************************************************************************************************************/
     case STATE_FIND_MODEM:
       pStateModemCfg = "STATE_FIND_MODEM";

       /* get device string (second string in configuration) */
       fFRM_xopen.device = fDatObjInfo.pDatObjMem + strlen((USINT*)fDatObjInfo.pDatObjMem) + 1;     /* take care about zero end (+1) */
       /* get mode string (third string in configuration) */
       fFRM_xopen.mode   = fFRM_xopen.device + strlen((USINT*)fFRM_xopen.device) + 1;               /* take care about zero end (+1) */

       /* pointer to very first AT command (after third string = mode configuration) */
       pATcommand = fFRM_xopen.mode + strlen((USINT*)fFRM_xopen.mode) + 1;                          /* take care about zero end (+1) */


       /* i386 only: close INA2000 communication before opening with frame driver */
       #ifdef __i386__
       fINADevClose.enable  = 1;
       fINADevClose.pDevice = fFRM_xopen.device;
       INADevClose(&fINADevClose);
       if (fINADevClose.status == ERR_FUB_BUSY) return;                                             /* call fub every cycle until success */
       #endif

       fFRM_xopen.enable = 1;
       FRM_xopen(&fFRM_xopen);
                     
       if (fFRM_xopen.status != 0)                                                                  /* stop on error */
         {                                                      
          sModemCfg                     = STATE_FIND_CFG_FILE;
          VisuInterface.modemCfgState   = MODEM_NOT_FOUND;
          VisuInterface.newModemCfgFile = 0;
         }
       else
         {
          ifOpen = 1;                                                                   /* Interface is now open */

          fFRM_ctrl.enable = 1;
          fFRM_ctrl.ident  = fFRM_xopen.ident;
          fFRM_ctrl.ioctrl = 0x12;                                                      /* set/reset DTR -> ignore error 14813 (setting RTS does not work with out DTR) */
          fFRM_ctrl.inarg  = 1;
                        
          FRM_ctrl(&fFRM_ctrl);
                    
          fFRM_ctrl.enable = 1;
          fFRM_ctrl.ident  = fFRM_xopen.ident;
          fFRM_ctrl.ioctrl = 0x27;                                                      /* set/reset RTS */
                        
          FRM_ctrl(&fFRM_ctrl);
        
          /* modem test - by the way: switch off echo at commands */            
          strcpy( &catTxBuffer[0], "ATE0");
          catTxBuffer[4] = 0x0D;                                                        /* add Carriage return to AT command string */
          catTxBuffer[5] = 0x00;                                                        /* zero end */
        
          fFRM_write.enable = 1;
          fFRM_write.ident  = fFRM_xopen.ident;
          fFRM_write.buffer = (UDINT)&catTxBuffer[0];
          fFRM_write.buflng = strlen( &catTxBuffer[0] );

          FRM_write(&fFRM_write);

          if (fFRM_write.status != 0)
            { 
             sModemCfg                     = STATE_FIND_CFG_FILE;
             VisuInterface.modemCfgState   = MODEM_NOT_FOUND;
             VisuInterface.newModemCfgFile = 0;
            }
          else
            {
             sModemCfg = STATE_WAIT_FIND_MODEM;
             responseTimer = 0;
            }
         } /* if (fFRM_xopen.status != 0) */
     break;    
                    

     /********************************************************************************************************************/
     /*** WAIT FOR VERY FIRST RESPONSE                                                                                   */
     /********************************************************************************************************************/
     case STATE_WAIT_FIND_MODEM:
       pStateModemCfg = "STATE_WAIT_FIND_MODEM";

       fFRM_read.enable = 1;
       fFRM_read.ident  = fFRM_xopen.ident;

       FRM_read(&fFRM_read);
      
       if (fFRM_read.status == 0)                                                       /* something received */
         {
          if ( fFRM_read.buflng <= sizeof(responseBuffer) )                             /* check if buffer big enough */
            {
             memcpy( &responseBuffer[0], (void*)fFRM_read.buffer, fFRM_read.buflng );   /* copy received data */

             fFRM_rbuf.enable = 1;
             fFRM_rbuf.ident  = fFRM_xopen.ident;
             fFRM_rbuf.buffer = fFRM_read.buffer;
             fFRM_rbuf.buflng = fFRM_read.buflng;

             FRM_rbuf(&fFRM_rbuf);                                                      /* release buffer again */
            
             /* watch out for "OK" in first response frame */
             if ( findOK((USINT *)&responseBuffer[0], (UDINT)fFRM_read.buflng) == OK_FOUND )
               {
                memset( &responseBuffer[0], 0, fFRM_read.buflng );                      /* reset Buffer in order to avoid missunderstandings */

                VisuInterface.modemCfgState = MODEM_FOUND;    
                sModemCfg                   = STATE_SEND_AT_COMMAND;
               }
            }           
          else
            {
             sModemCfg                     = STATE_FIND_CFG_FILE;
             VisuInterface.modemCfgState   = MODEM_NOT_FOUND;
             VisuInterface.newModemCfgFile = 0;
            } /* if ( fFRM_read.buflng <= sizeof(responseBuffer) ) */
         }                  
       else if (responseTimer >= responseTimeOut)                                       /* timeout - no response from Modem */
         {
          sModemCfg                     = STATE_FIND_CFG_FILE;
          VisuInterface.modemCfgState   = MODEM_NOT_FOUND;
          VisuInterface.newModemCfgFile = 0;
         } /* if (fFRM_read.status == 0) */
     break;
                        
    
     /********************************************************************************************************************/
     /*** SEND AT COMMAND                                                                                                */
     /********************************************************************************************************************/
     case STATE_SEND_AT_COMMAND:
       pStateModemCfg = "STATE_SEND_AT_COMMAND";

       atCommandLen = strlen((USINT*)pATcommand);
       
       /* stop initialization imediately if AT command is too long */
       if ( atCommandLen > sizeof(catTxBuffer) - 2 )                                    /* additionaly to command, buffer should contain carriage return and zero end -> -2 */
         {
          sModemCfg                     = STATE_FIND_CFG_FILE;
          VisuInterface.modemCfgState   = MODEM_AT_COMMAND_TOO_LONG;
          VisuInterface.newModemCfgFile = 0;
          return;
         }
         
       strcpy( &catTxBuffer[0], (USINT*)pATcommand );

       catTxBuffer[atCommandLen]     = 0x0D;                                            /* change zero end to carriage return */
       catTxBuffer[atCommandLen + 1] = 0x00;                                            /* add zero end */
       atCommandLen                  = atCommandLen + 1;                                /* recalculate length due to carriage return */
                           
       fFRM_write.enable = 1;
       fFRM_write.ident  = fFRM_xopen.ident;
       fFRM_write.buffer = (UDINT)&catTxBuffer[0];
       fFRM_write.buflng = atCommandLen;

       FRM_write(&fFRM_write);

       if (fFRM_write.status != 0)
         { 
          sModemCfg                     = STATE_FIND_CFG_FILE;
          VisuInterface.modemCfgState   = MODEM_NO_CONNECTION;
          VisuInterface.newModemCfgFile = 0;
         }
       else
         {                     
          sModemCfg     = STATE_WAIT_SEND_AT_COMMAND;
          responseTimer = 0;
         }    
     break;                 
                        
     /********************************************************************************************************************/
     /*** WAIT FOR RESPONSE AND ADJUST POINTER TO NEXT AT COMMAND                                                        */
     /********************************************************************************************************************/
     case STATE_WAIT_SEND_AT_COMMAND:
       pStateModemCfg = "STATE_WAIT_SEND_AT_COMMAND";

       fFRM_read.enable = 1;
       fFRM_read.ident  = fFRM_xopen.ident;

       FRM_read(&fFRM_read);

       if (fFRM_read.status == 0)                                                       /* something received */
         {
          if ( fFRM_read.buflng <= sizeof(responseBuffer) ) 
            {
             memcpy( &responseBuffer[0], (void *)fFRM_read.buffer, fFRM_read.buflng );  /* copy received data */

             fFRM_rbuf.enable = 1;
             fFRM_rbuf.ident  = fFRM_xopen.ident;
             fFRM_rbuf.buffer = fFRM_read.buffer;
             fFRM_rbuf.buflng = fFRM_read.buflng;

             FRM_rbuf(&fFRM_rbuf);                                                      /* release buffer again */
            
             /* watch out for "OK" in first response frame */
             if ( findOK((USINT *)&responseBuffer[0], (UDINT)fFRM_read.buflng) == OK_FOUND )
               {
                /* continue with next AT command only if 'OK' has been received */
                pATcommand = pATcommand + strlen((USINT*)pATcommand) + 1;               /* adjust pointer to next AT command including zero end of last AT command */
                                           
                /* stop modem configuration if end of datamodule reached */
                /* CAUTION: length of datamodul is 4 byte aligned -> maximum last three bytes are not used and set to zero by Automation Runtime -> != 'AT' */
                if ( (pATcommand >= fDatObjInfo.pDatObjMem + fDatObjInfo.len)                   || 
                     ( (((USINT *)pATcommand)[0] != 'A') && (((USINT *)pATcommand)[0] != 'a') ) ||
                     ( (((USINT *)pATcommand)[1] != 'T') && (((USINT *)pATcommand)[1] != 't') )
                   )
                  {
                   sModemCfg                     = STATE_FIND_CFG_FILE;
                   VisuInterface.modemCfgState   = MODEM_INIT_OK;                             
                   VisuInterface.newModemCfgFile = 0;
                  }
                else
                  {
                   sModemCfg = STATE_SEND_AT_COMMAND;
                  }
               } /* if ( findOK((USINT *)&responseBuffer[0], (UDINT)fFRM_read.buflng) == OK_FOUND ) */
            }               
          else
            {
             sModemCfg                     = STATE_FIND_CFG_FILE;
             VisuInterface.modemCfgState   = MODEM_BAD_ANSWER;
             VisuInterface.newModemCfgFile = 0;
            } /* if ( fFRM_read.buflng <= sizeof(responseBuffer) ) */
         }          
       else if (responseTimer >= responseTimeOut)                                       /* timeout - no response from Modem */
         {
          sModemCfg                     = STATE_FIND_CFG_FILE;
          VisuInterface.modemCfgState   = MODEM_NO_CONNECTION;
          VisuInterface.newModemCfgFile = 0;
         } /* if (fFRM_read.status == 0) */
     break;                 
    } /* switch (sModemCfg) */
   }                      
 else
   {
    sModemCfg = STATE_FIND_CFG_FILE;
    pStateModemCfg = "STATE_FIND_CFG_FILE";
   } /* if (newModemCfgFile == 1) */
                    
 responseTimer = responseTimer + cycT;
            
 /* close interface to allow INA2000 communication */
 if ( (sModemCfg == STATE_FIND_CFG_FILE) && (ifOpen) )
   {
    fFRM_close.enable = 1;
    fFRM_close.ident  = fFRM_xopen.ident;
    
    FRM_close(&fFRM_close);
    
    
    /* i386 only: restore INA2000 settings after closing interface by frame driver */
    fINADevOpen.enable  = 1;
    fINADevOpen.pDevice = fINADevClose.pDevice;
    INADevOpen(&fINADevOpen);
    if (fINADevOpen.status != ERR_FUB_BUSY)
      ifOpen = 0;                                           /* i386 only: stop calling FUB if */
   }
}



/* find "OK" in any buffer or string */
UINT findOK(USINT *pBuffer, UDINT sizeOfBuffer)
{
 UDINT loopIndex = 0;
 
 for (loopIndex = 0; loopIndex < sizeOfBuffer; loopIndex++)
   if ( (pBuffer[loopIndex] == 'O') && (pBuffer[loopIndex + 1] == 'K') ) return(OK_FOUND);

 return(OK_NOT_FOUND);
}
