/*********************************************************************************************
*  Copyright: 2002 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Managment System                                                    *
*    Purpose    simulation of heating system                                                 *
*                                                                                            *
*    Filename   hs_sim.c                                                                     *
*--------------------------------------------------------------------------------------------*
*  Description :                                                                             *
*    heating system simulation                                                               *
*    download this task only if all heating system IOs are disabled!                         *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  Interface :                                                                               *
*    Inputs:                                                                                 *
*      oFiring								activates burner                                 *
*      oBoilerPump							activates pump for boiler                        *
*      oHeatingCirculationPump				activates circulation pump of heating system     *
*      HsLoopInf.lcMixerInf.actPosition 	actual position of mixer                         *
*                                                                                            *
*    Outputs:                                                                                *
*      HsMgrInf.outsideTemp					outside temperature                              *
*      HsFireInf.firingInf.actTemp			temperature inside burner                        *
*      HsFireInf.boilerInf.actTemp			temperature inside hot water boiler              *
*      HsLoopInf.flowPipeTemp				temperature of heating pipe after mixer          *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  History :                                                                                 *
*  Version       Datum         Autor                                                         *
*  01.00         07.07.02      W. Paulin     Created                                         *
*********************************************************************************************/

#include <bur/plctypes.h>
#include <bms_gn.h>
#include <bms_io.h>
#include <math.h>

#define ONE_SECOND				1000				/* 1s = 1000ms */

#define HS_FIRING_SIM_T_ON		900					/* tau in s if firing device is switched on */
#define HS_FIRING_SIM_T_OFF		3600				/* tau in s if firing device is switched off */

#define HS_BOILER_SIM_T_ON		900					/* tau in s if boiler pump is switched on */
#define HS_BOILER_SIM_T_OFF		18000				/* tau in s if boiler pump is switched off */

#define HS_FLOWPIPE_SIM_T_ON	600					/* tau in s if heating circulation pump is switched on */
#define HS_FLOWPIPE_SIM_T_OFF	3600				/* tau in s if heating circulation pump is switched off */


_LOCAL RTInfo_typ 	fRTInfo;
_LOCAL UDINT		simTimer;
_LOCAL UDINT		cycT;
_LOCAL UDINT		secondTickFiring;
_LOCAL UDINT		secondTickBoiler;
_LOCAL UDINT		secondTickFlowPipe;

_LOCAL REAL 		startFiringCoolTemp;
_LOCAL REAL 		startBoilerCoolTemp;
_LOCAL REAL 		startFlowPipeCoolTemp;
_LOCAL REAL 		startFlowPipeBackCoolTemp;

_LOCAL REAL 		startFiringHeatTemp;
_LOCAL REAL 		startBoilerHeatTemp; 


_LOCAL REAL			flowPipeTempBack;
_LOCAL UDINT		flowPipeBackDelayInputIndex;
_LOCAL UDINT		flowPipeBackDelayOutputIndex;
_LOCAL REAL			flowPipeBackDelayBuffer[HS_FLOWPIPE_SIM_T_ON];

_LOCAL REAL			firingK;
_LOCAL REAL			firingD;
_LOCAL REAL         simOutsideTemp;

_LOCAL BOOL 		oldFiring;
_LOCAL BOOL			oldBoilerPump;
_LOCAL BOOL			oldHeatingCirculationPump;



_INIT void hs_simini()
{
 fRTInfo.enable = 1;
 RTInfo(&fRTInfo);
 
 cycT = fRTInfo.cycle_time / 1000;
 
 simTimer = 0;

 secondTickFiring   = 0;
 secondTickBoiler   = 0;
 secondTickFlowPipe = 0;

 /* characteristic of firing device */
 /* heat up */
 firingK = calcK(0, HS_FIRING_MIN_SET_TEMP, HS_FIRING_SIM_T_ON, HS_FIRING_ALARM_TEMP);			/* firing device starts heat up from 20�C to 85�C in 900s (=15 min.) */
 firingD = calcD(0, HS_FIRING_MIN_SET_TEMP, HS_FIRING_SIM_T_ON, HS_FIRING_ALARM_TEMP);			/* firing device starts heat up from 20�C to 85�C in 900s (=15 min.) */
 
 flowPipeBackDelayInputIndex  = 0;	
 flowPipeBackDelayOutputIndex =  flowPipeBackDelayInputIndex + 1;
}


_CYCLIC void hs_simcyc()
{
 /* set alarm */
 VisuInterface.messageAlarm[HEATING_SIMULATION_ACTIVE] = 1;


 /* time base of simulation is one second */
 simTimer += cycT;
 if (simTimer < ONE_SECOND)
   return;
 else
   simTimer = 0;
 

 secondTickFiring++;
 if (oldFiring != oFiring) 
   {
    secondTickFiring = 0;
    oldFiring        = oFiring;
   }
 
 secondTickBoiler++;
 if (oldBoilerPump != oBoilerPump) 
   {
    secondTickBoiler = 0;
    oldBoilerPump    = oBoilerPump;
   }

 secondTickFlowPipe++;
 if (oldHeatingCirculationPump != oHeatingCirculationPump) 
   {
    secondTickFlowPipe          = 0;
    oldHeatingCirculationPump = oHeatingCirculationPump;
   }
 
 
 /***********************************************************************************************************************/
 /*** Firing device                                                                                                   ***/
 /***********************************************************************************************************************/
 if (oFiring == 1) 																					/* heat up - linear */
   {
    if (HsFireInf.firingInf.actTemp <= HS_FIRING_ALARM_TEMP)
      {
       HsFireInf.firingInf.actTemp = startFiringHeatTemp + calcY( (REAL)(secondTickFiring % HS_FIRING_SIM_T_ON), firingK, firingD);
       startFiringCoolTemp = HsFireInf.firingInf.actTemp;											/* keep actual temperature for cooling in mind */
      }
   }
 else if (oFiring == 0)																				/* cool down - reverse PT1 */
   {
    if (HsFireInf.firingInf.actTemp >= HS_FIRING_MIN_SET_TEMP)
      {
       HsFireInf.firingInf.actTemp = startFiringCoolTemp * ( 1 - exp(-(REAL)(5*HS_FIRING_SIM_T_OFF-(secondTickFiring % HS_FIRING_SIM_T_OFF))/(REAL)HS_FIRING_SIM_T_OFF) );	/*  (1-EXP(-(5*Tau-t)/Tau)) */
       startFiringHeatTemp = HsFireInf.firingInf.actTemp;											/* keep actual temperature for cooling in mind */
      }
   }
   
 /* limit to realistic values */  
 lcLimit( &HsFireInf.firingInf.actTemp, HS_FIRING_MIN_SET_TEMP, HS_FIRING_MAX_SET_TEMP);
 
 
 /***********************************************************************************************************************/
 /*** Boiler device                                                                                                   ***/
 /***********************************************************************************************************************/
 if ( (oBoilerPump == 1) && (HsFireInf.boilerInf.actTemp < HsFireInf.firingInf.actTemp) )																			/* heat up - PT2 */
   {
    HsFireInf.boilerInf.actTemp = HsFireInf.firingInf.actTemp * myPow( 1 - exp(-(REAL)(secondTickBoiler % HS_BOILER_SIM_T_ON)/(REAL)HS_BOILER_SIM_T_ON), 4 );	/*  (1-EXP(-(5*Tau-t)/Tau))^4; */
    startBoilerCoolTemp = HsFireInf.boilerInf.actTemp;												/* keep actual temperature for cooling in mind */
   }
 else if (oBoilerPump == 0) 																		/* cool down - reverse PT2 */
   {
    HsFireInf.boilerInf.actTemp = startBoilerCoolTemp * myPow( 1 - exp(-(REAL)(5*HS_BOILER_SIM_T_OFF-(secondTickBoiler % HS_BOILER_SIM_T_OFF))/(REAL)HS_BOILER_SIM_T_OFF), 4 );	/*  (1-EXP(-(5*Tau-t)/Tau)) ^ 4 */
    startBoilerHeatTemp = HsFireInf.boilerInf.actTemp;												/* keep actual temperature for cooling in mind */
   }
   
 /* limit to realistic values */  
 lcLimit( &HsFireInf.boilerInf.actTemp, HS_FIRING_MIN_SET_TEMP, HS_FIRING_MAX_SET_TEMP);


 /***********************************************************************************************************************/
 /*** Flow pipe temperature  					                                                                      ***/
 /***********************************************************************************************************************/
 if (oHeatingCirculationPump == 1)
   {
    /* flow pipe - linear according to mixer */
    HsLoopInf.flowPipeTemp = ( (HsFireInf.firingInf.actTemp * HsLoopInf.lcMixerInf.actPosition) / ONE_HUNDRED_PERCENT ) +
                             ( (flowPipeTempBack * (100 - HsLoopInf.lcMixerInf.actPosition))    / ONE_HUNDRED_PERCENT );
    
    /* flow pipe back is delayed to flow pipe and cooler because of heat loss */
    flowPipeBackDelayBuffer[flowPipeBackDelayInputIndex] = HsLoopInf.flowPipeTemp;
    flowPipeTempBack = flowPipeBackDelayBuffer[flowPipeBackDelayOutputIndex];

    if (++flowPipeBackDelayInputIndex  >= HS_FLOWPIPE_SIM_T_ON) flowPipeBackDelayInputIndex  = 0;
    if (++flowPipeBackDelayOutputIndex >= HS_FLOWPIPE_SIM_T_ON) flowPipeBackDelayOutputIndex = 0;

    startFlowPipeCoolTemp     = HsLoopInf.flowPipeTemp;
    startFlowPipeBackCoolTemp = flowPipeTempBack;
   }
 else
   {
    /* cool down - reverse PT2 */
    HsLoopInf.flowPipeTemp = startFlowPipeCoolTemp     * myPow( 1 - exp(-(REAL)(5*HS_FLOWPIPE_SIM_T_OFF-(secondTickFlowPipe % HS_FLOWPIPE_SIM_T_OFF))/(REAL)HS_FLOWPIPE_SIM_T_OFF), 4 );	/*  (1-EXP(-(5*Tau-t)/Tau)) ^ 4 */
    flowPipeTempBack       = startFlowPipeBackCoolTemp * myPow( 1 - exp(-(REAL)(5*HS_FLOWPIPE_SIM_T_OFF-(secondTickFlowPipe % HS_FLOWPIPE_SIM_T_OFF))/(REAL)HS_FLOWPIPE_SIM_T_OFF), 4 );	/*  (1-EXP(-(5*Tau-t)/Tau)) ^ 4 */
   }
   
 /* limit to realistic values */  
 lcLimit( &HsLoopInf.flowPipeTemp, HS_FIRING_MIN_SET_TEMP, HS_FIRING_MAX_SET_TEMP);
 lcLimit( &flowPipeTempBack      , HS_FIRING_MIN_SET_TEMP, HS_FIRING_MAX_SET_TEMP);

 
 /***********************************************************************************************************************/
 /*** Outside temperature                                                                                             ***/
 /***********************************************************************************************************************/
 HsMgrInf.outsideTemp = simOutsideTemp;
 
}

