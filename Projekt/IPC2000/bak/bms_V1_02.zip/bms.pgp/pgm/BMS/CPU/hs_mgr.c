/*********************************************************************************************
*  Copyright: 2002 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Managment System                                                    *
*    Purpose    overall managment of heating system                                          *
*                                                                                            *
*    Filename   hs_mgr.c                                                                     *
*--------------------------------------------------------------------------------------------*
*  Description :                                                                             *
*    heating system manager                                                                  *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  Structures  :                                                                             *
*   hsMgrInf_s                                                                               *
*             .activeHeatingMode         heating mode which is currently active              *
*             .activeHeatingProgramm     programm which is active during automatic mode      *
*             .dayOffset                 offset of day chart for heating                     *
*             .nightOffset               offset of night chart for heating                   *
*             .notAtHomeOffset           offset of not-at-home chart for heating             *
*             .manTempOffset             offset of manual override of chart for heating      *
*             .hotWaterSetTemp           set temperature of hot water in boiler              *
*             .outsideTemp               outside temperature                                 *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  History :                                                                                 *
*  Version       Datum         Autor                                                         *
*  01.00         17.02.02      W. Paulin     Created                                         *
*  01.01         19.10.02      W. Paulin     ECO functions implemented                       *
*  01.02         07.12.02      W. Paulin     RawTempIsValid() implemented                    *
*  01.03         14.12.02      W. Paulin     Life Guarding of CAN-IO implemented             *
*********************************************************************************************/

#include <bur/plctypes.h>
#include <bms_gn.h>
#include <bms_io.h>


_LOCAL RTInfo_typ 	fRTInfo;
_LOCAL UDINT	  	cycT;

_LOCAL UINT			status;

_LOCAL dataObjInf_s	dataObjHsMgrInf;
_LOCAL dataObjInf_s	dataObjProgramm1Inf;
_LOCAL dataObjInf_s	dataObjProgramm2Inf;
_LOCAL dataObjInf_s	dataObjProgramm3Inf;
_LOCAL dataObjInf_s	dataObjProgramm4Inf;
_LOCAL dataObjInf_s	dataObjLinOut;

_LOCAL DatObjInfo_typ    	fDatObjInfo; 
_LOCAL DatObjCreate_typ  	fDatObjCreate;
_LOCAL DatObjDelete_typ  	fDatObjDelete;
_LOCAL DatObjWrite_typ   	fDatObjWrite;

_LOCAL basicProgrammInf_s 	programm1;
_LOCAL basicProgrammInf_s 	programm2;
_LOCAL dateProgrammInf_s  	programm3;
_LOCAL dayProgrammInf_s   	programm4;

_LOCAL USINT 				newHour;
_LOCAL USINT 				oldHour;
_LOCAL USINT 				newMinute;
_LOCAL USINT 				oldMinute;

_LOCAL USINT 				oldPictNr;

_LOCAL USINT				sAT324configuration;
_LOCAL USINT 				cmdStartAT324cfg;

_LOCAL USINT				sEX270lifeGuarding;
_LOCAL USINT				cmdStartEX270lifeGuarding;
_LOCAL USINT				ex270ConnectAfterInit;

_LOCAL USINT				cmdBuffer[8];
_LOCAL USINT				resBuffer[8];
_LOCAL CANIOcmd_typ         fCANIOcmd;

_LOCAL USINT				newHeatingProgrammSelected;
_LOCAL REAL					oldOutsideTemp;


_INIT void hs_mgrini(void)
{
 fRTInfo.enable = 1; 
 RTInfo(&fRTInfo);
 
 cycT = fRTInfo.cycle_time / 1000;					/* transform cycle time us -> ms */

 
 /* get current heating manager parameter or create new one if neccessary */
 do
 {
  status = NewDataObject( &fDatObjCreate, &fDatObjDelete, HS_MGR_INFO_DO_NAME, doUSRROM, 0, &HsMgrInf, sizeof(HsMgrInf), &dataObjHsMgrInf);
 } while (status == ERR_FUB_BUSY);
 if (status != ERR_OK) VisuInterface.heatingAlarm[HEATING_HS_MGR_DO_ERROR] = 1;

 /* restore last heating mode in visu interface after power fail */
 VisuInterface.heatingNewMode     = HsMgrInf.activeHeatingMode;			


 /* restore last heating mode in visu interface after power fail /Begin */
 VisuInterface.heatingProgrammSelect = 1;
 VisuInterface.heatingNewProgramm = HsMgrInf.activeHeatingProgramm;		

 /* decrement VisuInterface.heatingNewProgramm because it will be inkremented during runtime because of heatingProgrammSelect = 1 */
 if (VisuInterface.heatingNewProgramm == 0)
   VisuInterface.heatingNewProgramm = MAX_HEATING_PROGRAMMS - 1;
 else
   VisuInterface.heatingNewProgramm--;
 /* restore last heating mode in visu interface after power fail /End */
 

 /* get current programm settings or create new one if neccessary /Begin */
 do
 {
  status = NewDataObject( &fDatObjCreate, &fDatObjDelete, HS_PROGRAMM1_DO_NAME, doUSRROM, 0, &programm1, sizeof(programm1), &dataObjProgramm1Inf);
 } while (status == ERR_FUB_BUSY);
 if (status != ERR_OK) VisuInterface.heatingAlarm[HEATING_PROGRAMM1_DO_ERROR] = 1;

 do
 {
  status = NewDataObject( &fDatObjCreate, &fDatObjDelete, HS_PROGRAMM2_DO_NAME, doUSRROM, 0, &programm2, sizeof(programm2), &dataObjProgramm2Inf);
 } while (status == ERR_FUB_BUSY);
 if (status != ERR_OK) VisuInterface.heatingAlarm[HEATING_PROGRAMM2_DO_ERROR] = 1;
 
 do
 {
  status = NewDataObject( &fDatObjCreate, &fDatObjDelete, HS_PROGRAMM3_DO_NAME, doUSRROM, 0, &programm3, sizeof(programm3), &dataObjProgramm3Inf);
 } while (status == ERR_FUB_BUSY);
 if (status != ERR_OK) VisuInterface.heatingAlarm[HEATING_PROGRAMM3_DO_ERROR] = 1;

 do
 {
  status = NewDataObject( &fDatObjCreate, &fDatObjDelete, HS_PROGRAMM4_DO_NAME, doUSRROM, 0, &programm4, sizeof(programm4), &dataObjProgramm4Inf);
 } while (status == ERR_FUB_BUSY);
 if (status != ERR_OK) VisuInterface.heatingAlarm[HEATING_PROGRAMM4_DO_ERROR] = 1;
 /* get current programm settings or create new one if neccessary /End */



 /* set default names for heating programms if no name yet set /Begin */
 if ( strlen(&programm1.name[0]) == 0 ) 
   strcpy( &programm1.name[0], HS_DEF_NAME_PROGRAMM_1 );

 if ( strlen(&programm2.name[0]) == 0 ) 
   strcpy( &programm2.name[0], HS_DEF_NAME_PROGRAMM_2 );

 if ( strlen(&programm3.basicProgrammInf.name[0]) == 0 ) 
   strcpy( &programm3.basicProgrammInf.name[0], HS_DEF_NAME_PROGRAMM_3 );

 if ( strlen(&programm4.basicProgrammInf.name[0]) == 0 ) 
   strcpy( &programm4.basicProgrammInf.name[0], HS_DEF_NAME_PROGRAMM_4 );
 /* set default names for heating programms if no name yet set /End */


 /* get chart for linarisation of outside temperature sensor /Begin */
 fDatObjInfo.enable = 1;
 fDatObjInfo.pName = (UDINT)CHART_LINEAR_OUTSIDE_TEMP_DO_NAME;
 
 DatObjInfo(&fDatObjInfo);										/* get schedule */
 
 if (fDatObjInfo.status == ERR_OK)								/* error ? */
   {
    dataObjLinOut.pData     = fDatObjInfo.pDatObjMem;			/* pointer to chart */
    dataObjLinOut.doIdent   = fDatObjInfo.ident;				/* ident of data object containing chart */
    dataObjLinOut.doLength  = fDatObjInfo.len;					/* length of data in data object */
    dataObjLinOut.doMemType = fDatObjInfo.MemType;				/* memory of data object containing chart */
    dataObjLinOut.doOption  = fDatObjInfo.Option;				/* additional options of data object containing chart */
   }
 else
   {
    memset( &dataObjLinOut, 0, sizeof(dataObjLinOut) );
    VisuInterface.heatingAlarm[HEATING_LIN_OUT_DO_ERROR] = 1;
   }
 /* get chart for linarisation of outside temperature sensor /End */

 oAT324cfgWord14  = AT324_ALL_CHANNELS_RESISTANCE_MEASUREMENT;	/* bit 0 and 2 of each channel confiuration set */
 cmdStartAT324cfg = 1;											/* trigger configuration of AT324 on CANIO node */
 ex270ConnectAfterInit = 0;										/* default: at power up no connection - has to be proved before AT324 configuration starts */

 /* set slider in defined position */
 if ( (HsMgrInf.manTempOffset >= -4.0) && (HsMgrInf.manTempOffset <= 4.0) )
   VisuInterface.manTempSliderIndex = (USINT)HsMgrInf.manTempOffset + 4;

 /* configure history for heating errors */
 VisuInterface.heatingAlarmGroup      = HEATING_ALARM_GROUP;
 VisuInterface.heatingAlarmFilterCtrl = VC_ALARM_FILTER_TYPE_GROUP;

 /* E-Stop animation */
 VisuInterface.eStopAnimationInf.timer      = 0;
 VisuInterface.eStopAnimationInf.duration   = 500;
 VisuInterface.eStopAnimationInf.index      = 0; 
 VisuInterface.eStopAnimationInf.nbElements = 2;
}

_CYCLIC void hs_mgrcyc(void)
{
 /* generate new minute flag */
 getTimeFlags(&CurrentTime, &newHour, &oldHour, &newMinute, &oldMinute, 0, 0);

 /* convert meassured resistance to linear temperature */
 if ( RawTempIsValid(iOutsideTemp) )
   {
    if (dataObjLinOut.pData)
      {
       /* get resistance of NTC with total resistance */
       HsMgrInf.outsideTemp = getChartValueY( 1 / ( 1/((REAL)iOutsideTemp/10) - 1/(REAL)OUTSIDE_PARALLEL_RESISTANCE ), 
                                              (xyChartElement_s *)dataObjLinOut.pData, 
                                              dataObjLinOut.doLength / sizeof(xyChartElement_s) );
      }
    else
      {
       /* if no chart found -> use linear default formular */
       HsMgrInf.outsideTemp = calcY( 1 / ( 1/((REAL)iOutsideTemp/10) - 1/(REAL)OUTSIDE_PARALLEL_RESISTANCE ),  
                                     HS_LIN_OUT_TEMP_DEF_K, 
                                     HS_LIN_OUT_TEMP_DEF_D );
      }
   }

 /* evaluate tendency of outside temperature - with hysteresis */
 if ( 
     (newMinute) && 
     ( 
      ( ((HsMgrInf.outsideTemp - oldOutsideTemp) > 0) ? (HsMgrInf.outsideTemp - oldOutsideTemp) : 
                                                        (oldOutsideTemp - HsMgrInf.outsideTemp) ) >= HS_TENDENCY_TEMP_HYSTERESIS
      )
    )
   {
    if (HsMgrInf.outsideTemp > oldOutsideTemp)
      VisuInterface.outsideTempTendency = 1;					/* temperature is rising */
    else
      VisuInterface.outsideTempTendency = 0;					/* temperature is falling */
    
    oldOutsideTemp = HsMgrInf.outsideTemp;
   }

 /* evaluate new heating mode given by user */
 applyUserInput( &VisuInterface.heatingModeSelect, 
                  MAX_HEATUNG_MODES, 
                  HEATING_MODE_AUTO,
                 &VisuInterface.heatingNewModeTimer, 
                  USER_INPUT_APPLY_DELAY, 
                 &VisuInterface.heatingNewMode, 
                 &HsMgrInf.activeHeatingMode, 
                 &VisuInterface.hsMgrInputCompletion,
                  cycT );


 /* generate new start day for programm #4 according to user input /Begin */
 if (VisuInterface.heatingPrgm4StartDaySelect == 1)
   {
    if (++programm4.startDay >= MAX_DAYS_OF_WEEK)
      programm4.startDay = SUNDAY;

    VisuInterface.heatingPrgm4StartDaySelect = 0;
   }
 /* generate new start day for programm #4 according to user input /End */

 /* generate new end day for programm #4 according to user input /Begin */
 if (VisuInterface.heatingPrgm4EndDaySelect == 1)
   {
    if (++programm4.endDay >= MAX_DAYS_OF_WEEK)
      programm4.endDay = SUNDAY;

    VisuInterface.heatingPrgm4EndDaySelect = 0;
   }
 /* generate new end day for programm #4 according to user input /End */


 /* allow programm selection only if automatic mode is selected /Begin */
 if (VisuInterface.heatingNewMode == HEATING_MODE_AUTO)
   {
    /* set programm selection visible */
    VisuInterface.heatingProgrammNameTextStatus   = VisuInterface.heatingProgrammNameTextStatus   & VC_ELEMENT_VISIBLE;
    VisuInterface.heatingProgrammNameOutPutStatus = VisuInterface.heatingProgrammNameOutPutStatus & VC_ELEMENT_VISIBLE;
    VisuInterface.heatingProgrammNameHotSpotSts   = VisuInterface.heatingProgrammNameHotSpotSts   & VC_ELEMENT_UNLOCK;

    /* evaluate new heating mode given by user */
    applyUserInput( &VisuInterface.heatingProgrammSelect, 
                     MAX_HEATING_PROGRAMMS, 
                     HEATING_PROGRAMM_1,
                    &VisuInterface.heatingNewProgrammTimer, 
                     USER_INPUT_APPLY_DELAY, 
                    &VisuInterface.heatingNewProgramm, 
                    &HsMgrInf.activeHeatingProgramm,
                    &newHeatingProgrammSelected, 
                     cycT );

    /* set new name of selected heating programm /Begin */
    if (newHeatingProgrammSelected)								/* a new programm was selected */
      {
       newHeatingProgrammSelected = 0;
       
       VisuInterface.hsMgrInputCompletion = 1;

       switch(VisuInterface.heatingNewProgramm)
       {
        case HEATING_PROGRAMM_1:
          memcpy( &VisuInterface.heatingProgrammName[0], &programm1.name[0], sizeof(VisuInterface.heatingProgrammName) );
        break;
        case HEATING_PROGRAMM_2:
          memcpy( &VisuInterface.heatingProgrammName[0], &programm2.name[0], sizeof(VisuInterface.heatingProgrammName) );
        break;
        case HEATING_PROGRAMM_3:
          memcpy( &VisuInterface.heatingProgrammName[0], &programm3.basicProgrammInf.name[0], sizeof(VisuInterface.heatingProgrammName) );
        break;
        case HEATING_PROGRAMM_4:
          memcpy( &VisuInterface.heatingProgrammName[0], &programm4.basicProgrammInf.name[0], sizeof(VisuInterface.heatingProgrammName) );
        break;
       }
      }
    /* set new name of selected heating programm /End */
   }
 else
   {
    /* set programm selection invisible */
    VisuInterface.heatingProgrammNameTextStatus   = VisuInterface.heatingProgrammNameTextStatus   | VC_ELEMENT_INVISIBLE;
    VisuInterface.heatingProgrammNameOutPutStatus = VisuInterface.heatingProgrammNameOutPutStatus | VC_ELEMENT_INVISIBLE;
    VisuInterface.heatingProgrammNameHotSpotSts   = VisuInterface.heatingProgrammNameHotSpotSts   | VC_ELEMENT_LOCK;
   }
 /* allow programm selection only if automatic mode is selected /Begin */


 switch(HsMgrInf.activeHeatingMode)
 {
  case HEATING_MODE_AUTO: 
    switch(HsMgrInf.activeHeatingProgramm)
    {
     /* triggered by time schedule - repeats daily */
     case HEATING_PROGRAMM_1:
       if (newMinute)
         HeatingHotWaterMgr(&programm1, &CurrentTime, &HsMgrInf, &HsLoopInf, &VisuInterface);
     break;

     /* triggered by time schedule - repeats daily */
     case HEATING_PROGRAMM_2:
       if (newMinute)
         HeatingHotWaterMgr(&programm2, &CurrentTime, &HsMgrInf, &HsLoopInf, &VisuInterface);
     break;

     /* triggered by exact date schedule -> within range: dropped mode */
     case HEATING_PROGRAMM_3:
       if ( (DateIsValid(&programm3.startDate, &programm3.endDate)                      == DATE_VALID) &&
            (DateWithinBeginEnd(&programm3.startDate, &programm3.endDate, &CurrentTime) == DATE_IN_RANGE) )
         {
          HsLoopInf.lcHeatingInf.enable        = 1;
          HsLoopInf.lcHeatingInf.setTempOffset = HsMgrInf.notAtHomeOffset;		/* special offset in case that date is out of the window */
          
          HsLoopInf.lcHotWaterInf.enable       = 0;								/* no hot water preparation if date is out of window */
         }
       else
         {
          if (newMinute)
            HeatingHotWaterMgr(&programm3.basicProgrammInf, &CurrentTime, &HsMgrInf, &HsLoopInf, &VisuInterface);
         }
     break;

     /* triggered by day of week repeats weekly -> within range: dropped mode */
     case HEATING_PROGRAMM_4:
       if ( DayWithinBeginEnd(&programm4.startDay, &programm4.endDay, &CurrentTime) == DAY_IN_RANGE )
         {
          HsLoopInf.lcHeatingInf.enable        = 1;
          HsLoopInf.lcHeatingInf.setTempOffset = HsMgrInf.notAtHomeOffset;	/* special offset in case that date is out of the window */
          
          HsLoopInf.lcHotWaterInf.enable       = 0;							/* no hot water preparation if date is out of window */
         }
       else
         {
          if (newMinute)
            HeatingHotWaterMgr(&programm4.basicProgrammInf, &CurrentTime, &HsMgrInf, &HsLoopInf, &VisuInterface);
         }
     break;
    } /* switch(HsMgrInf.activeHeatingProgramm) */
  break;
  
  /* heating always on - hot water according to program #1 */
  case HEATING_MAN_ON: 	
    if (newMinute)
      {
       HeatingHotWaterMgr(&programm1, &CurrentTime, &HsMgrInf, &HsLoopInf, &VisuInterface);

       /* overrule manager on heating */
       HsLoopInf.lcHeatingInf.enable        = 1;
       HsLoopInf.lcHeatingInf.setTempOffset = HsMgrInf.dayOffset + HsMgrInf.manTempOffset;
      }
  break;
  
  /* heating always lowering phase - hot water according to program #1 */
  case HEATING_MAN_DROP: 
    if (newMinute)
      {
       HeatingHotWaterMgr(&programm1, &CurrentTime, &HsMgrInf, &HsLoopInf, &VisuInterface);

       /* overrule manager on heating */
       HsLoopInf.lcHeatingInf.enable        = 1;
       HsLoopInf.lcHeatingInf.setTempOffset = HsMgrInf.nightOffset + HsMgrInf.manTempOffset;
      }
  break;
 } /* switch(HsMgrInf.activeHeatingMode) */

 

 /***********************************************************************************************************************/
 /*** SAVE DATA                                                                                                       ***/
 /***********************************************************************************************************************/

 /* save info structure after user input but only every minute /Begin */
 if ( (VisuInterface.hsMgrInputCompletion == 1) && (newMinute) )
   {
    fDatObjWrite.enable  = 1;
    fDatObjWrite.ident   = dataObjHsMgrInf.doIdent;
    fDatObjWrite.Offset  = 0;
    fDatObjWrite.pSource = (UDINT)&HsMgrInf;
    fDatObjWrite.len     = sizeof(HsMgrInf);
    
    DatObjWrite(&fDatObjWrite);
    
    if (fDatObjWrite.status != ERR_OK)
      {
       dataObjHsMgrInf.nbWrErr++;
       dataObjHsMgrInf.lstWrErr = fDatObjWrite.status;
       VisuInterface.heatingAlarm[HEATING_HS_MGR_DO_ERROR] = 1;
       ERRxwarning(fDatObjWrite.status, 0, "write HsMgrInf");
      }
     
    VisuInterface.hsMgrInputCompletion = 0;
   }
 /* save info structure after user input but only every minute /End */


 /* save heating programms after user input /Begin */
 if (VisuInterface.hsProgSave == 1) 
   {
    /* programm #1 */
    fDatObjWrite.enable  = 1;
    fDatObjWrite.ident   = dataObjProgramm1Inf.doIdent;
    fDatObjWrite.Offset  = 0;
    fDatObjWrite.pSource = (UDINT)&programm1;
    fDatObjWrite.len     = sizeof(programm1);
    
    DatObjWrite(&fDatObjWrite);
    
    if (fDatObjWrite.status != ERR_OK) 
      {
       dataObjProgramm1Inf.nbWrErr++;
       dataObjProgramm1Inf.lstWrErr = fDatObjWrite.status;
       VisuInterface.heatingAlarm[HEATING_PROGRAMM1_DO_ERROR] = 1;
       ERRxwarning(fDatObjWrite.status, 0, "write programm #1");
      }
    
 
    /* programm #2 */
    fDatObjWrite.enable  = 1;
    fDatObjWrite.ident   = dataObjProgramm2Inf.doIdent;
    fDatObjWrite.Offset  = 0;
    fDatObjWrite.pSource = (UDINT)&programm2;
    fDatObjWrite.len     = sizeof(programm2);
    
    DatObjWrite(&fDatObjWrite);
    
    if (fDatObjWrite.status != ERR_OK) 
      {
       dataObjProgramm2Inf.nbWrErr++;
       dataObjProgramm2Inf.lstWrErr = fDatObjWrite.status;
       VisuInterface.heatingAlarm[HEATING_PROGRAMM2_DO_ERROR] = 1;
       ERRxwarning(fDatObjWrite.status, 0, "write programm #2");
      }
      
    /* programm #3 */
    fDatObjWrite.enable  = 1;
    fDatObjWrite.ident   = dataObjProgramm3Inf.doIdent;
    fDatObjWrite.Offset  = 0;
    fDatObjWrite.pSource = (UDINT)&programm3;
    fDatObjWrite.len     = sizeof(programm3);
    
    DatObjWrite(&fDatObjWrite);
    
    if (fDatObjWrite.status != ERR_OK) 
      {
       dataObjProgramm3Inf.nbWrErr++;
       dataObjProgramm3Inf.lstWrErr = fDatObjWrite.status;
       VisuInterface.heatingAlarm[HEATING_PROGRAMM3_DO_ERROR] = 1;
       ERRxwarning(fDatObjWrite.status, 0, "write programm #3");
      }
      
    /* programm #4 */
    fDatObjWrite.enable  = 1;
    fDatObjWrite.ident   = dataObjProgramm4Inf.doIdent;
    fDatObjWrite.Offset  = 0;
    fDatObjWrite.pSource = (UDINT)&programm4;
    fDatObjWrite.len     = sizeof(programm4);
    
    DatObjWrite(&fDatObjWrite);
    
    if (fDatObjWrite.status != ERR_OK) 
      {
       dataObjProgramm4Inf.nbWrErr++;
       dataObjProgramm4Inf.lstWrErr = fDatObjWrite.status;
       VisuInterface.heatingAlarm[HEATING_PROGRAMM4_DO_ERROR] = 1;
       ERRxwarning(fDatObjWrite.status, 0, "write programm #4");
      }
   }

   
 /* animation - progress bar */
 if (VisuInterface.hsProgSave == 1)
   {
    VisuInterface.progressBarInf.index = 1;											/* start progress bar */
    VisuInterface.hsProgSave = 0;									
   }
 else if ( (VisuInterface.progressBarInf.index > 0) && 
           (VisuInterface.progressBarInf.index < VisuInterface.progressBarInf.nbElements - 1) ) 									/* start progress bar if save has been actived */
   {
    if (VisuInterface.progressBarInf.timer >= VisuInterface.progressBarInf.duration)
      {
       VisuInterface.progressBarInf.timer = 0;
       VisuInterface.progressBarInf.index++;										/* next bitmap to increase progress bar */
      }
    else
      {
       VisuInterface.progressBarInf.timer += cycT;
      }
   }
 /* save heating programms after user input /End */



 /***********************************************************************************************************************/
 /*** EMERGENCY STOP HANDLING (overrides everything!)                                                                 ***/
 /***********************************************************************************************************************/
 if ( (VisuInterface.heatingAlarm[HEATING_FIRING_TEMPERATURE_TOO_HIGH] == 1) ||
      (VisuInterface.heatingAlarm[HEATING_BOILER_TEMPERATURE_TOO_HIGH] == 1) ||
      (VisuInterface.heatingAlarm[HEATING_NO_CONNECTION_CANIO]         == 1) ||
      (VisuInterface.heatingEstop == 1) )
   {
    HsFireInf.eStop = 1;
    HsLoopInf.eStop = 1;
    VisuInterface.heatingAlarm[HEATING_ESTOP] = 1;
   }
 else if ( (VisuInterface.heatingAlarm[HEATING_FIRING_TEMPERATURE_TOO_HIGH] == 0) &&
           (VisuInterface.heatingAlarm[HEATING_BOILER_TEMPERATURE_TOO_HIGH] == 0) &&
           (VisuInterface.heatingAlarm[HEATING_NO_CONNECTION_CANIO]         == 0) &&
           (VisuInterface.heatingEstop == 0) )
   {
    HsFireInf.eStop = 0;
    HsLoopInf.eStop = 0;
    VisuInterface.heatingAlarm[HEATING_ESTOP] = 0;
   }


 /***********************************************************************************************************************/
 /*** VISU INTERFACE                                                                                                  ***/
 /***********************************************************************************************************************/

 /* picture "30.0 Detailinformation" */
 /* set manual temperature overide accoding to user input at slider */
 if (VisuInterface.manTempSliderIndex != VisuInterface.oldManTempSliderIndex)
   {
    HsMgrInf.manTempOffset              = (REAL)VisuInterface.manTempSliderIndex - 4;	/* convert slider postion 0...8 to temperature -4...+4 */
    VisuInterface.oldManTempSliderIndex = VisuInterface.manTempSliderIndex;
    VisuInterface.hsMgrInputCompletion  = 1;
   }


 /* animate E-Stop sign if user pressed E-Stop "button" /Begin */
 if (VisuInterface.heatingEstop)
   {
    if (VisuInterface.eStopAnimationInf.timer >= VisuInterface.eStopAnimationInf.duration)
      {
       VisuInterface.eStopAnimationInf.timer = 0;

       if (++VisuInterface.eStopAnimationInf.index >= VisuInterface.eStopAnimationInf.nbElements)
         VisuInterface.eStopAnimationInf.index = 0;
      }
    else
      {
       VisuInterface.eStopAnimationInf.timer += cycT;
      }
  }
else
  {
   VisuInterface.eStopAnimationInf.timer = 0;
   VisuInterface.eStopAnimationInf.index = 0;
  }
 /* animate E-Stop sign if user pressed E-Stop "button" /End */

 if (VisuInterface.curPictNr != oldPictNr)
   {
    VisuInterface.progressBarInf.index = 0;											/* progress bar is invisble */
   }




 /***********************************************************************************************************************/
 /*** EX270 LIFE GUARDING : Read Operating System Version                                                             ***/
 /***********************************************************************************************************************/
 /* cyclic check and configuration */
 if (newMinute) 
   cmdStartEX270lifeGuarding = 1;

 switch(sEX270lifeGuarding)
 {
  case sWAIT_START_LIFE_GUARDING:
    if (cmdStartEX270lifeGuarding == 1)
      sEX270lifeGuarding = sREAD_OS_VERSION;
  break;
  
  case sREAD_OS_VERSION:
    cmdBuffer[0] = 0;															/* free number in range 0-126 */
    cmdBuffer[1] = CANIO_READ_OS_VERSION;										/* 16 ...read operation system version */
    cmdBuffer[2] = 0;															/*  0 ...not used */
    cmdBuffer[3] = 0;															/*  0 ...not used */    

    cmdBuffer[4] = 0;															/*  0 ...not used */
    cmdBuffer[5] = 0;															/*  0 ...not used */
    cmdBuffer[6] = 0;															/*  0 ...not used */
    cmdBuffer[7] = 0;															/*  0 ...not used */

    fCANIOcmd.enable = 1;
    fCANIOcmd.busnr  = HEATING_EX270_BUS_NUMBER;
    fCANIOcmd.nodenr = HEATING_EX270_NODE_NUMBER;
    fCANIOcmd.cmd    = (UDINT)&cmdBuffer[0];
    fCANIOcmd.res    = (UDINT)&resBuffer[0];

    CANIOcmd(&fCANIOcmd);
    
    if (fCANIOcmd.status != ERR_FUB_BUSY)										/* all done,... */
      {
       /* if node is not responding or not (yet) active try again */
       if ( (fCANIOcmd.status == 8985) || (fCANIOcmd.status == 8979) )
         {
          VisuInterface.heatingAlarm[HEATING_NO_CONNECTION_CANIO] = 1;
          cmdStartAT324cfg      = 1;											/* reinitialize AT324 once connection is reestablished */
         }
       else
         {
          VisuInterface.heatingAlarm[HEATING_NO_CONNECTION_CANIO] = 0;
          ex270ConnectAfterInit = 1;
         }
       
       cmdStartEX270lifeGuarding = 0;											/* automatic retry every minute */
       sEX270lifeGuarding = sWAIT_START_LIFE_GUARDING;
      }
  break;
 }



 /***********************************************************************************************************************/
 /*** AT324 CONFIGURATION                                                                                             ***/
 /***********************************************************************************************************************/
 /* cyclic check and configuration */
 switch(sAT324configuration)
 {
  case sWAIT_START_CONFIGURATION:
    if ( (cmdStartAT324cfg == 1)                                        && 
         (VisuInterface.heatingAlarm[HEATING_NO_CONNECTION_CANIO] == 0) &&
         (ex270ConnectAfterInit == 1) )
      {
       sAT324configuration = sWRITE_CONFIGWORD_14;
      }
  break;
  
  case sWRITE_CONFIGWORD_14:
    cmdBuffer[0] = 0;															/* free number in range 0-126 */
    cmdBuffer[1] = CANIO_WRITE_PARAMETER;										/* 11 ...write parameter */
    cmdBuffer[2] = CANIO_PARAMETER_FOR_SCREW_IN_MODULE;							/* 28 ...parameter for screw in module */
    cmdBuffer[3] = 0;															/*  0 ...screw-in module 1 and 2 */    

    cmdBuffer[4] = (USINT)(oAT324cfgWord14 >> 8);								/* High Byte of configword 14 / slot 1 */
    cmdBuffer[5] = (USINT)oAT324cfgWord14;										/* Low  Byte of configword 14 / slot 1 */

    cmdBuffer[6] = (USINT)(oAT324cfgWord14 >> 8);								/* High Byte of configword 14 / slot 2 */
    cmdBuffer[7] = (USINT)oAT324cfgWord14;										/* Low  Byte of configword 14 / slot 2 */

    fCANIOcmd.enable = 1;
    fCANIOcmd.busnr  = HEATING_EX270_BUS_NUMBER;
    fCANIOcmd.nodenr = HEATING_EX270_NODE_NUMBER;
    fCANIOcmd.cmd    = (UDINT)&cmdBuffer[0];
    fCANIOcmd.res    = (UDINT)&resBuffer[0];

    CANIOcmd(&fCANIOcmd);
    
    if (fCANIOcmd.status != ERR_FUB_BUSY)										/* ignore errors at this possition -> will be done anyway in next step */
      sAT324configuration = sACTIVATE_PARAMETERS;
  break;
  
  case sACTIVATE_PARAMETERS:
    cmdBuffer[0] = 0;															/* free number in range 0-126 */
    cmdBuffer[1] = CANIO_ACTIVATE_PARAMETER;									/* 12 ...activate parameter */
    cmdBuffer[2] = 0;															/* not used */
    cmdBuffer[3] = 0;															/* no block transfer */    

    cmdBuffer[4] = 0;															/* not used */
    cmdBuffer[5] = 0;															/* not used */
    cmdBuffer[6] = 0;															/* not used */
    cmdBuffer[7] = 0;															/* not used */

    fCANIOcmd.enable = 1;
    fCANIOcmd.busnr  = HEATING_EX270_BUS_NUMBER;
    fCANIOcmd.nodenr = HEATING_EX270_NODE_NUMBER;
    fCANIOcmd.cmd    = (UDINT)&cmdBuffer[0];
    fCANIOcmd.res    = (UDINT)&resBuffer[0];

    CANIOcmd(&fCANIOcmd);

    if (fCANIOcmd.status != ERR_FUB_BUSY)										/* all done,... */
      {
       /* if node is not responding or not (yet) set alarm and keep trying if possible */
       if ( (fCANIOcmd.status == 8985) || (fCANIOcmd.status == 8979) )
         {
          VisuInterface.heatingAlarm[HEATING_NO_CONNECTION_CANIO] = 1; 
         }
       else
         {
          cmdStartAT324cfg = 0;
          VisuInterface.heatingAlarm[HEATING_NO_CONNECTION_CANIO] = 0; 

          /* command to initialize moving average buffer for outside temperature */
          if (HsEcoInf.outsideTemp.cmdMovAvBuffer == MOV_AV_PREPARED)
            HsEcoInf.outsideTemp.cmdMovAvBuffer = MOV_AV_DO_INIT;
         }
       
       sAT324configuration = sWAIT_START_CONFIGURATION;
      }
  break;
 }


 /***********************************************************************************************************************/
 /*** ALARM GENERATION                                                                                                ***/
 /***********************************************************************************************************************/
 /* outside temperature sensor */
 if ( (RawTempIsValid(iOutsideTemp) == 0) && (VisuInterface.heatingAlarm[HEATING_NO_CONNECTION_CANIO] == 0) )
   VisuInterface.heatingAlarm[HEATING_OUTSIDE_TEMPERATUR_SENSOR_BROKEN] = 1;
 else
   VisuInterface.heatingAlarm[HEATING_OUTSIDE_TEMPERATUR_SENSOR_BROKEN] = 0;

 /* heating on/off */
 if (HsLoopInf.lcHeatingInf.enable == 1)
   VisuInterface.messageAlarm[HEATING_HEATING_ON] = 1;
 else
   VisuInterface.messageAlarm[HEATING_HEATING_ON] = 0;

 /* hot water managment on/off */
 if (HsLoopInf.lcHotWaterInf.enable == 1)
   VisuInterface.messageAlarm[HEATING_HOT_WATER_ON] = 1;
 else
   VisuInterface.messageAlarm[HEATING_HOT_WATER_ON] = 0;


 oldPictNr = VisuInterface.curPictNr;  
}














