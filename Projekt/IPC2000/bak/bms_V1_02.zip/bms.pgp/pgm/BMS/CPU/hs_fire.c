/*********************************************************************************************
*  Copyright: 2002 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Managment System                                                    *
*    Purpose    controling firing appliance of heating system                                *
*                                                                                            *
*    Filename   hs_fire.c                                                                    *
*--------------------------------------------------------------------------------------------*
*  Description :                                                                             *
*    controling firing device of heating system                                              *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  Structures  :                                                                             *
*   hsFireInf_s                                                                              *
*             .eStop                     starts emergency stop handling immediately          *
*             .minSetTemp                lower limit of set temperature                      *
*             .maxSetTemp                upper limit of set temperature                      *
*             .actTempHyst               permitable hysteresis of actual temperature         *
*             .firingInf_s                                                                   *
*                        .enable         enables/disables internal control of firing device  *
*                        .lcOutput       output of 2 point closed loop controler             *
*                        .setTemp        set temperature for firing                          *
*                        .actTemp        actual temperature for firing                       *
*                        .runTime        actual runtime of firing device                     *
*                        .minRunTime     minimum runtime of firing device                    *
*                        .cmdService     service mode of firing components:                  *
*                                          0 ...no service mode of firing device             *
*                                          1 ...firing device off for service operation      *
*                                          2 ...firing device on for service operation       *
*             .boilerInf_s                                                                   *
*                        .enable         enables/disables internal control of boiler         *
*                        .lcOutput       output of 2 point closed loop controler             *
*                        .setTemp        set temperature for boiler                          *
*                        .actTemp        actual temperature for boiler                       *
*                        .lcOutput       output of 2 point closed loop controler             *
*                        .delayTime      actual delay time of boiler pump                    *
*                        .delayTimeOut   delay timeout of boiler pump                        *
*                        .minDutyCycle   minimum duty cycle within boiler pump must be       *
*                                        activated at least once                             *
*                        .offDutyTimer   counts as long as boiler pump is switched off       *
*                                        will be reseted as soon as pump is switched on      *
*                        .dutyRequest    request to switch on boiler pump                    *
*                        .cmdService     service mode of boiler components:                  *
*                                          0 ...no service mode of firing device             *
*                                          1 ...boiler pump off for service operation        *
*                                          2 ...boiler pump on for service operation         *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  History :                                                                                 *
*  Version       Datum         Autor                                                         *
*  01.00         16.02.02      W. Paulin     Created                                         *
*  01.01         19.10.02      W. Paulin     ECO functions implemented                       *
*  01.02         07.12.02      W. Paulin     RawTempIsValid() implemented                    *
*                                            no acknowlege of high temperature necessary     *
*                                            switch on firing device in closed loop operation*
*                                            only if temperature sensors are O.K.            * 
*  01.03         24.12.02      W. Paulin     separate outputs for each lc2Point()            *
*********************************************************************************************/

#include <bur/plctypes.h>
#include <bms_gn.h>
#include <bms_io.h>


_LOCAL RTInfo_typ       fRTInfo;
_LOCAL UDINT			cycT;
_LOCAL USINT 			newMinute;
_LOCAL USINT 			oldMinute;
_LOCAL dataObjInf_s 	dataObjLinFire;
_LOCAL DatObjInfo_typ	fDatObjInfo;


_INIT void hs_fireini(void)
{
 fRTInfo.enable = 1; 
 RTInfo(&fRTInfo);
 
 cycT = fRTInfo.cycle_time / 1000;					/* transform cycle time us -> ms */

 /* get chart for linarisation of temperature sensors firing device, boiler and flow pipe /Begin */
 fDatObjInfo.enable = 1;
 fDatObjInfo.pName = (UDINT)CHART_LINEAR_FIRING_TEMP_DO_NAME;
 
 DatObjInfo(&fDatObjInfo);										/* get linearisation data object */
 
 if (fDatObjInfo.status == ERR_OK)								/* error ? */
   {
    dataObjLinFire.pData     = fDatObjInfo.pDatObjMem;			/* pointer to chart */
    dataObjLinFire.doIdent   = fDatObjInfo.ident;				/* ident of data object containing chart */
    dataObjLinFire.doLength  = fDatObjInfo.len;					/* length of data in data object */
    dataObjLinFire.doMemType = fDatObjInfo.MemType;				/* memory of data object containing chart */
    dataObjLinFire.doOption  = fDatObjInfo.Option;				/* additional options of data object containing chart */
   }
 else
   {
    memset( &dataObjLinFire, 0, sizeof(dataObjLinFire) );
    VisuInterface.heatingAlarm[HEATING_LIN_FIRE_DO_ERROR] = 1;
   }
 /* get chart for linarisation of temperature sensors firing device, boiler and flow pipe /End */

 
 HsFireInf.firingInf.enable				= 0;
 HsFireInf.firingInf.cmdService  		= SERVICE_MODE_OFF;
 HsFireInf.boilerInf.enable				= 0;
 HsFireInf.boilerInf.cmdService  		= SERVICE_MODE_OFF;

 HsFireInf.minSetTemp  					= HS_FIRING_MIN_SET_TEMP;
 HsFireInf.maxSetTemp  					= HS_FIRING_MAX_SET_TEMP;
 HsFireInf.actTempHyst 					= HS_FIRING_ACT_TEMP_HYSTERESIS;
 HsFireInf.firingInf.minRunTime  		= HS_FIRING_MIN_RUNTIME;
 HsFireInf.boilerInf.delayTimeOut 		= HS_BOILER_PUMP_DELAY_TIME;
 HsFireInf.boilerInf.minDutyCycle 		= HS_BOILER_PUMP_MIN_DUTY_CYCLE;
}


_CYCLIC void hs_firecyc(void)
{
 /* generate new minute flag */
 getTimeFlags(&CurrentTime, 0, 0, &newMinute, &oldMinute, 0, 0);

 /* convert meassured resistance to linear temperature /Begin */
 /* firing device */
 if ( RawTempIsValid(iFiringTemp) ) 
   {
    if (dataObjLinFire.pData)
      {
       HsFireInf.firingInf.actTemp = getChartValueY( 1 / ( 1/((REAL)iFiringTemp/10) - 1/(REAL)FIRING_PARALLEL_RESISTANCE ), 
                                                     (xyChartElement_s *)dataObjLinFire.pData, 
                                                     dataObjLinFire.doLength / sizeof(xyChartElement_s) );
      }   
    else
      {
       /* if no chart found -> use linear default formular */
       HsFireInf.firingInf.actTemp  = calcY( 1 / ( 1/((REAL)iFiringTemp/10) - 1/(REAL)FIRING_PARALLEL_RESISTANCE ),
                                             HS_LIN_FIRE_TEMP_DEF_K, 
                                             HS_LIN_FIRE_TEMP_DEF_D );
      }
   }


 /* boiler */
 if ( RawTempIsValid(iBoilerTemp) )
   {
    if (dataObjLinFire.pData)
      {
       HsFireInf.boilerInf.actTemp = getChartValueY( 1 / ( 1/((REAL)iBoilerTemp/10) - 1/(REAL)BOILER_PARALLEL_RESISTANCE ),  
                                                     (xyChartElement_s *)dataObjLinFire.pData, 
                                                     dataObjLinFire.doLength / sizeof(xyChartElement_s) );
      }   
    else
      {
       /* if no chart found -> use linear default formular */
       HsFireInf.boilerInf.actTemp  = calcY( 1 / ( 1/((REAL)iBoilerTemp/10) - 1/(REAL)BOILER_PARALLEL_RESISTANCE ),  
                                             HS_LIN_FIRE_TEMP_DEF_K, 
                                             HS_LIN_FIRE_TEMP_DEF_D );
      }
   }
  /* convert meassured resistance to linear temperature /End */
  
 
 /***********************************************************************************************************************/
 /*** TWO POINT CONTROL OF FIRING DEVICE AND BOILER                                                                   ***/
 /***********************************************************************************************************************/
 /* control firing device /Begin */  
 if (HsFireInf.boilerInf.enable)					/* enable of boiler wins -> usually higher temperatures for hot water -> automatic regulation for heating system done by mixer */
   {
    /* limit set temperatur to upper and lower limits */
    lcLimit(&HsFireInf.boilerInf.setTemp, HsFireInf.minSetTemp, HsFireInf.maxSetTemp);

    /* 2-point controller */
    lc2Point(HsFireInf.boilerInf.setTemp, HsFireInf.boilerInf.actTemp, HsFireInf.actTempHyst, HsFireInf.actTempHyst, &HsFireInf.boilerInf.lcOutput);
    
    /* check if firing device is needed */ 
    if (HsFireInf.boilerInf.lcOutput > 0)
      {
       /* heat up firing device higher then needed -> energie has to be transported through water pipes to boiler */
       HsFireInf.firingInf.setTemp = HsFireInf.boilerInf.setTemp + HS_FIRING_MIN_DELTA_TEMP;
       lcLimit(&HsFireInf.firingInf.setTemp, HsFireInf.minSetTemp, HsFireInf.maxSetTemp);
       
       /* 2-point controller */
       lc2Point(HsFireInf.firingInf.setTemp, HsFireInf.firingInf.actTemp, HsFireInf.actTempHyst, HsFireInf.actTempHyst, &HsFireInf.firingInf.lcOutput);
      }
   }
 else if (HsFireInf.firingInf.enable)
   {
    /* limit set temperature to upper and lower limits */
    lcLimit(&HsFireInf.firingInf.setTemp, HsFireInf.minSetTemp, HsFireInf.maxSetTemp);
       
    /* 2-point controller */
    lc2Point(HsFireInf.firingInf.setTemp, HsFireInf.firingInf.actTemp, HsFireInf.actTempHyst, HsFireInf.actTempHyst, &HsFireInf.firingInf.lcOutput);
   }
 else
   {
    HsFireInf.firingInf.lcOutput = 0;
   }
       
 /* apply controller output to digital output */     
 if (HsFireInf.firingInf.lcOutput > 0)
   oFiring = HS_SWITCH_ON;
 else  
   oFiring = HS_SWITCH_OFF;
 /* control firing device /End */  


 /***********************************************************************************************************************/
 /*** GARANTEE MINIMUM RUNTIME OF FIRING DEVICE                                                                       ***/
 /***********************************************************************************************************************/
 if (HsFireInf.firingInf.runTime > 0)							/* firing startet already -> keep on running for a while */
   {
    if (HsFireInf.firingInf.runTime < HsFireInf.firingInf.minRunTime)
      {
       HsFireInf.firingInf.runTime += newMinute;
       oFiring = HS_SWITCH_ON;									/* override other output settings as long as firing device was not running a minimal time */
      }
   }
 else if (oFiring == HS_SWITCH_ON)								/* increase initially runtime once firing startet */
   {
    HsFireInf.firingInf.runTime += newMinute;
   }
 else if (oFiring == HS_SWITCH_OFF)								/* reset runtime if firing has been switched off */
   {
    HsFireInf.firingInf.runTime = 0;
   }
 

 /* switch of firing device in closed loop operation if temperature sensors are broken */
 if ( (VisuInterface.heatingAlarm[HEATING_BOILER_TEMPERATUR_SENSOR_BROKEN] == 1) ||
      (VisuInterface.heatingAlarm[HEATING_FIRING_TEMPERATUR_SENSOR_BROKEN] == 1) )
   {
    oFiring = HS_SWITCH_OFF;
   }
 

 
 /***********************************************************************************************************************/
 /*** BOILER PUMP CONTROL                                                                                             ***/
 /***********************************************************************************************************************/
 /* switch boiler pump on if hot water boiler control is active and firing is hoter than boiler or if pump was not running since some time */
 if ( ((HsFireInf.boilerInf.enable) && (HsFireInf.firingInf.actTemp > HsFireInf.boilerInf.actTemp)) || 
      (HsFireInf.boilerInf.dutyRequest) )
   {
    oBoilerPump = HS_SWITCH_ON;
    HsFireInf.boilerInf.delayTime   = 0;
    HsFireInf.boilerInf.dutyRequest = 0;
   }

 /* switch boiler pump off after certain delay time */
 if (HsFireInf.boilerInf.delayTime >= HsFireInf.boilerInf.delayTimeOut) 
   oBoilerPump = HS_SWITCH_OFF;
 else
   HsFireInf.boilerInf.delayTime += newMinute; 


 /* take care that boiler pump is running frequently /Begin */
 if (oBoilerPump == HS_SWITCH_ON)
   HsFireInf.boilerInf.offDutyTimer = 0;
 else
   HsFireInf.boilerInf.offDutyTimer += newMinute;
 
 if (HsFireInf.boilerInf.offDutyTimer >= HsFireInf.boilerInf.minDutyCycle)
   HsFireInf.boilerInf.dutyRequest = 1;
 /* take care that boiler pump is running frequently /End */

 /* generate warning message for visualization /Begin */
 if (HsFireInf.boilerInf.dutyRequest)
   VisuInterface.messageAlarm[HEATING_BOILER_PUMP_DUTY_REQUEST] = 1;
 else if (oBoilerPump == 0)
   VisuInterface.messageAlarm[HEATING_BOILER_PUMP_DUTY_REQUEST] = 0;
 /* generate warning message for visualization /End */
 

 /***********************************************************************************************************************/
 /*** SERVICE OPERATION - FIRING DEVICE                                                                                              ***/
 /***********************************************************************************************************************/
 /* evaluate service command given by user */
 applyUserInput( &VisuInterface.hsFiringSelect, 
                  MAX_SERVICE_MODES, 
                  SERVICE_MODE_OFF,
                 &VisuInterface.hsFiringModeTimer, 
                  USER_INPUT_APPLY_DELAY, 
                 &VisuInterface.hsNewFiringMode, 
                 &HsFireInf.firingInf.cmdService, 
                  0,
                  cycT );

 if (HsFireInf.firingInf.cmdService == SERVICE_MODE_SWITCH_ON)
   oFiring = HS_SWITCH_ON;
 else if (HsFireInf.firingInf.cmdService == SERVICE_MODE_SWITCH_OFF)
   oFiring = HS_SWITCH_OFF;



 /***********************************************************************************************************************/
 /*** SERVICE OPERATION - BOILER PUMP                                                                                 ***/
 /***********************************************************************************************************************/
 /* evaluate service command given by user */
 applyUserInput( &VisuInterface.hsBoilerPumpSelect, 
                  MAX_SERVICE_MODES, 
                  SERVICE_MODE_OFF,
                 &VisuInterface.hsBoilerPumpModeTimer, 
                  USER_INPUT_APPLY_DELAY, 
                 &VisuInterface.hsNewBoilerPumpMode, 
                 &HsFireInf.boilerInf.cmdService, 
                  0,
                  cycT );

 if (HsFireInf.boilerInf.cmdService == SERVICE_MODE_SWITCH_ON)
   oBoilerPump = HS_SWITCH_ON;
 else if (HsFireInf.boilerInf.cmdService == SERVICE_MODE_SWITCH_OFF)
   oBoilerPump = HS_SWITCH_OFF;
 


 /***********************************************************************************************************************/
 /*** FIRING STATISTICS                                                                                               ***/
 /***********************************************************************************************************************/
 if ( (oFiring == 1) && (newMinute == 1) )	
   BMSstatistic.heatingStatistic.onTimeFiring++;				/* statistics: on time of firing device */

 if ( (oBoilerPump == 1) && (newMinute == 1) )	
   BMSstatistic.heatingStatistic.onTimeBoilerPump++;			/* statistics: on time of boiler pump */
 

 
 /***********************************************************************************************************************/
 /*** ALARM GENERATION                                                                                                ***/
 /***********************************************************************************************************************/
 /* ALARM: firing sensor broken */
 if ( (RawTempIsValid(iFiringTemp) == 0) && (VisuInterface.heatingAlarm[HEATING_NO_CONNECTION_CANIO] == 0) )
   VisuInterface.heatingAlarm[HEATING_FIRING_TEMPERATUR_SENSOR_BROKEN] = 1;
 else
   VisuInterface.heatingAlarm[HEATING_FIRING_TEMPERATUR_SENSOR_BROKEN] = 0;

 /* ALARM: firing temperature */
 if (HsFireInf.firingInf.actTemp > HS_FIRING_ALARM_TEMP)
   VisuInterface.heatingAlarm[HEATING_FIRING_TEMPERATURE_TOO_HIGH] = 1;
 else 
   VisuInterface.heatingAlarm[HEATING_FIRING_TEMPERATURE_TOO_HIGH] = 0;
 
 /* ALARM: boiler sensor broken */
 if ( (RawTempIsValid(iBoilerTemp) == 0) && (VisuInterface.heatingAlarm[HEATING_NO_CONNECTION_CANIO] == 0) )
   VisuInterface.heatingAlarm[HEATING_BOILER_TEMPERATUR_SENSOR_BROKEN] = 1;
 else
   VisuInterface.heatingAlarm[HEATING_BOILER_TEMPERATUR_SENSOR_BROKEN] = 0;

 /* ALARM: boiler temperature */
 if (HsFireInf.boilerInf.actTemp > HS_FIRING_ALARM_TEMP)
   VisuInterface.heatingAlarm[HEATING_BOILER_TEMPERATURE_TOO_HIGH] = 1;
 else
   VisuInterface.heatingAlarm[HEATING_BOILER_TEMPERATURE_TOO_HIGH] = 0;
 

 /***********************************************************************************************************************/
 /*** EMERGENCY STOP HANDLING (overrides everything!)                                                                 ***/
 /***********************************************************************************************************************/
 if (HsFireInf.eStop)
   {
    oFiring     = HS_SWITCH_OFF;
    oBoilerPump = HS_SWITCH_OFF;
   }
}