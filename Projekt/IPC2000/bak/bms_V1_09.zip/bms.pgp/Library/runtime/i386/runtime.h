/****************************************************************************/
/*                                                                          */
/*  runtime.h                                                               */
/*                                                                          */
/*      Automation Studio                                                   */
/*  Copyright Bernecker&Rainer 1998-1999                                    */
/*                                                                          */
/****************************************************************************/

/* This library does not contain code for C programming */
