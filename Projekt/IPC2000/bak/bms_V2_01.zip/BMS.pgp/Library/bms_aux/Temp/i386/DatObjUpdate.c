#include	<bur\plc.h>

void DatObjUpdate(void) {};
