/* Automation Studio Generated Header File, Format Version 1.00 */
/* do not change */
#ifndef VCTREND_H_
#define VCTREND_H_
#define _WEAK	__attribute__((__weak__))

#include <bur/plc.h>



/* Constants */


/* Datatypes */


/* Datatypes of function blocks */


/* Prototyping of functions and function blocks */
unsigned long TR_cDrawInit(unsigned long pTrendID);
unsigned long TR_cSingleShot(unsigned long pTrendID);
unsigned long TR_cDraw(unsigned long pTrendID);
unsigned long TR_sDraw(unsigned long pTrendID);
unsigned long TR_redraw(unsigned long pTrendID);
unsigned long TR_cRecord(unsigned long pTrendID);
unsigned long TR_init(unsigned long* pTrendID, unsigned long vc_handle, unsigned short maxCurves, unsigned short nbValues, unsigned short left, unsigned short top, unsigned short samplesWidth, unsigned short height, unsigned short gridX, unsigned short gridY, unsigned short gridColor, plcbit* gridEnable, unsigned short backColor, unsigned short foreColor);
unsigned long TR_addCurve(unsigned long pTrendID, signed long* pLiveVal, unsigned long* ppData, plcbit* enable, signed long minY, signed long maxY, unsigned short color);



#endif /* VCTREND_H_ */