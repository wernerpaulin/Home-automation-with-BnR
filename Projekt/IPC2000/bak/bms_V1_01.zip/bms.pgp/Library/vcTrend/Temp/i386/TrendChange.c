#include	<bur\plc.h>

void TrendChange(void) {};
