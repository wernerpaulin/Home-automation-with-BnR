#include	<bur\plc.h>

_FUNDEF(TrendDrwSingle);
