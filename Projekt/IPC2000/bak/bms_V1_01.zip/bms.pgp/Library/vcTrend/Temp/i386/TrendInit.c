#include	<bur\plc.h>

void TrendInit(void) {};
