#include	<bur\plc.h>

void TR_cDrawInit(void) {};
