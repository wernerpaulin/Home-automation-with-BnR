#include	<bur\plc.h>

void TR_init(void) {};
