#include	<bur\plc.h>

void TR_cDraw(void) {};
