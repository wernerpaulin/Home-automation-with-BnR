#include <vctrend.h>
#include <bur/plctypes.h>
#include <sys_lib.h>
#include <visapi.h>

typedef struct
{
	DINT	minY;
	DINT	maxY;
	UINT	color;
	UINT	fillUINT;
	DINT*	pLiveVal;
	DINT*	pData;
	BOOL*	enable;
} curveInfo_typ;

typedef struct
{
	UINT	maxCurves;
	UINT	nbCurves;
	UINT	nbValues;
	UINT	left;
	UINT	top;
	UINT	width;
	UINT	height;
	UINT	gridX;
	UINT	gridY;
	UINT	gridColor;
	UDINT	samplesWidth;
	UINT	ixQueue;
	UINT	backColor;
	UINT	foreColor;
	UINT	fillUINT;
	UDINT	vc_handle;
	BOOL*	gridEnable;
	curveInfo_typ*	pCurveInfo;
} trendInfo_typ;

UDINT TR_init(UDINT* pTrendID, UDINT vc_handle, UINT maxCurves, UINT nbValues, UINT left, UINT top, UINT samplesWidth, UINT height, UINT gridX, UINT gridY, UINT gridColor, BOOL* gridEnable, UINT backColor, UINT foreColor)
{
	UDINT memlen;
	UDINT status;
	trendInfo_typ* pTrendInfo;

	if (vc_handle == 0) {
		return (2);
	}
	
	if (maxCurves == 0) {
		return (3);
	}
	
	if (nbValues <= 1) {
		return (4);
	}
	
	memlen = sizeof(trendInfo_typ) + ((maxCurves - 1) * sizeof(curveInfo_typ*));
	status = TMP_alloc(memlen, (void*)pTrendID);
	if (status != 0) {
		return (status);
	}
	memset((void*)*pTrendID, 0, memlen);
	pTrendInfo = (trendInfo_typ*)*pTrendID;
	pTrendInfo->maxCurves = maxCurves;
	pTrendInfo->nbCurves = 0;
	pTrendInfo->nbValues = nbValues;
	pTrendInfo->left = left;
	pTrendInfo->top = top;
	pTrendInfo->width = samplesWidth * (nbValues - 1);
	pTrendInfo->height = height;
	pTrendInfo->gridX = gridX;
	pTrendInfo->gridY = gridY;
	pTrendInfo->gridColor = gridColor;
	pTrendInfo->samplesWidth = samplesWidth;
	pTrendInfo->ixQueue = nbValues - 1;
	pTrendInfo->backColor = backColor;
	pTrendInfo->foreColor = foreColor;
	pTrendInfo->vc_handle = vc_handle;
	pTrendInfo->gridEnable = gridEnable;
	return (0);
}

UDINT TR_addCurve(UDINT pTrendID, DINT* pLiveVal, UDINT* ppData, BOOL* enable, DINT minY, DINT maxY, UINT color)
{
	UDINT status;
	trendInfo_typ* pTrendInfo;
	curveInfo_typ* pCurveInfo;
	
	pTrendInfo = (trendInfo_typ*)pTrendID;
	
	if (pTrendInfo->nbCurves < pTrendInfo->maxCurves) {
		status = TMP_alloc(sizeof(curveInfo_typ), (void*)(&(pTrendInfo->pCurveInfo) + pTrendInfo->nbCurves));
		if (status != 0) {
			return (status);
		}
		
		pCurveInfo = &(pTrendInfo->pCurveInfo)[pTrendInfo->nbCurves];
		pCurveInfo = *(&(pTrendInfo->pCurveInfo) + pTrendInfo->nbCurves);
		
		
		if (ppData == 0) {
			if (pLiveVal == 0) {
				return (3);
			}
			else {
				pCurveInfo->minY = minY;
				pCurveInfo->maxY = maxY;
				pCurveInfo->color = color;
				pCurveInfo->pLiveVal = pLiveVal;
				pCurveInfo->enable = enable;
				
				status = TMP_alloc(pTrendInfo->nbValues * sizeof(DINT), (void*)&(pCurveInfo->pData));
				if (status != 0) {
					return (status);
				}
				else {
					pTrendInfo->nbCurves = pTrendInfo->nbCurves + 1;
					return (0);
				}	
			}
		}
		else {
			if (*ppData == 0) {
				pCurveInfo->minY = minY;
				pCurveInfo->maxY = maxY;
				pCurveInfo->color = color;
				if (pLiveVal == 0) {
					pCurveInfo->pLiveVal = 0;
				}
				else {
					pCurveInfo->pLiveVal = pLiveVal;
				}
				
				pCurveInfo->enable = enable;

				status = TMP_alloc(pTrendInfo->nbValues * sizeof(DINT), (void*)&(pCurveInfo->pData));
				if (status != 0) {
					return (status);
				}
				else {
					*ppData = (UDINT)pCurveInfo->pData;
					pTrendInfo->nbCurves = pTrendInfo->nbCurves + 1;
					return (0);
				}	
			}
			else
			{
				pCurveInfo->minY = minY;
				pCurveInfo->maxY = maxY;
				pCurveInfo->color = color;
				if (pLiveVal == 0) {
					pCurveInfo->pLiveVal = 0;
				}
				else {
					pCurveInfo->pLiveVal = pLiveVal;
				}
				pCurveInfo->enable = (void*)enable;
				pCurveInfo->pData = (void*)*ppData;
				pTrendInfo->nbCurves = pTrendInfo->nbCurves + 1;
				return (0);
			}
		}
	}
	else {
		return (2);
	}
}

UDINT TR_cRecord(UDINT pTrendID)
{
	trendInfo_typ* pTrendInfo;
	curveInfo_typ* pCurveInfo;
	
	UINT i;
	
	pTrendInfo = (trendInfo_typ*)pTrendID;

	pTrendInfo->ixQueue = pTrendInfo->ixQueue + 1;
	if (pTrendInfo->ixQueue == pTrendInfo->nbValues) {
		pTrendInfo->ixQueue = 0;
	}

	for (i=0;i<(pTrendInfo->nbCurves);i++) {
		pCurveInfo = *(&(pTrendInfo->pCurveInfo) + i);
		if (pCurveInfo->pLiveVal != 0) {
			*(&(pCurveInfo->pData)[pTrendInfo->ixQueue]) = *(pCurveInfo->pLiveVal);
		}
	}
	return (0);
}


UDINT TR_cDraw(UDINT pTrendID)
{
	trendInfo_typ* pTrendInfo;
	curveInfo_typ* pCurveInfo;
	
	DINT absoluteY;
	DINT actCurveValue;
	DINT oldCurveValue;
	UINT actValue;
	UINT oldValue;
	
	UINT i;
	UINT j;

	UINT status;

	pTrendInfo = (trendInfo_typ*)pTrendID;

	if (pTrendInfo->ixQueue == 0) {
		return (0);
	}
	
	i = 0;
	j = 0;
	status = 0;
	do {
		status = VA_Saccess(1, pTrendInfo->vc_handle);
		i = i + 1;
	} while ((status != 0) && (i < 10));

	if (status == 0) {
		if (pTrendInfo->ixQueue == 1) {
			j = 0;
			do {
				status = VA_Line(1, pTrendInfo->vc_handle, pTrendInfo->left, pTrendInfo->top, pTrendInfo->left, pTrendInfo->top + pTrendInfo->height, pTrendInfo->backColor);
				j = j + 1;
			} while ((status != 0) && (j < 10));
		}
		
		if (status == 0) {
			j = 0;
			do {
				status = VA_Rect(1, pTrendInfo->vc_handle, pTrendInfo->left + 1 + ((pTrendInfo->ixQueue-1)*pTrendInfo->samplesWidth), pTrendInfo->top, pTrendInfo->samplesWidth - 1, pTrendInfo->height, pTrendInfo->backColor, pTrendInfo->backColor);
				j = j + 1;
			} while ((status != 0) && (j < 10));
		}
		
		if (pTrendInfo->gridEnable != 0) {
			if (*(pTrendInfo->gridEnable) == 1) {
				if (pTrendInfo->gridX != 0) {
					i = (pTrendInfo->ixQueue - 1) * pTrendInfo->samplesWidth + 1;
					while (i <= (pTrendInfo->ixQueue * pTrendInfo->samplesWidth)) {
						if (((i % pTrendInfo->gridX) == 0) && (i != 0) && (i < pTrendInfo->width) && (status == 0)) {
							j = 0;
							do {
								status = VA_Line(1, pTrendInfo->vc_handle, pTrendInfo->left + i - 1, pTrendInfo->top, pTrendInfo->left + i - 1, pTrendInfo->top + pTrendInfo->height, pTrendInfo->gridColor);
								j = j + 1;
							} while ((status != 0) && (j < 10));
						}
						i = i + 1;
					}
				}
				if (pTrendInfo->gridY != 0) {
					i = 0;
					while (i < pTrendInfo->height) {
						if (((i % pTrendInfo->gridY) == 0) && (i != 0) && (status == 0)) {
							if (pTrendInfo->ixQueue == 1) {
								j = 0;
								do {
									status = VA_Line(1, pTrendInfo->vc_handle, pTrendInfo->left + ((pTrendInfo->ixQueue-1)*pTrendInfo->samplesWidth), pTrendInfo->top + pTrendInfo->height - i + 1 , pTrendInfo->left + (pTrendInfo->ixQueue*pTrendInfo->samplesWidth), pTrendInfo->top + pTrendInfo->height - i + 1, pTrendInfo->gridColor);
									j = j + 1;
								} while ((status != 0) && (j < 10));
							}
							else {
								j = 0;
								do {
									status = VA_Line(1, pTrendInfo->vc_handle, pTrendInfo->left + ((pTrendInfo->ixQueue-1)*pTrendInfo->samplesWidth) + 1, pTrendInfo->top + pTrendInfo->height - i + 1 , pTrendInfo->left + (pTrendInfo->ixQueue*pTrendInfo->samplesWidth), pTrendInfo->top + pTrendInfo->height - i + 1, pTrendInfo->gridColor);
									j = j + 1;
								} while ((status != 0) && (j < 10));
							}
						}
						i = i + 1;
					}
				}
			}
		}
		

		for (i=0;i<(pTrendInfo->nbCurves);i++) {
			pCurveInfo = *(&(pTrendInfo->pCurveInfo) + i);
			if ((*(pCurveInfo->enable) == 1) && (status == 0)) {

				oldCurveValue = *(pCurveInfo->pData + (pTrendInfo->ixQueue - 1));
				if (oldCurveValue > pCurveInfo->maxY) {
					oldCurveValue = pCurveInfo->maxY;	
				}
				else if (oldCurveValue < pCurveInfo->minY) { 
					oldCurveValue = pCurveInfo->minY;
				}

				actCurveValue = *(pCurveInfo->pData + pTrendInfo->ixQueue);
				if (actCurveValue > pCurveInfo->maxY) {
					actCurveValue = pCurveInfo->maxY;	
				}
				else if (actCurveValue < pCurveInfo->minY) { 
					actCurveValue = pCurveInfo->minY;
				}

				absoluteY = pCurveInfo->maxY - pCurveInfo->minY;
				oldValue = ((oldCurveValue - pCurveInfo->minY)*pTrendInfo->height)/absoluteY;
				actValue = ((actCurveValue - pCurveInfo->minY)*pTrendInfo->height)/absoluteY;

				j = 0;
				do {
					status = VA_Line(1, pTrendInfo->vc_handle, pTrendInfo->left + ((pTrendInfo->ixQueue-1)*pTrendInfo->samplesWidth), pTrendInfo->top + pTrendInfo->height - oldValue, pTrendInfo->left + (pTrendInfo->ixQueue*pTrendInfo->samplesWidth), pTrendInfo->top + pTrendInfo->height - actValue, pCurveInfo->color);
					j = j + 1;
				} while ((status != 0) && (j < 10));
			}
		}
		if ((pTrendInfo->ixQueue < (pTrendInfo->nbValues - 1)) && (status == 0)) {
			j = 0;
			do {
				status = VA_Line(1, pTrendInfo->vc_handle, pTrendInfo->left + 1 + (pTrendInfo->ixQueue*pTrendInfo->samplesWidth), pTrendInfo->top, pTrendInfo->left + 1 + (pTrendInfo->ixQueue*pTrendInfo->samplesWidth), pTrendInfo->top + pTrendInfo->height, pTrendInfo->foreColor);
				j = j + 1;
			} while ((status != 0) && (j < 10));
		}
				
	}
	
	VA_Srelease(1, pTrendInfo->vc_handle);
	return (status);
}

UDINT TR_cDrawInit(UDINT pTrendID)
{
	trendInfo_typ* pTrendInfo;
	curveInfo_typ* pCurveInfo;
	
	UINT Saccess;
	
	DINT absoluteY;
	DINT actCurveValue;
	DINT oldCurveValue;
	UINT actValue;
	UINT oldValue;
	

	UINT i;
	UINT j;

	pTrendInfo = (trendInfo_typ*)pTrendID;
	
	Saccess = 0;
	Saccess = VA_Saccess(1, pTrendInfo->vc_handle);
	if (Saccess == 0) {

		VA_Rect(1, pTrendInfo->vc_handle, pTrendInfo->left, pTrendInfo->top, pTrendInfo->width, pTrendInfo->height, pTrendInfo->backColor, pTrendInfo->backColor);

		if (pTrendInfo->gridEnable != 0) {
			if (*(pTrendInfo->gridEnable) == 1) {
				if (pTrendInfo->gridX != 0) {
					i = 0;
					while (i < pTrendInfo->width) {
						if (((i % pTrendInfo->gridX) == 0) && (i != 0)) {
							VA_Line(1, pTrendInfo->vc_handle, pTrendInfo->left + i - 1, pTrendInfo->top, pTrendInfo->left + i - 1, pTrendInfo->top + pTrendInfo->height, pTrendInfo->gridColor);
						}
						i = i + 1;
					}
				}
				if (pTrendInfo->gridY != 0) {
					i = 0;
					while (i < pTrendInfo->height) {
						if (((i % pTrendInfo->gridY) == 0) && (i != 0)) {
							VA_Line(1, pTrendInfo->vc_handle, pTrendInfo->left, pTrendInfo->top + pTrendInfo->height - i + 1 , pTrendInfo->left + pTrendInfo->width, pTrendInfo->top + pTrendInfo->height - i + 1, pTrendInfo->gridColor);
						}
						i = i + 1;
					}
				}
			}
		}

		for (i=0;i<(pTrendInfo->nbCurves);i++) {
			pCurveInfo = *(&(pTrendInfo->pCurveInfo) + i);
			if (*(pCurveInfo->enable) == 1) {
			
				actCurveValue = *(pCurveInfo->pData);
				if (*(pCurveInfo->pData) > pCurveInfo->maxY) {
					actCurveValue = pCurveInfo->maxY;
				}
				else if (*(pCurveInfo->pData) < pCurveInfo->minY) {
					actCurveValue = pCurveInfo->minY;
				}
				
				absoluteY = pCurveInfo->maxY - pCurveInfo->minY;
				for (j=1;j<(pTrendInfo->nbValues);j++) {
					oldCurveValue = actCurveValue;
					
					actCurveValue = *(pCurveInfo->pData + j);
					if (*(pCurveInfo->pData + j) > pCurveInfo->maxY) {
						actCurveValue = pCurveInfo->maxY;	
					}
					else if (*(pCurveInfo->pData + j) < pCurveInfo->minY) { 
						actCurveValue = pCurveInfo->minY;
					}
					
					oldValue = ((oldCurveValue - pCurveInfo->minY)*pTrendInfo->height)/absoluteY;
					actValue = ((actCurveValue - pCurveInfo->minY)*pTrendInfo->height)/absoluteY;
					VA_Line(1, pTrendInfo->vc_handle, pTrendInfo->left + ((j-1)*pTrendInfo->samplesWidth), pTrendInfo->top + pTrendInfo->height - oldValue, pTrendInfo->left + (j*pTrendInfo->samplesWidth), pTrendInfo->top + pTrendInfo->height - actValue, pCurveInfo->color);
				}
			}
		}		
	}
	else {
		return (Saccess);
	}
	VA_Srelease(1, pTrendInfo->vc_handle);
	return (0);
}


UDINT TR_cSingleShot(UDINT pTrendID)
{
	trendInfo_typ* pTrendInfo;
	curveInfo_typ* pCurveInfo;

	UINT Saccess;

	DINT absoluteY;
	DINT actCurveValue;
	DINT oldCurveValue;
	UINT actValue;
	UINT oldValue;

	UINT i;
	UINT j;
	UINT k;

	pTrendInfo = (trendInfo_typ*)pTrendID;

	Saccess = 0;
	Saccess = VA_Saccess(1, pTrendInfo->vc_handle);
	if (Saccess == 0) {

		for (i=0;i<(pTrendInfo->nbCurves);i++) {
			pCurveInfo = *(&(pTrendInfo->pCurveInfo) + i);
			if ((pCurveInfo->pLiveVal != 0) && (*(pCurveInfo->enable) == 1)) {
				
				k = 1;
				absoluteY = pCurveInfo->maxY - pCurveInfo->minY;

				actCurveValue = *(pCurveInfo->pData + pTrendInfo->ixQueue + 1);
				if (*(pCurveInfo->pData + pTrendInfo->ixQueue + 1) > pCurveInfo->maxY) {
					actCurveValue = pCurveInfo->maxY;
				}
				else if (*(pCurveInfo->pData + pTrendInfo->ixQueue + 1) < pCurveInfo->minY) {
					actCurveValue = pCurveInfo->minY;
				}

				if (pTrendInfo->ixQueue != (pTrendInfo->nbValues - 1)) {				
					for (j=(pTrendInfo->ixQueue + 2);j<(pTrendInfo->nbValues);j++) {
						oldCurveValue = actCurveValue;
						
						actCurveValue = *(pCurveInfo->pData + j);
						if (*(pCurveInfo->pData + j) > pCurveInfo->maxY) {
							actCurveValue = pCurveInfo->maxY;	
						}
						else if (*(pCurveInfo->pData + j) < pCurveInfo->minY) { 
							actCurveValue = pCurveInfo->minY;
						}
					
						oldValue = ((oldCurveValue - pCurveInfo->minY)*pTrendInfo->height)/absoluteY;
						actValue = ((actCurveValue - pCurveInfo->minY)*pTrendInfo->height)/absoluteY;
						VA_Line(1, pTrendInfo->vc_handle, pTrendInfo->left + ((k-1)*pTrendInfo->samplesWidth), pTrendInfo->top + pTrendInfo->height - oldValue, pTrendInfo->left + (k*pTrendInfo->samplesWidth), pTrendInfo->top + pTrendInfo->height - actValue, pCurveInfo->color);
						k = k + 1;
					}
				
					oldCurveValue = actCurveValue;
					actCurveValue = *(pCurveInfo->pData);
					if (*(pCurveInfo->pData) > pCurveInfo->maxY) {
						actCurveValue = pCurveInfo->maxY;
					}
					else if (*(pCurveInfo->pData) < pCurveInfo->minY) {
						actCurveValue = pCurveInfo->minY;
					}
	
					oldValue = ((oldCurveValue - pCurveInfo->minY)*pTrendInfo->height)/absoluteY;
					actValue = ((actCurveValue - pCurveInfo->minY)*pTrendInfo->height)/absoluteY;
					VA_Line(1, pTrendInfo->vc_handle, pTrendInfo->left + ((k-1)*pTrendInfo->samplesWidth), pTrendInfo->top + pTrendInfo->height - oldValue, pTrendInfo->left + (k*pTrendInfo->samplesWidth), pTrendInfo->top + pTrendInfo->height - actValue, pCurveInfo->color);
					k = k + 1;
				}
				else {
					actCurveValue = *(pCurveInfo->pData);
					if (*(pCurveInfo->pData) > pCurveInfo->maxY) {
						actCurveValue = pCurveInfo->maxY;
					}
					else if (*(pCurveInfo->pData) < pCurveInfo->minY) {
						actCurveValue = pCurveInfo->minY;
					}
				}					
			
				for (j=1;j<=(pTrendInfo->ixQueue);j++) {
					oldCurveValue = actCurveValue;
					
					actCurveValue = *(pCurveInfo->pData + j);
					if (*(pCurveInfo->pData + j) > pCurveInfo->maxY) {
						actCurveValue = pCurveInfo->maxY;	
					}
					else if (*(pCurveInfo->pData + j) < pCurveInfo->minY) { 
						actCurveValue = pCurveInfo->minY;
					}
					
					oldValue = ((oldCurveValue - pCurveInfo->minY)*pTrendInfo->height)/absoluteY;
					actValue = ((actCurveValue - pCurveInfo->minY)*pTrendInfo->height)/absoluteY;
					VA_Line(1, pTrendInfo->vc_handle, pTrendInfo->left + ((k-1)*pTrendInfo->samplesWidth), pTrendInfo->top + pTrendInfo->height - oldValue, pTrendInfo->left + (k*pTrendInfo->samplesWidth), pTrendInfo->top + pTrendInfo->height - actValue, pCurveInfo->color);
					k = k + 1;
				}
			}
		}
	}
	else {
		return (Saccess);
	}
	VA_Srelease(1, pTrendInfo->vc_handle);
	return (0);
}


UDINT TR_sDraw(UDINT pTrendID)
{
	trendInfo_typ* pTrendInfo;
	curveInfo_typ* pCurveInfo;
	
	UINT Saccess;
	
	DINT absoluteY;
	DINT actCurveValue;
	DINT oldCurveValue;
	UINT actValue;
	UINT oldValue;
	

	UINT i;
	UINT j;

	pTrendInfo = (trendInfo_typ*)pTrendID;
	
	Saccess = 0;
	Saccess = VA_Saccess(1, pTrendInfo->vc_handle);
	if (Saccess == 0) {

		for (i=0;i<(pTrendInfo->nbCurves);i++) {
			pCurveInfo = *(&(pTrendInfo->pCurveInfo) + i);
			if ((pCurveInfo->pLiveVal == 0) && (*(pCurveInfo->enable) == 1)) {
			
				actCurveValue = *(pCurveInfo->pData);
				if (*(pCurveInfo->pData) > pCurveInfo->maxY) {
					actCurveValue = pCurveInfo->maxY;
				}
				else if (*(pCurveInfo->pData) < pCurveInfo->minY) {
					actCurveValue = pCurveInfo->minY;
				}
				
				absoluteY = pCurveInfo->maxY - pCurveInfo->minY;
				for (j=1;j<(pTrendInfo->nbValues);j++) {
					oldCurveValue = actCurveValue;
					
					actCurveValue = *(pCurveInfo->pData + j);
					if (*(pCurveInfo->pData + j) > pCurveInfo->maxY) {
						actCurveValue = pCurveInfo->maxY;	
					}
					else if (*(pCurveInfo->pData + j) < pCurveInfo->minY) { 
						actCurveValue = pCurveInfo->minY;
					}
					
					oldValue = ((oldCurveValue - pCurveInfo->minY)*pTrendInfo->height)/absoluteY;
					actValue = ((actCurveValue - pCurveInfo->minY)*pTrendInfo->height)/absoluteY;
					VA_Line(1, pTrendInfo->vc_handle, pTrendInfo->left + ((j-1)*pTrendInfo->samplesWidth), pTrendInfo->top + pTrendInfo->height - oldValue, pTrendInfo->left + (j*pTrendInfo->samplesWidth), pTrendInfo->top + pTrendInfo->height - actValue, pCurveInfo->color);
				}
			}
		}		
	}
	else {
		return (Saccess);
	}
	VA_Srelease(1, pTrendInfo->vc_handle);
	return (0);
}


UDINT TR_redraw(UDINT trendID)
{
	trendInfo_typ* pTrendInfo;
	
	UINT Saccess;

	UINT i;

	pTrendInfo = (trendInfo_typ*)trendID;
	
	Saccess = VA_Saccess(1, pTrendInfo->vc_handle);
	
	if (Saccess == 0) {
		VA_Rect(1, pTrendInfo->vc_handle, pTrendInfo->left, pTrendInfo->top, pTrendInfo->width, pTrendInfo->height, pTrendInfo->backColor, pTrendInfo->backColor);

		if (pTrendInfo->gridEnable != 0) {
			if (*(pTrendInfo->gridEnable) == 1) {
				if (pTrendInfo->gridX != 0) {
					i = 0;
					while (i < pTrendInfo->width) {
						if (((i % pTrendInfo->gridX) == 0) && (i != 0)) {
							VA_Line(1, pTrendInfo->vc_handle, pTrendInfo->left + i - 1, pTrendInfo->top, pTrendInfo->left + i - 1, pTrendInfo->top + pTrendInfo->height, pTrendInfo->gridColor);
						}
						i = i + 1;
					}
				}
				if (pTrendInfo->gridY != 0) {
					i = 0;
					while (i < pTrendInfo->height) {
						if (((i % pTrendInfo->gridY) == 0) && (i != 0)) {
							VA_Line(1, pTrendInfo->vc_handle, pTrendInfo->left, pTrendInfo->top + pTrendInfo->height - i + 1 , pTrendInfo->left + pTrendInfo->width, pTrendInfo->top + pTrendInfo->height - i + 1, pTrendInfo->gridColor);
						}
						i = i + 1;
					}
				}
			}
		}
		
	}
	else {
		return (Saccess);
	}
	VA_Srelease(1, pTrendInfo->vc_handle);
	return (0);
}


