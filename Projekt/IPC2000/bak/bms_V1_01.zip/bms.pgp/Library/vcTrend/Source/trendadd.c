#include <vctrend.h>
#include <bur/plctypes.h>
#include <sys_lib.h>

unsigned short TrendAdd(unsigned long* pTrendID, unsigned long* pLiveVal, unsigned long* ppData, signed long minY, signed long maxY, unsigned short color)
{
}