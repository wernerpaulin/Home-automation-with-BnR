/*********************************************************************************************
*  Copyright: 2001 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Managment System                                                    *
*    Purpose    general include file                                                         *
*                                                                                            *
*    Filename   bms_gn.h                                                                     *
*********************************************************************************************/

#ifndef _BMS_GN_H_
#define _BMS_GN_H_

#include <bur/plctypes.h>
#include <astime.h>
#include <asstring.h>
#include <sys_lib.h>
#include <brsystem.h>
#include <dataobj.h>
#include <visapi.h>
#include <dvframe.h>
#include <vcTrend.h>
#include <canio.h>
#include <commserv.h>

/*** error numbers ***/
#define ERR_BMS_NO_ERR                  1              	/* no error */
#define ERR_BMS_NO_IP_SCHEDULE	    50000				/* no valid irrigation plant schedule available */

#define ERR_OK                          0               /* B&R error code for no error */
#define ERR_FUB_BUSY                65535

/*** defines ***/
#define USER_INPUT_APPLY_DELAY          2000            /* delay after which a new user input will be applied */

#define NB_VALVES                       7               /* total number of valves - including segments and service water valve */
#define NB_SEGMENTS						6				/* number of irrigation segments */
#define NB_PERIODS_PER_DAY              4              	/* number of configurable periods per day */
#define DAYS_OF_WEEK                    7               /* week is usually 7 days long */ 

#define WATER_SOURCE_UNKNOWN            0               /* unknown whether water source is available or not */
#define WATER_SOURCE_NOT_AVAILABLE      1               /* water source is not available */
#define WATER_SOURCE_AVAILABLE          2               /* water source is available */


#define DATE_OUT_OF_RANGE               0               /* given date is out of range */
#define DATE_IN_RANGE                   1               /* given date is within range */

#define DATE_INVALID 					0				/* given date is invalid */
#define DATE_VALID 						1				/* given date is valid */

#define TIME_OUT_OF_RANGE               0               /* given time is out of range */
#define TIME_IN_RANGE                   1               /* given time is within range */

#define TIME_INVALID 					0				/* given time is invalid */
#define TIME_VALID 						1				/* given time is valid */

#define DAY_OUT_OF_RANGE               	0              	/* given day is out of range */
#define DAY_IN_RANGE                   	1              	/* given day is within range */

#define VC_ALARM_FILTER_TYPE_GROUP		3				/* alarm history filtered by group */
#define VC_ELEMENT_VISIBLE				0xFFFE			/* sets bit #0 of a VC status variable to 0 -> visible */
#define VC_ELEMENT_INVISIBLE			0x0001			/* sets bit #0 of a VC status variable to 1 -> invisible */
#define VC_ELEMENT_UNLOCK				0xFFFD			/* sets bit #1 of a VC status variable to 0 -> unlock */
#define VC_ELEMENT_LOCK					0x0002			/* sets bit #1 of a VC status variable to 1 -> lock */

#define CHECK_PRESSURE_DELAY        	60000			/* delay for checking pressure after activating one water source */
#define CHECK_VALVE_STATE_DELAY     	60000           /* delay within valve should have been entered desired state (open or close) */

#define IRRIGATION_SEGMENT_FORCE_TIMEOUT	45			/* timeout for force segments */

#define BMS_STATISTIC_INFO_DO_NAME  	"bmsstat"       /* name of data object containing statistical information of buliding managment system */
#define HS_MGR_INFO_DO_NAME				"hsmgrinf"
#define HS_LOOP_INFO_DO_NAME			"hslpinf"
#define HS_ECO_INFO_DO_NAME				"hsecoinf"

#define CHART_OUTSIDE_LEADING_TEMP_DO_NAME		"out_lead"	/* name of data object containing relationship between outside temperature and leading temperature */
#define CHART_OUTSIDE_LEADING_TEMP_MAX_CURVE	4			/* 4 curves in this chart */
#define CHART_OUTSIDE_LEADING_TEMP_UPPER_LEFT_X	45			/* x coordinate of upper left corner */
#define CHART_OUTSIDE_LEADING_TEMP_UPPER_LEFT_Y	63			/* y coordinate of upper left corner */
#define CHART_OUTSIDE_LEADING_TEMP_WIDTH		289			/* width of chart in pixel */
#define CHART_OUTSIDE_LEADING_TEMP_HEIGHT		344			/* height of chart in pixel */
#define CHART_OUTSIDE_LEADING_TEMP_GRID_X		5			/* width of grid in �C:  5�C */
#define CHART_OUTSIDE_LEADING_TEMP_GRID_Y		10			/* width of grid in �C: 10�C */
#define CHART_OUTSIDE_LEADING_TEMP_GRID_COLOR	145			/* grid color      : 145 ...dark gray */
#define CHART_OUTSIDE_LEADING_TEMP_BACK_COLOR	53			/* background color:  53 ...grey */
#define CHART_OUTSIDE_LEADING_TEMP_FORE_COLOR	167			/* foreground color: 167 ...what is a foreground color? */
#define CHART_OUTSIDE_LEADING_TEMP_MIN_Y 		0			/* minimum value:  0�C */
#define CHART_OUTSIDE_LEADING_TEMP_MAX_Y 		80			/* maximum value: 80�C */

#define CHART_OUTSIDE_LEADING_TEMP_ORIGINAL_CURVE_COLOR		0	/* color of original curve:     0 ...black  */
#define CHART_OUTSIDE_LEADING_TEMP_DAY_CURVE_COLOR			49	/* color of day curve:         49 ...orange */
#define CHART_OUTSIDE_LEADING_TEMP_NIGHT_CURVE_COLOR		5	/* color of night curve: 	    5 ...violet */
#define CHART_OUTSIDE_LEADING_TEMP_NOT_AT_HOME_CURVE_COLOR	2	/* color of not at home curve:  2 ...green */


#define CHART_YEAR_TREND_MAX_DAYS				366			/* day maximum � year */
#define CHART_YEAR_TREND_MAX_CURVE				5			/* 5 curves in this chart */

#define CHART_YEAR_TEMP_TREND_UPPER_LEFT_X		45			/* x coordinate of upper left corner */
#define CHART_YEAR_TEMP_TREND_UPPER_LEFT_Y		80			/* y coordinate of upper left corner */
#define CHART_YEAR_TEMP_TREND_WIDTH				367			/* width of chart in pixel */
#define CHART_YEAR_TEMP_TREND_HEIGHT			147			/* height of chart in pixel */
#define CHART_YEAR_TEMP_TREND_GRID_X		 	30			/* width of grid in days */
#define CHART_YEAR_TEMP_TREND_GRID_Y			10			/* width of grid in �C */
#define CHART_YEAR_TEMP_TREND_GRID_COLOR		145			/* grid color      : 145 ...dark gray */
#define CHART_YEAR_TEMP_TREND_BACK_COLOR		53			/* background color:  53 ...grey */
#define CHART_YEAR_TEMP_TREND_FORE_COLOR		167			/* foreground color: 167 ...what is a foreground color? */
#define CHART_YEAR_TEMP_TREND_MIN_Y 			-30			/* minimum value: -30�C */
#define CHART_YEAR_TEMP_TREND_MAX_Y 			40			/* maximum value:  40�C */
#define TEMP_TREND_DO_NAME_TEMPLATE				"temp_xx"	/* template for temperature trend data objects */

#define CHART_YEAR_HEAT_TREND_UPPER_LEFT_X		45			/* x coordinate of upper left corner */
#define CHART_YEAR_HEAT_TREND_UPPER_LEFT_Y		273			/* y coordinate of upper left corner */
#define CHART_YEAR_HEAT_TREND_WIDTH				367			/* width of chart in pixel */
#define CHART_YEAR_HEAT_TREND_HEIGHT			144			/* height of chart in pixel */
#define CHART_YEAR_HEAT_TREND_GRID_X		 	30			/* width of grid in days */
#define CHART_YEAR_HEAT_TREND_GRID_Y			60			/* width of grid in minutes */
#define CHART_YEAR_HEAT_TREND_GRID_COLOR		145			/* grid color      : 145 ...dark gray */
#define CHART_YEAR_HEAT_TREND_BACK_COLOR		53			/* background color:  53 ...grey */
#define CHART_YEAR_HEAT_TREND_FORE_COLOR		167			/* foreground color: 167 ...what is a foreground color? */
#define CHART_YEAR_HEAT_TREND_MIN_Y 			0			/* minimum value:    0min */
#define CHART_YEAR_HEAT_TREND_MAX_Y 			360			/* maximum value:  360min = 6hours */
#define HEAT_TREND_DO_NAME_TEMPLATE				"heat_xx"	/* template for heating minutes trend data objects */




#define CHART_LINEAR_FIRING_TEMP_DO_NAME		"lin_fire"	/* name of data object containing characteristics of NTC sensor used for firing device, boiler and flow pipe */
#define CHART_LINEAR_OUTSIDE_TEMP_DO_NAME		"lin_out"   /* name of data object containing characteristics of NTC sensor used for outside temperature */
#define CHART_LINEAR_ROOM_TEMP_DO_NAME			"lin_room"  /* name of data object containing characteristics of NTC sensor used for room temperature */

#define HS_PROGRAMM1_DO_NAME					"hsprog1"	/* name of data object containing programm 1 information */
#define HS_PROGRAMM2_DO_NAME					"hsprog2"	/* name of data object containing programm 2 information */
#define HS_PROGRAMM3_DO_NAME					"hsprog3"	/* name of data object containing programm 3 information */
#define HS_PROGRAMM4_DO_NAME					"hsprog4"	/* name of data object containing programm 4 information */


#define HS_DEF_NAME_PROGRAMM_1					"Sommer mit Uhr"		/* default name of programm #1 (max. 32 char) */
#define HS_DEF_NAME_PROGRAMM_2					"Winter ohne Uhr"		/* default name of programm #2 (max. 32 char) */
#define HS_DEF_NAME_PROGRAMM_3					"Urlaub nach Datum"		/* default name of programm #3 (max. 32 char) */
#define HS_DEF_NAME_PROGRAMM_4					"Urlaub nach Wochentag"	/* default name of programm #4 (max. 32 char) */


#define IP_SCHEDULE_DEFAULT_DO_NAME 	"ipdefcfg"		/* default configuration of irrigation schedule */
#define IP_SCHEDULE_USER_DO_NAME    	"ipusrcfg"		/* irrigation schedule configuration modified by user */
#define IP_SEGMENT_INFO_DO_NAME     	"ipseginf"		/* name of dataobject containing segmet name */

#define HS_FIRING_MIN_SET_TEMP			20				/* minimum temperature in �C for firing device */
#define HS_FIRING_MAX_SET_TEMP			70				/* maximum temperature in �C for firing device */
#define HS_FIRING_ALARM_TEMP			85				/* alarm level temperature in �C for firing device */
#define HS_FIRING_MIN_RUNTIME		    10				/* minimum runtime in minutes */
#define HS_FIRING_MIN_DELTA_TEMP	    5				/* minimum delta between set temperature and actual temperature in �C */
#define HS_FIRING_ACT_TEMP_HYSTERESIS   3				/* hysteresis in �C of actual temperature */

#define HS_BOILER_PUMP_DELAY_TIME		10				/* delay time in minutes for switching off boiler pump */
#define HS_BOILER_PUMP_MIN_DUTY_CYCLE	10080			/* minimum duty of boiler pump in minutes: within that time pump must be switch on at least once -> actual: 1 week */

#define HS_HEATING_CIRCULATION_PUMP_DELAY_TIME		10		/* delay time in minutes for switching off heating circulation pump */
#define HS_HEATING_CIRCULATION_PUMP_MIN_DUTY_CYCLE	10080	/* minimum duty of heating circulation pump: within that time pump must be switch on at least once -> actual: 1 week */

#define HS_HEATING_MIXER_LC_PAR_E_MAX				15      /* maximum control deviation for anti windup: integral active if actual value is within delta of 20�C to set value */
#define HS_HEATING_MIXER_LC_PAR_KP					5		/* kp of PI-Controller */
#define HS_HEATING_MIXER_LC_PAR_TN					300     /* integral action time in s of PI-Controller */
#define HS_HEATING_MIXER_LC_PAR_LOW_LIMIT			0		/* lower limit of PI-Controller */
#define HS_HEATING_MIXER_LC_PAR_HIGH_LIMIT			100		/* lower limit of PI-Controller */

#define HS_HEATING_MIXER_FULLY_OPEN_TIME			118000	/* time in ms which is needed to open mixer completely */

#define HS_MIXER_DEAD_TIME_OFFSET					200		/* dead time in ms off mixer due to mechanical reasons */

#define OUTSIDE_PARALLEL_RESISTANCE					4692.2	/* exact value of parallel restance used with outside temperature NTC */
#define FIRING_PARALLEL_RESISTANCE					4696.8	/* exact value of parallel restance used with firing temperature NTC */
#define BOILER_PARALLEL_RESISTANCE					4715.8	/* exact value of parallel restance used with boiler temperature NTC */
#define FLOW_PIPE_PARALLEL_RESISTANCE				4649.0	/* exact value of parallel restance used with flow pipe temperature NTC */
#define ROOM_PARALLEL_RESISTANCE					4651.1	/* exact value of parallel restance used with room temperature NTC */

#define AT324_ALL_CHANNELS_RESISTANCE_MEASUREMENT	0x0B6D 	/* bit 0 and 2 of each channel confiuration set */
#define AT324_BUS_NUMBER							1		/* CAN-Bus number where CAN-IO with AT324 is located */
#define AT324_NODE_NUMBER							3		/* Node number of CAN-IO, where AT324 is located */

#define CANIO_WRITE_PARAMETER						11		/* code according CANIO-Master */
#define CANIO_ACTIVATE_PARAMETER					12		/* code according CANIO-Master */
#define CANIO_PARAMETER_FOR_SCREW_IN_MODULE			28		/* code according CANIO-Master */

#define HS_LIN_FIRE_TEMP_DEF_K 			-0.00625		/* default k of y=k*x+d if no data object of linearisation is given */
#define HS_LIN_FIRE_TEMP_DEF_D 			78.75			/* default d of y=k*x+d if no data object of linearisation is given */

#define HS_LIN_OUT_TEMP_DEF_K 			-0.037811		/* default k of y=k*x+d if no data object of linearisation is given */
#define HS_LIN_OUT_TEMP_DEF_D 			152.3617021		/* default d of y=k*x+d if no data object of linearisation is given */

#define HS_LIN_ROOM_TEMP_DEF_K 			-0.002			/* default k of y=k*x+d if no data object of linearisation is given */
#define HS_LIN_ROOM_TEMP_DEF_D 			45.0			/* default d of y=k*x+d if no data object of linearisation is given */

#define HS_OUTSIDE_LEAD_TEMP_DEF_K		-0.6			/* default k of y=k*x+d if no data object of linearisation is given */
#define HS_OUTSIDE_LEAD_TEMP_DEF_D		42.0			/* default d of y=k*x+d if no data object of linearisation is given */

#define HS_KILL_BACTERIA_TEMP			60.0			/* critical temperature in order to kill bacteria */

#define HS_SWITCH_OFF					0				/* off */
#define HS_SWITCH_ON					1				/* on */

#define HS_MIXER_CLOSE					-1				/* forces mixer to close */
#define HS_MIXER_STOP					 0				/* forces mixer to stop */
#define HS_MIXER_OPEN					 1				/* forces mixer to open */

#define HS_MIXER_HOMING_DONE			0				/* acknowledge: homing done */
#define HS_MIXER_DO_HOMING				1				/* command: do homing */
#define HS_MIXER_HOMING_ACTIVE			2				/* acknowledge: do homing */

#define SHIFT_HEATING_START_TEMPERATURE	-15.0			/* below this temperature heating will start one hour earlier */		

#define NB_HOT_WATER_PHASES				2				/* number of hot water generatig phases per day */

#define ONE_HUNDRED_PERCENT				100				

#define ENABLE_FIRING_LEVEL				30				/* if mixer postion > level in % -> firing will be enabled */

#define MIXER_MIN_DELTA_POSITON 		5				/* minimum delta of mixer to start mixer movement (to avoid continous movement within dead time) */

#define HS_ECO_OUTSIDE_TEMP_MOV_AV_ELEMENTS		1440	/* number of elements: 1440Elements/24h -> every minute a new temperature value */
#define HS_ECO_LIVING_ROOM_ACT_TEMP_HYSTERESIS	1		/* hysteresis in �C of actual temperature */
#define HS_ECO_FIRING_TOGGLE_DELAY_TIME			30		/* time in min after release of firing device will be toggled if set temperature fall below HS_ECO_FIRING_MIN_SET_TEMPERATURE */
#define HS_ECO_FIRING_MIN_SET_TEMPERATURE		30		/* below this temperature in �C, firing device will stop working for HS_ECO_FIRING_ON_DELAY_TIME */
#define HS_ECO_FIRING_SET_TEMP_HYSTERESIS		1		/* hysteresis in �C of set temperature */
#define HS_ECO_NOON_DEF_MIN_TEMP				16		/* minimum of outside temperature in �C when heating will be switched off for a certain time */


enum SEGMENT_STATES
{
 SEGMENT_INACTIVE = 0,  	             				/* segment is no flooded */
 SEGMENT_READY_FOR_ACTIVE,               				/* segment is ready for beein flooded */
 SEGMENT_ACTIVE,		             					/* segment is flooded */
 MAX_SEGMENT_STATES,
};


enum SEGMENT_MODES
{
 SEGMENT_MODE_AUTO = 0,					               	/* segment will be activated according schedule */
 SEGMENT_MAN_INACTIVE ,              					/* segment is manually set to inactive */
 SEGMENT_MAN_ACTIVE   ,            						/* segment is manually set to active */
 MAX_SEGMENT_MODES,		
};

enum HUMIDITY_SENSORS
{
 NO_HUMIDITY_CHECK = 0,              				 	/* humidity is irrelevant for segment */
 HUMIDITY_KITCHEN_GARDEN,               				/* sensor in kitchen garden is taken under considuration */
 HUMIDITY_FLOWER_GARDEN,               					/* sensor in flower garden is taken under considuration */
 MAX_HUMIDITY_SENSORS,											
};

enum WATER_SOURCES
{
 WATER_SOURCE_AUTO = 0,               					/* water source will be chosen automatically */
 WATER_SOURCE_RAIN,               						/* only rain water will be used for irrigation */ 
 WATER_SOURCE_SERVICE,               					/* only service water will be used for irrigation */ 
 MAX_WATER_SOURCES,
};


enum BMS_ALARMS
{
 CAN_NODE_2_DROP_OFF = 0,
 CAN_NODE_3_DROP_OFF,
 MAX_BMS_ALARMS,
};


enum IRRIGATION_ALARMS
{
 IRRIGATION_LOW_WATER_PREASURE = 0,
 IRRIGATION_NO_ENDPOS_VALVE_1,
 IRRIGATION_NO_ENDPOS_VALVE_2,
 IRRIGATION_NO_ENDPOS_VALVE_3,
 IRRIGATION_NO_ENDPOS_VALVE_4,
 IRRIGATION_NO_ENDPOS_VALVE_5,
 IRRIGATION_NO_ENDPOS_VALVE_6,
 IRRIGATION_NO_ENDPOS_VALVE_7,
 MAX_IRRIGATION_ALARMS,
};

enum HEATING_ALARMS
{
 HEATING_ESTOP = 0,
 HEATING_FIRING_TEMPERATURE_TOO_HIGH,
 HEATING_BOILER_TEMPERATURE_TOO_HIGH,
 HEATING_HS_MGR_DO_ERROR,
 HEATING_HS_LOOP_DO_ERROR,
 HEATING_PROGRAMM1_DO_ERROR,
 HEATING_PROGRAMM2_DO_ERROR,
 HEATING_PROGRAMM3_DO_ERROR,
 HEATING_PROGRAMM4_DO_ERROR,
 HEATING_OUTSIDE_LEADING_DO_ERROR,
 HEATING_LIN_FIRE_DO_ERROR,
 HEATING_LIN_OUT_DO_ERROR,
 HEATING_OUTSIDE_TEMPERATUR_SENSOR_BROKEN,
 HEATING_FIRING_TEMPERATUR_SENSOR_BROKEN,
 HEATING_BOILER_TEMPERATUR_SENSOR_BROKEN,
 HEATING_FLOW_PIPE_TEMPERATUR_SENSOR_BROKEN,
 HEATING_TREND_TEMPERATUR_DO_ERROR,
 HEATING_TREND_HEATING_DO_ERROR,
 HEATING_NO_CONNECTION_CANIO,
 HEATING_LIN_ROOM_DO_ERROR,
 HEATING_HS_ECO_DO_ERROR,
 MAX_HEATING_ALARMS,
};


enum MESSAGE_ALARMS
{
 IRRIGATION_KITCHEN_GARDEN_DRY = 0,
 IRRIGATION_FLOWER_GARDEN_DRY,
 HEATING_SIMULATION_ACTIVE,
 HEATING_CIRCULATION_PUMP_DUTY_REQUEST,
 HEATING_BOILER_PUMP_DUTY_REQUEST,
 HEATING_KILL_BACTERIA_ACTIVE,
 HEATING_HEATING_ON,
 HEATING_HOT_WATER_ON,
 MAX_MESSAGE_ALARMS,
};


/* picture numbers */
enum PIC_NUMBERS
{
 FRONT_PAGE = 0,
 ALLG_EINST,
 TOUCH_CAL,
 GARTEN,
 TOPOLOGY,
 PIC_20_0,
 PIC_20_1,
 PIC_20_2,
 PIC_20_3,
 PIC_20_4,
 PIC_20_5,
 PIC_20_6,
 PIC_20_7,
 PIC_20_8,
 PIC_20_9,
 PIC_21_0,
 PIC_21_1,
 HEIZUNG,
 PIC_30_0,
 PIC_30_1,
 PIC_30_2,
 PIC_30_3,
 PIC_30_4,
 PIC_30_5,
 PIC_30_6,
 PIC_30_7,
 PIC_30_8,
};

enum TOUCH_CALIBRATION_STATES
{
 TOUCH_CALIBRATION_DONE = 0,
 CHANGE_TO_TOUCH_CALIBRATION_PICTURE,
 START_TOUCH_CALIBRATION,
 GET_TOUCH_CALIBRATION_STATUS,
};

enum MODEM_CONFIGURATION_STATES
{
 MODEM_CFG_DONE = 0,
 MODEM_CFG_NOT_FOUND,
 MODEM_CFG_FOUND,
 MODEM_NOT_FOUND,
 MODEM_BAD_ANSWER,
 MODEM_FOUND,
 MODEM_NO_CONNECTION,
 MODEM_INIT_OK,
 MODEM_AT_COMMAND_TOO_LONG,
};


enum ALARM_GROUPS
{
 SYSTEM_ALARM_GROUP = 0,
 IRRIGATION_ALARM_GROUP,
 HEATING_ALARM_GROUP,
};

enum HEATING_MODES
{
 HEATING_MODE_AUTO = 0,					       	/* heating will be controlled according schedule */
 HEATING_MAN_ON,              					/* heating is manually set to permanently on */
 HEATING_MAN_DROP,    	         				/* heating drops by manual override */
 MAX_HEATUNG_MODES,								/* heating is manually set to */
};

enum HEATING_PROGRAMMS
{
 HEATING_PROGRAMM_1 = 0,
 HEATING_PROGRAMM_2,
 HEATING_PROGRAMM_3,
 HEATING_PROGRAMM_4,
 MAX_HEATING_PROGRAMMS,
};

enum BMS_DAYS_OF_WEEK
{
 SUNDAY = 0,
 MONDAY,
 TUESDAY,
 WEDNESDAY,
 THURSDAY,
 FRIDAY,
 SATURDAY,
 MAX_DAYS_OF_WEEK,
};

enum SERVICE_MODES
{
 SERVICE_MODE_OFF = 0,				             	/* no serivce mode -> automatic operation */
 SERVICE_MODE_SWITCH_OFF,              				/* service mode active */
 SERVICE_MODE_SWITCH_ON,           					/* service mode inactive */
 MAX_SERVICE_MODES,		
};

enum AT324_CONFIGURATION_STATES
{
 sWAIT_START_CONFIGURATION = 0,
 sWRITE_CONFIGWORD_14,
 sACTIVATE_PARAMETERS,
};

enum MOV_AV_BUFFER_STATES
{
 MOV_AV_NOT_PREPARED = 0,
 MOV_AV_PREPARED,
 MOV_AV_DO_INIT,
 MOV_AV_OPERATIONAL,
};


/*** datatypes ***/
typedef struct time_s 
{
  USINT hour;
  USINT minute;
} time_s; 


typedef struct periode_s
{
  time_s start;
  UINT   duration;
} periode_s;

typedef struct ipSegmentSchedule_s
{
  periode_s periode[NB_PERIODS_PER_DAY];
} ipSegmentSchedule_s;

typedef struct ipDaySchedule_s
{
  ipSegmentSchedule_s ipSegmentSchedule[NB_SEGMENTS];
} ipDaySchedule_s;

typedef struct segment_s
{
  USINT       name[32];
  DTStructure beginDate;
  DTStructure endDate;
  USINT       force;
  USINT       useHumidity;
  USINT       waterSource;
  USINT       state;
  UINT        durationTimer;
  BOOL        *pOutputValve;
  UINT        curPeriodeNr;
} segment_s;

typedef struct valveStateCheck_s
{
  BOOL        *pOutputValve;
  BOOL        *pInputValveState;
  USINT       oldOutputValve;
  USINT       res0;
  UDINT       valveStateTimer;
  UDINT       valveStateDelayTO;
} valveStateCheck_s;

typedef struct irrigationStatistic_s
{
  UDINT onTimeRainWaterPump;
  UDINT nbSwitchValve[NB_VALVES];
} irrigationStatistic_s;

typedef struct heatingStatistic_s
{
  UDINT onTimeFiring;
  UDINT onTimeBoilerPump;
  UDINT onTimeHeatingCirculationPump;
} heatingStatistic_s;

typedef struct bmsStatistic_s
{
  irrigationStatistic_s irrigationStatistic;
  heatingStatistic_s heatingStatistic;
} bmsStatistic_s;

typedef struct waterSourceInf_s
{
 USINT request;
 USINT type;
 USINT available;
 USINT res0;
} waterSourceInf_s;


typedef struct dataObjInf_s 
{
 UDINT           pData;
 UDINT           doIdent;
 UDINT           doLength;
 UDINT           doOption;
 USINT           doMemType;
 USINT           res0;
 DATE_AND_TIME   doChangeDate;
 UINT            nbWrErr;
 UINT            lstWrErr;
 UINT            nbRdErr;
 UINT            lstRdErr;
} dataObjInf_s;

typedef struct animationInf_s
{
 UDINT timer;
 UDINT duration;
 USINT index;
 USINT nbElements;
} animationInf_s;


typedef struct xyChartElement_s
{
 REAL x;
 REAL y;
} xyChartElement_s;


typedef struct visuInterface_s
{
 ipDaySchedule_s  ipDaySchedule[DAYS_OF_WEEK];
 UINT             curPictNr;
 UINT             newPictNr;
 USINT            saveSchedule;
 USINT            saveAllSchedule;
 USINT            cancelSchedule;
 USINT            loadDefaultSchedule;
 USINT            doTouchCalibration;
 USINT            setTime;
 DTStructure      newTime;
 UINT             language;
 USINT            segmentModeSelect[NB_SEGMENTS];
 BOOL             bmsAlarm[MAX_BMS_ALARMS];
 BOOL             irrigationAlarm[MAX_IRRIGATION_ALARMS];
 REAL             rainWaterPumpHour;
 USINT            segmentNewForce[NB_SEGMENTS];
 UDINT            segmentNewForceTimer[NB_SEGMENTS];
 USINT            waterSourceSelect[NB_SEGMENTS];
 USINT            humiditySelect[NB_SEGMENTS];
 animationInf_s   ipAnimationInf[NB_SEGMENTS];
 USINT            nameOfModemCfgFile[10];
 USINT            nameOfSelectedModem[32];
 USINT            newModemCfgFile;
 USINT            modemCfgState;
 USINT            ipAlarmGroup;
 USINT            ipAlarmFilterCtrl;
 animationInf_s   progressBarInf;
 BOOL             heatingAlarm[MAX_HEATING_ALARMS];
 BOOL             heatingAlarmAck[MAX_HEATING_ALARMS];
 USINT 			  heatingModeSelect;
 USINT            heatingNewMode;
 UDINT            heatingNewModeTimer;
 USINT 			  heatingProgrammSelect;
 USINT            heatingNewProgramm;
 UDINT            heatingNewProgrammTimer;
 USINT            heatingProgrammName[32];
 UINT             heatingProgrammNameTextStatus;
 UINT             heatingProgrammNameOutPutStatus;
 UINT             heatingProgrammNameHotSpotSts;
 USINT            manTempSliderIndex;
 USINT            oldManTempSliderIndex;
 USINT 			  heatingEstop;
 USINT            heatingPrgm4StartDaySelect;
 USINT            heatingPrgm4EndDaySelect;
 USINT            heatingAlarmGroup;
 USINT            heatingAlarmFilterCtrl;
 REAL             firingHour;
 REAL             boilerPumpHour;
 REAL             heatingCirculationPumpHour;
 USINT            hsMixerModeSelect;
 USINT            hsNewMixerMode;
 UDINT            hsMixerModeTimer;
 USINT            hsCircPumpModeSelect;
 USINT            hsNewCircPumpMode;
 UDINT            hsCircPumpModeTimer;
 USINT            hsFiringSelect;
 USINT            hsNewFiringMode;
 UDINT            hsFiringModeTimer;
 USINT            hsBoilerPumpSelect;
 USINT            hsNewBoilerPumpMode;
 UDINT            hsBoilerPumpModeTimer;
 animationInf_s   eStopAnimationInf;
 USINT            ipSegmentInputCompletion;
 USINT            hsMgrInputCompletion;
 USINT            hsProgSave;
 xyChartElement_s hsAdjOutLeadTemp[9];
 USINT            hsXyChartElementInputCompletion;
 USINT            hsChartSave;
 USINT            hsChartUndo;
 UINT             hsFiringSetValueStatus;
 UINT             hsBoilerSetValueStatus;
 UINT			  segmentForceTimeout;
 BOOL             messageAlarm[MAX_MESSAGE_ALARMS];
 USINT            hsEcoInputCompletion;
} visuInterface_s;

typedef struct firingInf_s
{
 USINT enable;
 USINT res0;
 REAL  actTemp;
 REAL  setTemp;
 UDINT runTime;
 UDINT minRunTime;
 USINT cmdService;
 USINT res1;
} firingInf_s;


typedef struct boilerInf_s
{
 USINT enable;
 USINT res0;
 REAL  actTemp;
 REAL  setTemp;
 UDINT delayTime;
 UDINT delayTimeOut;
 UDINT minDutyCycle;
 UDINT offDutyTimer;
 USINT dutyRequest;
 USINT cmdService;
} boilerInf_s;


typedef struct hsFireInf_s
{
 USINT 			eStop;
 REAL  			minSetTemp;
 REAL  			maxSetTemp;
 REAL  			actTempHyst;
 firingInf_s	firingInf;
 boilerInf_s 	boilerInf;
} hsFireInf_s;

typedef struct hsMgrInf_s
{
 USINT activeHeatingMode;
 USINT activeHeatingProgramm;
 REAL  dayOffset;
 REAL  nightOffset;
 REAL  notAtHomeOffset;
 REAL  manTempOffset;
 REAL  hotWaterSetTemp;
 REAL  outsideTemp;
} hsMgrInf_s;

typedef struct lcParInf_s
{
 REAL  w;
 REAL  x;
 REAL  e;
 REAL  eMax;
 REAL  y;
 REAL  kp;
 REAL  ki;
 REAL  tn;
 REAL  kd;
 REAL  intPart;
 REAL  diffPart;
 REAL  loLimit;
 REAL  hiLimit;
} lcParInf_s;

typedef struct lcHeatingInf_s
{
 USINT 		enable;
 USINT      enableFiringLevel;
 REAL  		setTempOffset;
 lcParInf_s lcParInf;
 UDINT 		delayTime;
 UDINT 		delayTimeOut;
 UDINT 		minDutyCycle;
 UDINT 		offDutyTimer;
 USINT 		dutyRequest;
} lcHeatingInf_s;

typedef struct lcHotWaterInf_s
{
 USINT enable;
 REAL  setTemp;
} lcHotWaterInf_s;

typedef struct lcMixerInf_s
{ 
 USINT cmdHoming;
 USINT setPosition;
 USINT oldSetPosition;
 USINT actPosition;
 USINT startPosition;
 SINT  dir;
 UDINT fullyOpenTime;
 UDINT deadTime;
 UDINT posTimer;
 UDINT setPosTime;
 USINT cmdService;
 USINT servPosition;
} lcMixerInf_s;

typedef struct hsLoopInf_s
{
 REAL 				flowPipeTemp;
 USINT 				eStop;
 USINT              cmdService;
 lcHeatingInf_s 	lcHeatingInf;
 lcHotWaterInf_s 	lcHotWaterInf;
 lcMixerInf_s 		lcMixerInf;
} hsLoopInf_s;


typedef struct periodeInf_s
{ 
  time_s startTime;
  time_s endTime;
} periodeInf_s;

typedef struct basicProgrammInf_s
{
 USINT		  name[32];
 periodeInf_s heating;
 periodeInf_s hotWaterPhase[NB_HOT_WATER_PHASES];
} basicProgrammInf_s;


typedef struct dateProgrammInf_s
{ 
  basicProgrammInf_s 	basicProgrammInf;
  DTStructure 			startDate;
  DTStructure 			endDate;
} dateProgrammInf_s;


typedef struct dayProgrammInf_s
{ 
  basicProgrammInf_s 	basicProgrammInf;
  USINT 				startDay;
  USINT	 				endDay;
} dayProgrammInf_s;

typedef struct trendChartInf_s
{
 UDINT	id;
 UINT	nbValues;
 UINT	samplesWidth;
 plcbit	gridEnable;
 UINT	gridX;
 UINT	gridY;
 UDINT 	status;
 USINT  forceChartDraw;
} trendChartInf_s;

typedef struct trendCurveInf_s
{
 plcbit  enable;
 UDINT	*pData;
} trendCurveInf_s;

typedef struct yearTrendInf_s
{
 USINT 	inputCompleted;
 UINT  	year;
} yearTrendInf_s;


typedef struct bufferInf_s
{
 REAL  *pBuffer;
 UDINT index;
 REAL  nbElements;
 REAL  sumValue;
} bufferInf_s;

typedef struct ecoOutsideTemp_s
{ 
 USINT       enable;
 USINT       cmdMovAvBuffer;
 bufferInf_s movAvBufferInf;
 REAL        movAvTemp;
} ecoOutsideTemp_s;

typedef struct ecoLivingRoomTemp_s
{ 
 USINT enable;
 USINT release;
 REAL  actTemp;     
 REAL  setTemp;     
 REAL  actTempHyst;
} ecoLivingRoomTemp_s;

typedef struct ecoFiring_s
{ 
 USINT enable;
 USINT release;
 REAL  minSetTemp;     
 REAL  setTempHyst;
 UDINT toggleDelayTimer;
 UDINT toggleDelay;
} ecoFiring_s;

typedef struct ecoNoon_s
{ 
 USINT enable;
 USINT release;
 REAL  minTemp;     
 UDINT offTimer;
 UDINT offTime;
} ecoNoon_s;

typedef struct hsEcoInf_s
{
 ecoOutsideTemp_s    outsideTemp;
 ecoLivingRoomTemp_s livingRoomTemp;
 ecoFiring_s         firing;
 ecoNoon_s           noon;
} hsEcoInf_s;


/*** global variables ***/
_GLOBAL bmsStatistic_s      BMSstatistic;
_GLOBAL DTStructure         CurrentTime;
_GLOBAL visuInterface_s     VisuInterface;
_GLOBAL hsFireInf_s			HsFireInf;
_GLOBAL hsMgrInf_s			HsMgrInf;
_GLOBAL hsLoopInf_s			HsLoopInf;
_GLOBAL hsEcoInf_s			HsEcoInf;


/*** prototyping ***/
UINT CheckIrrigationSchedule(ipDaySchedule_s *pSchedule, segment_s *pSegment, DTStructure *pCurrentTime);
UINT DateWithinBeginEnd(DTStructure *pBegin, DTStructure *pEnd, DTStructure *pCurrentTime);
UINT DateIsValid(DTStructure *pBegin, DTStructure *pEnd);
UINT TimeWithinBeginEnd(time_s *pBegin, time_s *pEnd, DTStructure *pCurrentTime);
UINT TimeIsValid(time_s *pBegin, time_s *pEnd);
UINT DayWithinBeginEnd(USINT *pBegin, USINT *pEnd, DTStructure *pCurrentTime);
void lc2Point(REAL setValue, REAL actValue, REAL hysteresis, SINT *pOutput);
void lcLimit(REAL *pValue, REAL minValue, REAL maxValue);
void lcPI(REAL w, REAL x, REAL *pE, REAL eMax, REAL *pY, REAL kp, REAL ki, REAL *pIntPart, REAL loLimit, REAL hiLimit);
void lcAntiWindup(REAL *pIntPart, REAL e, REAL iMax, REAL eMax);
void getTimeFlags(DTStructure *pCurrentTime, USINT *pNewHour, USINT *pOldHour, USINT *pNewMinute, USINT *pOldMinute, USINT *pNewSecond, USINT *pOldSecond);
void HeatingHotWaterMgr(basicProgrammInf_s *pBasicProgramm, DTStructure *pCurrentTime, hsMgrInf_s *pHsMgrInf, hsLoopInf_s *pHsLoopInf, visuInterface_s *pVisuInterface);
UINT NewDataObject(DatObjCreate_typ *pfDatObjCreate, DatObjDelete_typ *pfDatObjDelete, USINT *pFileName, USINT memType, UDINT option, void *pData, UDINT sizeOfData, dataObjInf_s *pDataObjInf);
REAL getChartValueY(REAL inValueX, xyChartElement_s *pChartElement, UDINT nbEntries);
REAL calcK(REAL x1, REAL y1, REAL x2, REAL y2);
REAL calcD(REAL x1, REAL y1, REAL x2, REAL y2);
REAL calcY(REAL x, REAL k, REAL d);
void mixerControl(USINT *pCmdHoming, USINT setPosition, USINT *pOldSetPosition, USINT *pActPosition, USINT *pStartPosition, UDINT fullyOpenTime, UDINT deadTime, UDINT *pPosTimer, UDINT *pSetPosTime, SINT *pDir, UDINT cycT);
void applyUserInput(USINT *pSelect, USINT maxSelect, USINT firstSelect, UDINT *pTimer, UDINT delay, USINT *pTempSelect, USINT *pApplySelect, USINT *pNewSelection, UDINT cycT);
UDINT round(REAL value);
UINT getDayOfYear(DTStructure *pDate);
UINT isLeapYear(UINT year);
REAL absREAL(REAL value);
DINT myPow(DINT base, DINT n);
void movAv( bufferInf_s *pBufferInf, REAL newValue, REAL *pMovAvValue );


#endif

