/*********************************************************************************************
*  Copyright: 2002 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Managment System                                                    *
*    Purpose    trend handling of heating system                                             *
*                                                                                            *
*    Filename   hs_trend.c                                                                   *
*--------------------------------------------------------------------------------------------*
*  Description :                                                                             *
*    Picture 30.0: outside temp./leading temp. chart                                         *
*    Picture 30.1: outside temp./leading temp. chart original curve adjustment               *
*    Picture 30.5: outside temp. and heating minutes chart                                   *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  History :                                                                                 *
*  Version       Datum         Autor                                                         *
*  01.00         08.06.02      W. Paulin     Created                                         *
*********************************************************************************************/

#include <bur/plctypes.h>
#include <bms_gn.h>

_LOCAL dataObjInf_s 		dataObjOutLeadTemp;
_LOCAL dataObjInf_s 		dataObjTempYear;
_LOCAL dataObjInf_s 		dataObjHeatYear;
_LOCAL DatObjInfo_typ		fDatObjInfo;
_LOCAL DatObjWrite_typ		fDatObjWrite;
_LOCAL DatObjCreate_typ		fDatObjCreate;

_LOCAL RTInfo_typ			fRTInfo;

_LOCAL UDINT 				vcHandle;
_LOCAL UDINT 				loopIndex;
_LOCAL UDINT 				subLoopIndex;

_LOCAL REAL 				oldManTempOffset;
_LOCAL REAL 				oldDayOffset;
_LOCAL REAL 				oldNightOffset;
_LOCAL REAL 				oldNotAtHomeOffset;

_LOCAL trendChartInf_s		outLeadChartInf;
_LOCAL trendCurveInf_s		originalCurveInf;
_LOCAL trendCurveInf_s		dayCurveInf;
_LOCAL trendCurveInf_s		nightCurveInf;
_LOCAL trendCurveInf_s		notAtHomeCurveInf;

_LOCAL REAL					chartXmin;
_LOCAL REAL					chartXmiddle;
_LOCAL REAL					chartXmax;

_LOCAL USINT				oldPictNr;
       
_LOCAL trendChartInf_s		tempChartInf;
_LOCAL trendCurveInf_s		tempCurveInf[CHART_YEAR_TREND_MAX_CURVE];

_LOCAL trendChartInf_s		heatChartInf;
_LOCAL trendCurveInf_s		heatCurveInf[CHART_YEAR_TREND_MAX_CURVE];

_LOCAL yearTrendInf_s		yearTrendInf[CHART_YEAR_TREND_MAX_CURVE];

_LOCAL USINT				trendDOname[8+1];

_LOCAL UINT					status;

_LOCAL UDINT				cycT;

_LOCAL USINT            	newHour;
_LOCAL USINT            	oldHour;
_LOCAL USINT            	newMinute;
_LOCAL USINT            	oldMinute;
_LOCAL UDINT 				heatingMinutesPerDay;
_LOCAL UDINT				oldOnTimeFiring;

_LOCAL USINT				tempDebug;
_LOCAL UINT					catDayOfYear;
_LOCAL REAL					catReadTemp;
_LOCAL REAL					catWriteTemp;
_LOCAL DatObjRead_typ		fDatObjRead;
_LOCAL USINT				catWriteTrigger;


_INIT void hs_trendini(void)
{
 fRTInfo.enable = 1; 
 RTInfo(&fRTInfo);
 
 cycT = fRTInfo.cycle_time / 1000;					/* transform cycle time us -> ms */

 /* get chart of leading temperature according to outside temperature /Begin */
 fDatObjInfo.enable = 1;
 fDatObjInfo.pName = (UDINT)CHART_OUTSIDE_LEADING_TEMP_DO_NAME;
 
 DatObjInfo(&fDatObjInfo);										/* get schedule */
 
 if (fDatObjInfo.status == ERR_OK)								/* error ? */
   {
    dataObjOutLeadTemp.pData     = fDatObjInfo.pDatObjMem;		/* pointer to chart */
    dataObjOutLeadTemp.doIdent   = fDatObjInfo.ident;			/* ident of data object containing chart */
    dataObjOutLeadTemp.doLength  = fDatObjInfo.len;				/* length of data in data object */
    dataObjOutLeadTemp.doMemType = fDatObjInfo.MemType;			/* memory of data object containing chart */
    dataObjOutLeadTemp.doOption  = fDatObjInfo.Option;			/* additional options of data object containing chart */
   }
 else
   {
    memset( &dataObjOutLeadTemp, 0, sizeof(dataObjOutLeadTemp) );
    VisuInterface.heatingAlarm[HEATING_OUTSIDE_LEADING_DO_ERROR] = 1;
   }
 /* get chart of leading temperature according to outside temperature /End */
 
 /* check if there are enough elements in VisuInterface to store Data Object Information */
 if ((dataObjOutLeadTemp.doLength / sizeof(xyChartElement_s)) > (sizeof(VisuInterface.hsAdjOutLeadTemp) / sizeof(xyChartElement_s))) 
   ERRxfatal(dataObjOutLeadTemp.doLength , sizeof(VisuInterface.hsAdjOutLeadTemp), "hs_trend: hsAdjOutLeadTemp too small");

 /* allocate data buffer for temperature trend /Begin */
 for (loopIndex = 0; loopIndex < CHART_YEAR_TREND_MAX_CURVE; loopIndex++)
 {
  status = TMP_alloc( CHART_YEAR_TREND_MAX_DAYS * sizeof(REAL), (void**)&tempCurveInf[loopIndex].pData );
  if (status) ERRxwarning(status, loopIndex, "hs_trend: allocate temperature buffer");
 }
 
 /* allocate data buffer for heating minutes trend */
 for (loopIndex = 0; loopIndex < CHART_YEAR_TREND_MAX_CURVE; loopIndex++)
 {
  status = TMP_alloc( CHART_YEAR_TREND_MAX_DAYS * sizeof(UDINT), (void**)&heatCurveInf[loopIndex].pData );
  if (status) ERRxwarning(status, loopIndex, "hs_trend: allocate heating buffer");
 }
 
 /* get temperature trend data of current year /Begin */
 fDatObjInfo.enable = 1;

 strcpy( &trendDOname[0], TEMP_TREND_DO_NAME_TEMPLATE );			/* "temp_xx" */
 trendDOname[5] = (CurrentTime.year % 100) / 10 + '0';	/* 2001 -> 0 -> '0' */
 trendDOname[6] = (CurrentTime.year % 100) % 10 + '0';	/* 2001 -> 1 -> '1' */

 fDatObjInfo.pName = (UDINT)&trendDOname[0];
 
 DatObjInfo(&fDatObjInfo);												
 
 /* if it does not exist -> create it */
 if ( (fDatObjInfo.status == ERR_OK) && (CHART_YEAR_TREND_MAX_DAYS == fDatObjInfo.len / sizeof(REAL)) )
   {
    dataObjTempYear.pData     = fDatObjInfo.pDatObjMem;							/* pointer to statistic information */
    dataObjTempYear.doIdent   = fDatObjInfo.ident;								/* ident of data object containing statistic information */
    dataObjTempYear.doLength  = fDatObjInfo.len;								/* length of data in data object */
    dataObjTempYear.doMemType = fDatObjInfo.MemType;							/* memory of data object containing statistic information */
    dataObjTempYear.doOption  = fDatObjInfo.Option;								/* additional options of data object containing statistic information */
   }
 else
   {
    fDatObjCreate.enable   = 1;
    fDatObjCreate.pName    = fDatObjInfo.pName;
    fDatObjCreate.len      = CHART_YEAR_TREND_MAX_DAYS * sizeof(REAL);
    fDatObjCreate.MemType  = doUSRROM;
    fDatObjCreate.Option   = 0;
    fDatObjCreate.pCpyData = 0;
    
    DatObjCreate(&fDatObjCreate);

    if (fDatObjCreate.status == ERR_OK)
      { 		
       dataObjTempYear.pData     = fDatObjCreate.pDatObjMem;					/* pointer to segment information */
       dataObjTempYear.doIdent   = fDatObjCreate.ident;							/* ident of data object containing schedule */
       dataObjTempYear.doLength  = fDatObjCreate.len;							/* length of data in data object */
       dataObjTempYear.doMemType = fDatObjCreate.MemType;						/* memory of data object containing schedule */
       dataObjTempYear.doOption  = fDatObjCreate.Option;						/* additional options of data object containing schedule */
      }
   }
 /* get temperature trend data of current year /End */

 /* get heating minutes trend data of current year /Begin */
 fDatObjInfo.enable = 1;

 strcpy( &trendDOname[0], HEAT_TREND_DO_NAME_TEMPLATE );			/* "heat_xx" */
 trendDOname[5] = (CurrentTime.year % 100) / 10 + '0';	/* 2001 -> 0 -> '0' */
 trendDOname[6] = (CurrentTime.year % 100) % 10 + '0';	/* 2001 -> 1 -> '1' */

 fDatObjInfo.pName = (UDINT)&trendDOname[0];
 
 DatObjInfo(&fDatObjInfo);												
 
 /* if it does not exist -> create it */
 if ( (fDatObjInfo.status == ERR_OK) && (CHART_YEAR_TREND_MAX_DAYS == fDatObjInfo.len / sizeof(UDINT)) )
   {
    dataObjHeatYear.pData     = fDatObjInfo.pDatObjMem;							/* pointer to statistic information */
    dataObjHeatYear.doIdent   = fDatObjInfo.ident;								/* ident of data object containing statistic information */
    dataObjHeatYear.doLength  = fDatObjInfo.len;								/* length of data in data object */
    dataObjHeatYear.doMemType = fDatObjInfo.MemType;							/* memory of data object containing statistic information */
    dataObjHeatYear.doOption  = fDatObjInfo.Option;								/* additional options of data object containing statistic information */
   }
 else
   {
    fDatObjCreate.enable   = 1;
    fDatObjCreate.pName    = fDatObjInfo.pName;
    fDatObjCreate.len      = CHART_YEAR_TREND_MAX_DAYS * sizeof(UDINT);
    fDatObjCreate.MemType  = doUSRROM;
    fDatObjCreate.Option   = 0;
    fDatObjCreate.pCpyData = 0;
    
    DatObjCreate(&fDatObjCreate);

    if (fDatObjCreate.status == ERR_OK)
      { 		
       dataObjHeatYear.pData     = fDatObjCreate.pDatObjMem;					/* pointer to segment information */
       dataObjHeatYear.doIdent   = fDatObjCreate.ident;							/* ident of data object containing schedule */
       dataObjHeatYear.doLength  = fDatObjCreate.len;							/* length of data in data object */
       dataObjHeatYear.doMemType = fDatObjCreate.MemType;						/* memory of data object containing schedule */
       dataObjHeatYear.doOption  = fDatObjCreate.Option;						/* additional options of data object containing schedule */
      }
   }
 /* get heating minutes trend data of current year /End */
 
 oldOnTimeFiring = BMSstatistic.heatingStatistic.onTimeFiring;					/* in case of boot up: minimize error by keeping current value in mind */
}


_CYCLIC void hs_trendcyc(void)
{
 /* generate new hour and new minute time flags */
 getTimeFlags( &CurrentTime, &newHour, &oldHour, &newMinute, &oldMinute, 0, 0);


 /* get handle to vc interpreter */
 if (vcHandle == 0)
   vcHandle = VA_Setup(1, "visu");

 if (tempDebug)
   {
    fDatObjRead.enable = 1;
    fDatObjRead.ident  = dataObjTempYear.doIdent;
    fDatObjRead.Offset = sizeof(REAL) * (catDayOfYear - 1);
    fDatObjRead.pDestination = (UDINT)&catReadTemp; 
    fDatObjRead.len    = sizeof(catReadTemp);
 
    DatObjRead(&fDatObjRead);

    if (catWriteTrigger)
      {
       fDatObjWrite.enable  = 1;
       fDatObjWrite.ident   = dataObjTempYear.doIdent;
       fDatObjWrite.Offset  = sizeof(REAL) * (catDayOfYear - 1);
       fDatObjWrite.pSource = (UDINT)&catWriteTemp;
       fDatObjWrite.len     = sizeof(catWriteTemp);
    
       DatObjWrite(&fDatObjWrite);
    
       catWriteTrigger = 0;
      }
   }

 /***********************************************************************************************************************/
 /*** ACQUISITION OF STATISTICAL DATA                                                                                 ***/
 /***********************************************************************************************************************/
 /* store temperature per day every day at 12:00 o'clock noon */
 if ((CurrentTime.hour == 12) && (newHour))
   {
    fDatObjWrite.enable  = 1;
    fDatObjWrite.ident   = dataObjTempYear.doIdent;
    fDatObjWrite.Offset  = sizeof(REAL) * (getDayOfYear(&CurrentTime) - 1);
    fDatObjWrite.pSource = (UDINT)&HsMgrInf.outsideTemp;
    fDatObjWrite.len     = sizeof(HsMgrInf.outsideTemp);
    
    DatObjWrite(&fDatObjWrite);
    
    if (fDatObjWrite.status != ERR_OK) 
      {
       dataObjTempYear.nbWrErr++;
       dataObjTempYear.lstWrErr = fDatObjWrite.status;
       VisuInterface.heatingAlarm[HEATING_TREND_TEMPERATUR_DO_ERROR] = 1;
       ERRxwarning(fDatObjWrite.status, 0, "write temp. trend data");
      }
   }

 /* store heating minutes per day at 0:00 o'clock midnight */
 if ((CurrentTime.hour == 0) && (newHour))
   {
    /* minutes per day = actual value - value of the day before */
    heatingMinutesPerDay = BMSstatistic.heatingStatistic.onTimeFiring - oldOnTimeFiring;
    oldOnTimeFiring      = BMSstatistic.heatingStatistic.onTimeFiring;
    
    fDatObjWrite.enable  = 1;
    fDatObjWrite.ident   = dataObjHeatYear.doIdent;
    fDatObjWrite.Offset  = sizeof(UDINT) * (getDayOfYear(&CurrentTime) - 1);
    fDatObjWrite.pSource = (UDINT)&heatingMinutesPerDay;
    fDatObjWrite.len     = sizeof(heatingMinutesPerDay);
    
    DatObjWrite(&fDatObjWrite);
    
    if (fDatObjWrite.status != ERR_OK) 
      {
       dataObjHeatYear.nbWrErr++;
       dataObjHeatYear.lstWrErr = fDatObjWrite.status;
       VisuInterface.heatingAlarm[HEATING_TREND_HEATING_DO_ERROR] = 1;
       ERRxwarning(fDatObjWrite.status, 0, "write heat. trend data");
      }
   }
 

 /***********************************************************************************************************************/
 /*** CHART ADJUSTMENT in 30.1                                                                                        ***/
 /***********************************************************************************************************************/
 if (VisuInterface.curPictNr == PIC_30_1)
   {
    if (VisuInterface.curPictNr != oldPictNr)        										/* if entered */
      {
       /* copy current xy-point information in buffer to be adjusted by visualisation */
       memcpy( &VisuInterface.hsAdjOutLeadTemp[0], (void*)dataObjOutLeadTemp.pData, sizeof(VisuInterface.hsAdjOutLeadTemp) );
      }
         
    /* force redraw if value has been entered */
    if (VisuInterface.hsXyChartElementInputCompletion)
      {
       outLeadChartInf.forceChartDraw                = 1;
       VisuInterface.hsXyChartElementInputCompletion = 0;
      }

    /* undo user changes */
    if (VisuInterface.hsChartUndo == 1) 
      {
       VisuInterface.hsChartUndo      = 0;
       outLeadChartInf.forceChartDraw = 1;
       memcpy( &VisuInterface.hsAdjOutLeadTemp[0], (void*)dataObjOutLeadTemp.pData, sizeof(VisuInterface.hsAdjOutLeadTemp) );
      }
      
    /* save chart data /Begin */
    if (VisuInterface.hsChartSave == 1) 
      {
       fDatObjWrite.enable  = 1;
       fDatObjWrite.ident   = dataObjOutLeadTemp.doIdent;
       fDatObjWrite.Offset  = 0;
       fDatObjWrite.pSource = (UDINT)&VisuInterface.hsAdjOutLeadTemp;
       fDatObjWrite.len     = sizeof(VisuInterface.hsAdjOutLeadTemp);
    
       DatObjWrite(&fDatObjWrite);
    
       if (fDatObjWrite.status != ERR_OK) 
         {
          dataObjOutLeadTemp.nbWrErr++;
          dataObjOutLeadTemp.lstWrErr = fDatObjWrite.status;
          VisuInterface.heatingAlarm[HEATING_OUTSIDE_LEADING_DO_ERROR] = 1;
          ERRxwarning(fDatObjWrite.status, 0, "write chart out/lead temp.");
         }
      }

    /* animation - progress bar */
    if (VisuInterface.hsChartSave == 1)
      {
       VisuInterface.progressBarInf.index = 1;											/* start progress bar */
       VisuInterface.hsChartSave = 0;
      }
    else if ( (VisuInterface.progressBarInf.index > 0) && 
              (VisuInterface.progressBarInf.index < VisuInterface.progressBarInf.nbElements - 1) ) 									/* start progress bar if save has been actived */
      {
       if (VisuInterface.progressBarInf.timer >= VisuInterface.progressBarInf.duration)
         {
          VisuInterface.progressBarInf.timer = 0;
          VisuInterface.progressBarInf.index++;											/* next bitmap to increase progress bar */
         }
       else
         {
          VisuInterface.progressBarInf.timer += cycT;
         }
      }
    /* save chart data /End */
   }




 /***********************************************************************************************************************/
 /*** CHART CONTROL in 30.0                                                                                           ***/
 /***********************************************************************************************************************/
 /* set up chart for leading temperature according to outside temperature if not yet done /Begin */
 if (outLeadChartInf.id == 0)
   {
    outLeadChartInf.gridEnable = 1;													/* switch on grid */
    outLeadChartInf.nbValues   = dataObjOutLeadTemp.doLength / sizeof(xyChartElement_s);

    /* dynamic axis labeling for x-axis */
    chartXmin    = ((xyChartElement_s *)dataObjOutLeadTemp.pData)[0].x;
    chartXmiddle = ((xyChartElement_s *)dataObjOutLeadTemp.pData)[outLeadChartInf.nbValues / 2].x;
    chartXmax    = ((xyChartElement_s *)dataObjOutLeadTemp.pData)[outLeadChartInf.nbValues - 1].x;

    /* set width of samples according to width of chart and how many values should fit in chart */
    outLeadChartInf.samplesWidth = (CHART_OUTSIDE_LEADING_TEMP_WIDTH - 1) / outLeadChartInf.nbValues;

    /* convert X grid width from �C to pixel according width of chart and value range */
    outLeadChartInf.gridX = CHART_OUTSIDE_LEADING_TEMP_WIDTH / 														/* width of chart */
                            ( 
                             (( ((xyChartElement_s *)dataObjOutLeadTemp.pData)[outLeadChartInf.nbValues - 1].x - 	/* value range */
                               ((xyChartElement_s *)dataObjOutLeadTemp.pData)[0].x ) /
                             CHART_OUTSIDE_LEADING_TEMP_GRID_X) + 1													/* grid with in �C */
                            );													


    /* convert Y grid width from �C to pixel according to height of chart and value range */
    outLeadChartInf.gridY = CHART_OUTSIDE_LEADING_TEMP_HEIGHT / 													/* height of chart */
                            (
                             (CHART_OUTSIDE_LEADING_TEMP_MAX_Y - CHART_OUTSIDE_LEADING_TEMP_MIN_Y) /				/* value range */
                              CHART_OUTSIDE_LEADING_TEMP_GRID_Y														/* grid with in �C */		
                            );									


    outLeadChartInf.status = TR_init( &outLeadChartInf.id, 						/* init trend */
                                       vcHandle, 
                                       CHART_OUTSIDE_LEADING_TEMP_MAX_CURVE, 
                                       outLeadChartInf.nbValues,
                                       CHART_OUTSIDE_LEADING_TEMP_UPPER_LEFT_X, 
                                       CHART_OUTSIDE_LEADING_TEMP_UPPER_LEFT_Y, 
                                       outLeadChartInf.samplesWidth, 
                                       CHART_OUTSIDE_LEADING_TEMP_HEIGHT,
                                       outLeadChartInf.gridX, 
                                       outLeadChartInf.gridY, 
                                       CHART_OUTSIDE_LEADING_TEMP_GRID_COLOR, 
                                      &outLeadChartInf.gridEnable, 
                                       CHART_OUTSIDE_LEADING_TEMP_BACK_COLOR, 
                                       CHART_OUTSIDE_LEADING_TEMP_FORE_COLOR );
                                        
    if (outLeadChartInf.status == 0)												/* if init ok -> add all curves to chart */
      {
       /* original curve */
       outLeadChartInf.status = TR_addCurve(  outLeadChartInf.id, 
                                              0,									/* static trend */ 
                                              (UDINT *)&originalCurveInf.pData,
                                             &originalCurveInf.enable, 
                                              CHART_OUTSIDE_LEADING_TEMP_MIN_Y, 
                                              CHART_OUTSIDE_LEADING_TEMP_MAX_Y, 
                                              CHART_OUTSIDE_LEADING_TEMP_ORIGINAL_CURVE_COLOR );
       if (outLeadChartInf.status)
         ERRxwarning( (UINT)outLeadChartInf.status, 0, "hs_trend: add original curve");

       /* day curve */
       outLeadChartInf.status = TR_addCurve(  outLeadChartInf.id, 
                                              0,									/* static trend */ 
                                              (UDINT *)&dayCurveInf.pData,
                                             &dayCurveInf.enable, 
                                              CHART_OUTSIDE_LEADING_TEMP_MIN_Y, 
                                              CHART_OUTSIDE_LEADING_TEMP_MAX_Y, 
                                              CHART_OUTSIDE_LEADING_TEMP_DAY_CURVE_COLOR );
       if (outLeadChartInf.status)
         ERRxwarning( (UINT)outLeadChartInf.status, 0, "hs_trend: add day curve");

       /* night curve */
       outLeadChartInf.status = TR_addCurve(  outLeadChartInf.id, 
                                              0,									/* static trend */ 
                                              (UDINT *)&nightCurveInf.pData,
                                             &nightCurveInf.enable, 
                                              CHART_OUTSIDE_LEADING_TEMP_MIN_Y, 
                                              CHART_OUTSIDE_LEADING_TEMP_MAX_Y, 
                                              CHART_OUTSIDE_LEADING_TEMP_NIGHT_CURVE_COLOR );
       if (outLeadChartInf.status)
         ERRxwarning( (UINT)outLeadChartInf.status, 0, "hs_trend: add night curve");

       /* not at home curve */
       outLeadChartInf.status = TR_addCurve(  outLeadChartInf.id, 
                                              0,									/* static trend */ 
                                              (UDINT *)&notAtHomeCurveInf.pData,
                                             &notAtHomeCurveInf.enable, 
                                              CHART_OUTSIDE_LEADING_TEMP_MIN_Y, 
                                              CHART_OUTSIDE_LEADING_TEMP_MAX_Y, 
                                              CHART_OUTSIDE_LEADING_TEMP_NOT_AT_HOME_CURVE_COLOR );
       if (outLeadChartInf.status)
         ERRxwarning( (UINT)outLeadChartInf.status, 0, "hs_trend: add not at home curve");
      } /* if (outLeadChartInf.id == 0) */
   } /* if (outLeadChartInf.id == 0) */
 /* set up chart for leading temperature according to outside temperature if not yet done /End */


 /* draw chart only in 30.0 or 30.1 and if handle to vc interpreter exists /Begin */
 if ( ((VisuInterface.curPictNr == PIC_30_0) || (VisuInterface.curPictNr == PIC_30_1)) && (vcHandle != 0) )
   {
    if ( (VisuInterface.curPictNr  != oldPictNr)        ||			/* draw chart if entered           */
         (HsMgrInf.manTempOffset   != oldManTempOffset) ||			/* user changed manual offset      */
         (HsMgrInf.dayOffset       != oldDayOffset)	    ||			/* user changed day offset         */
         (HsMgrInf.nightOffset     != oldNightOffset)   ||			/* user changed night offset       */
         (HsMgrInf.notAtHomeOffset != oldNotAtHomeOffset) )			/* user changed not at home offset */
      {
       outLeadChartInf.forceChartDraw = 1;
       oldManTempOffset   = HsMgrInf.manTempOffset;
       oldDayOffset       = HsMgrInf.dayOffset;
       oldNightOffset     = HsMgrInf.nightOffset;
       oldNotAtHomeOffset = HsMgrInf.notAtHomeOffset;
      }

    /* or any change by user or problems during last drawing (immediately after entering 30.0) */
    if (outLeadChartInf.forceChartDraw)
      {
       outLeadChartInf.forceChartDraw = 0;

       /* prepare curves for display (visible, data) /Begin */
       switch (VisuInterface.curPictNr)    
       {
        case PIC_30_0:
          originalCurveInf.enable    = 1;
          dayCurveInf.enable         = 1;
          nightCurveInf.enable       = 1;
          notAtHomeCurveInf.enable   = 1;

          /* copy curve data in buffer */
          for ( loopIndex = 0; 
               (loopIndex < outLeadChartInf.nbValues) && (originalCurveInf.pData != 0) && (dayCurveInf.pData != 0) && (nightCurveInf.pData != 0) && (notAtHomeCurveInf.pData != 0) && (dataObjOutLeadTemp.pData != 0); 
                loopIndex++ 
              )
            {
             originalCurveInf.pData[loopIndex]  = round( ((xyChartElement_s *)dataObjOutLeadTemp.pData)[loopIndex].y );
             dayCurveInf.pData[loopIndex]       = round( ((xyChartElement_s *)dataObjOutLeadTemp.pData)[loopIndex].y + HsMgrInf.dayOffset       + HsMgrInf.manTempOffset );
             nightCurveInf.pData[loopIndex]     = round( ((xyChartElement_s *)dataObjOutLeadTemp.pData)[loopIndex].y + HsMgrInf.nightOffset     + HsMgrInf.manTempOffset );
             notAtHomeCurveInf.pData[loopIndex] = round( ((xyChartElement_s *)dataObjOutLeadTemp.pData)[loopIndex].y + HsMgrInf.notAtHomeOffset + HsMgrInf.manTempOffset );
            }
        break;
        
        case PIC_30_1:
          originalCurveInf.enable    = 1;
          dayCurveInf.enable         = 0;
          nightCurveInf.enable       = 0;
          notAtHomeCurveInf.enable   = 0;

          /* copy curve data in buffer */
          for ( loopIndex = 0; 
               (loopIndex < outLeadChartInf.nbValues) && (originalCurveInf.pData != 0); 
                loopIndex++ 
              )
            {
             originalCurveInf.pData[loopIndex] = round( VisuInterface.hsAdjOutLeadTemp[loopIndex].y );
            }
        break;
       }
       /* prepare curves for display (visible, data) /End */

       
       /* clear chart */
       outLeadChartInf.status = TR_redraw(outLeadChartInf.id);
       if (outLeadChartInf.status != 0) outLeadChartInf.forceChartDraw = 1;		/* on error - once again */

       /* draw chart */
       outLeadChartInf.status = TR_sDraw(outLeadChartInf.id);
       if (outLeadChartInf.status != 0) outLeadChartInf.forceChartDraw = 1;		/* on error - once again */
      }
   } /* if ( ((VisuInterface.curPictNr == PIC_30_0) || (VisuInterface.curPictNr == PIC_30_1)) && (vcHandle != 0) ) */
 /* draw chart only in 30.0 or 30.1 and if handle to vc interpreter exists /End */




 /***********************************************************************************************************************/
 /*** CHART CONTROL in 30.5                                                                                           ***/
 /***********************************************************************************************************************/
 /* set up chart for temperature trend if not yet done /Begin */
 if (tempChartInf.id == 0)
   {
    tempChartInf.gridEnable = 1;														/* switch on grid */
    tempChartInf.nbValues   = CHART_YEAR_TREND_MAX_DAYS;
    
    /* set width of samples according to width of chart and how many values should fit in chart */
    tempChartInf.samplesWidth = (CHART_YEAR_TEMP_TREND_WIDTH - 1) / tempChartInf.nbValues;

    /* convert X grid width from day to pixel according width of chart and value range */
    tempChartInf.gridX = CHART_YEAR_TEMP_TREND_WIDTH / 									/* width of chart */
                         ( 
                          (CHART_YEAR_TREND_MAX_DAYS /									/* day per year */
                          CHART_YEAR_TEMP_TREND_GRID_X) + 1								/* grid with in days */
                         );													

    /* convert Y grid width from �C to pixel according to height of chart and value range */
    tempChartInf.gridY = CHART_YEAR_TEMP_TREND_HEIGHT / 											/* height of chart */
                            (
                             (CHART_YEAR_TEMP_TREND_MAX_Y - CHART_YEAR_TEMP_TREND_MIN_Y) /			/* value range */
                              CHART_YEAR_TEMP_TREND_GRID_Y											/* grid with in �C */		
                            );									


    tempChartInf.status = TR_init( &tempChartInf.id, 									/* init trend */
                                    vcHandle, 
                                    CHART_YEAR_TREND_MAX_CURVE, 
                                    tempChartInf.nbValues,
                                    CHART_YEAR_TEMP_TREND_UPPER_LEFT_X, 
                                    CHART_YEAR_TEMP_TREND_UPPER_LEFT_Y, 
                                    tempChartInf.samplesWidth, 
                                    CHART_YEAR_TEMP_TREND_HEIGHT,
                                    tempChartInf.gridX, 
                                    tempChartInf.gridY, 
                                    CHART_YEAR_TEMP_TREND_GRID_COLOR, 
                                   &tempChartInf.gridEnable, 
                                    CHART_YEAR_TEMP_TREND_BACK_COLOR, 
                                    CHART_YEAR_TEMP_TREND_FORE_COLOR );
                                        
    if (tempChartInf.status == 0)														/* if init ok -> add all curves to chart */
      {
       for (loopIndex = 0; loopIndex < CHART_YEAR_TREND_MAX_CURVE; loopIndex++)
       {
        tempChartInf.status = TR_addCurve(  tempChartInf.id, 
                                            0,											/* static trend */ 
                                            (UDINT *)&tempCurveInf[loopIndex].pData,
                                           &tempCurveInf[loopIndex].enable, 
                                            CHART_YEAR_TEMP_TREND_MIN_Y, 
                                            CHART_YEAR_TEMP_TREND_MAX_Y, 
                                            (USINT)loopIndex );
        if (tempChartInf.status)
          ERRxwarning( (UINT)tempChartInf.status, loopIndex, "hs_trend: add temperature curve");
       }
      } /* if (tempChartInf.id == 0) */
   } /* if (tempChartInf.id == 0) */
 /* set up chart for temperature trend if not yet done /End */


 /* set up chart for heating minutes trend if not yet done /Begin */
 if (heatChartInf.id == 0)
   {
    heatChartInf.gridEnable = 1;														/* switch on grid */
    heatChartInf.nbValues   = CHART_YEAR_TREND_MAX_DAYS;
    
    /* set width of samples according to width of chart and how many values should fit in chart */
    heatChartInf.samplesWidth = (CHART_YEAR_HEAT_TREND_WIDTH - 1)/ heatChartInf.nbValues;

    /* convert X grid width from day to pixel according width of chart and value range */
    heatChartInf.gridX = CHART_YEAR_HEAT_TREND_WIDTH / 									/* width of chart */
                         ( 
                          (CHART_YEAR_TREND_MAX_DAYS /									/* day per year */
                          CHART_YEAR_HEAT_TREND_GRID_X) + 1								/* grid with in days */
                         );													

    /* convert Y grid width from minutes to pixel according to height of chart and value range */
    heatChartInf.gridY = CHART_YEAR_HEAT_TREND_HEIGHT / 								/* height of chart */
                         (
                          (CHART_YEAR_HEAT_TREND_MAX_Y - CHART_YEAR_HEAT_TREND_MIN_Y) /	/* value range */
                           CHART_YEAR_HEAT_TREND_GRID_Y									/* grid with in minutes */		
                         );									


    heatChartInf.status = TR_init( &heatChartInf.id, 									/* init trend */
                                    vcHandle, 
                                    CHART_YEAR_TREND_MAX_CURVE, 
                                    heatChartInf.nbValues,
                                    CHART_YEAR_HEAT_TREND_UPPER_LEFT_X, 
                                    CHART_YEAR_HEAT_TREND_UPPER_LEFT_Y, 
                                    heatChartInf.samplesWidth, 
                                    CHART_YEAR_HEAT_TREND_HEIGHT,
                                    heatChartInf.gridX, 
                                    heatChartInf.gridY, 
                                    CHART_YEAR_HEAT_TREND_GRID_COLOR, 
                                   &heatChartInf.gridEnable, 
                                    CHART_YEAR_HEAT_TREND_BACK_COLOR, 
                                    CHART_YEAR_HEAT_TREND_FORE_COLOR );
                                        
    if (heatChartInf.status == 0)														/* if init ok -> add all curves to chart */
      {
       for (loopIndex = 0; loopIndex < CHART_YEAR_TREND_MAX_CURVE; loopIndex++)
       {
        heatChartInf.status = TR_addCurve(  heatChartInf.id, 
                                            0,											/* static trend */ 
                                            (UDINT *)&heatCurveInf[loopIndex].pData,
                                           &heatCurveInf[loopIndex].enable, 
                                            CHART_YEAR_HEAT_TREND_MIN_Y, 
                                            CHART_YEAR_HEAT_TREND_MAX_Y, 
                                            (USINT)loopIndex );
        if (heatChartInf.status)
          ERRxwarning( (UINT)heatChartInf.status, loopIndex, "hs_trend: add heating min. curve");
       }
      } /* if (heatChartInf.id == 0) */
   } /* if (heatChartInf.id == 0) */
 /* set up chart for heating minutes trend if not yet done /End */




 /* search for existing temperature trend data objects on user input /Begin */
 for (loopIndex = 0; loopIndex < CHART_YEAR_TREND_MAX_CURVE; loopIndex++)
 {
  if (yearTrendInf[loopIndex].inputCompleted)
    {
     yearTrendInf[loopIndex].inputCompleted = 0;
     heatChartInf.forceChartDraw            = 1;
     tempChartInf.forceChartDraw            = 1;

     /* prepare temperature trend /Begin */
     strcpy( &trendDOname[0], TEMP_TREND_DO_NAME_TEMPLATE );			/* "temp_xx" */
     trendDOname[5] = (yearTrendInf[loopIndex].year % 100) / 10 + '0';	/* 2001 -> 0 -> '0' */
     trendDOname[6] = (yearTrendInf[loopIndex].year % 100) % 10 + '0';	/* 2001 -> 1 -> '1' */
  
     fDatObjInfo.enable = 1;
     fDatObjInfo.pName  = (UDINT)&trendDOname[0];
 
     DatObjInfo(&fDatObjInfo);											/* get schedule */
 
     if ( (fDatObjInfo.status == ERR_OK) && (yearTrendInf[loopIndex].year >= 2000) )				/* error or before year 2000? */
       {
        tempCurveInf[loopIndex].enable = 1;

        /* fill up trend buffer */
        for (subLoopIndex = 0; subLoopIndex < CHART_YEAR_TREND_MAX_DAYS; subLoopIndex++)
          tempCurveInf[loopIndex].pData[subLoopIndex] = round( ((REAL*)fDatObjInfo.pDatObjMem)[subLoopIndex] );
       }
     else
       {
        tempCurveInf[loopIndex].enable = 0;
       }
     /* prepare temperature trend /End */


     /* prepare heating minutes trend /Begin */
     strcpy( &trendDOname[0], HEAT_TREND_DO_NAME_TEMPLATE );			/* "heat_xx" */
     trendDOname[5] = (yearTrendInf[loopIndex].year % 100) / 10 + '0';	/* 2001 -> 0 -> '0' */
     trendDOname[6] = (yearTrendInf[loopIndex].year % 100) % 10 + '0';	/* 2001 -> 1 -> '1' */
  
     fDatObjInfo.enable = 1;
     fDatObjInfo.pName  = (UDINT)&trendDOname[0];
 
     DatObjInfo(&fDatObjInfo);											/* get schedule */
 
     if ( (fDatObjInfo.status == ERR_OK) && (yearTrendInf[loopIndex].year >= 2000) )				/* error or before year 2000? */
       {
        heatCurveInf[loopIndex].enable = 1;

        /* fill up trend buffer */
        for (subLoopIndex = 0; subLoopIndex < CHART_YEAR_TREND_MAX_DAYS; subLoopIndex++)
          heatCurveInf[loopIndex].pData[subLoopIndex] = ((UDINT*)fDatObjInfo.pDatObjMem)[subLoopIndex];
       }
     else
       {
        heatCurveInf[loopIndex].enable = 0;
       }
     /* prepare heating minutes trend /End */

     /* mark input field if no curve can be displayed */     
     if ( (tempCurveInf[loopIndex].enable == 0) && (heatCurveInf[loopIndex].enable == 0) )
       yearTrendInf[loopIndex].year = 10000;						/* display: "****" because of four digits in visu */
    }
 } /* for (loopIndex = 0; loopIndex < CHART_YEAR_TREND_MAX_CURVE; loopIndex++) */
 /* search for existing temperature trend data objects on user input /End */



 /* draw chart only in 30.6 and if handle to vc interpreter exists /Begin */
 if ( (VisuInterface.curPictNr == PIC_30_6) && (vcHandle != 0) )
   {
    /* on entering 30.5: default trend of current year as first chart if not yet occopied */
    if ( (VisuInterface.curPictNr != oldPictNr) && (heatCurveInf[0].enable == 0) && (tempCurveInf[0].enable == 0) )
      {
       yearTrendInf[0].year           = CurrentTime.year;
       yearTrendInf[0].inputCompleted = 1;
      }

    if (VisuInterface.curPictNr  != oldPictNr)        			/* draw charts if 30.5 entered */
      {
       tempChartInf.forceChartDraw = 1;
       heatChartInf.forceChartDraw = 1;
      }
    
      

    /* or any change by user or problems during last drawing (immediately after entering 30.5) */
    if (tempChartInf.forceChartDraw)
      {
       tempChartInf.forceChartDraw = 0;
    
       /* clear chart */
       tempChartInf.status = TR_redraw(tempChartInf.id);
       if (tempChartInf.status != 0) tempChartInf.forceChartDraw = 1;		/* on error - once again */

       /* draw chart */
       tempChartInf.status = TR_sDraw(tempChartInf.id);
       if (tempChartInf.status != 0) tempChartInf.forceChartDraw = 1;		/* on error - once again */
      }

    if (heatChartInf.forceChartDraw)
      {
       heatChartInf.forceChartDraw = 0;
    
       /* clear chart */
       heatChartInf.status = TR_redraw(heatChartInf.id);
       if (heatChartInf.status != 0) heatChartInf.forceChartDraw = 1;		/* on error - once again */

       /* draw chart */
       heatChartInf.status = TR_sDraw(heatChartInf.id);
       if (heatChartInf.status != 0) heatChartInf.forceChartDraw = 1;		/* on error - once again */
      }
   } /* if ( (VisuInterface.curPictNr == PIC_30_6) && (vcHandle != 0) ) */
 /* draw chart only in 30.6 and if handle to vc interpreter exists /End */


 oldPictNr = VisuInterface.curPictNr;  
}