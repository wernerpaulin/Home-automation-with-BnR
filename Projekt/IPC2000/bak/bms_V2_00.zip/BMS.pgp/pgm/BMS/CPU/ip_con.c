/*********************************************************************************************
*  Copyright: 2005 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Management System                                                   *
*    Purpose	Irrigation Plant Control                                                     *
*                                                                                            *
*    Filename   ip_con.c                                                                     *
*--------------------------------------------------------------------------------------------*
*  Description :                                                                             *
*               irrigation control                                                           *
*               statistics                                                                   *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  History :                                                                                 *
*  Version       Datum         Autor                                                         *
*  01.00         28.04.05      W. Paulin     created                                         *
*********************************************************************************************/

#include <bms_gn.h>
#include <bms_global.h>
#include <bms_io.h>

_LOCAL	rcpParIrrigation_typ	rcpPar;
_LOCAL	RTInfo_typ				fRTInfo;

_LOCAL	UDINT					segmentIndex;
_LOCAL	UDINT					timeIndex;
_LOCAL	BOOL					stateOld[NB_SEGMENT];
_LOCAL	USINT					newMinute;
_LOCAL	USINT					oldMinute;
_LOCAL	UDINT					dayMinute;
_LOCAL	UDINT					segmentWatchdogTimer[NB_SEGMENT];
_LOCAL	USINT					cmdPumpOn;
_LOCAL	UDINT					cycT;
_LOCAL	UDINT					pumpOnTimer;

_INIT void ip_conini()
{
	oldMinute = gActData.general.time.minute;

	fRTInfo.enable = 1;
	RTInfo(&fRTInfo);
	cycT = fRTInfo.cycle_time / 1000;
}	/* _INIT void ip_conini() */



_CYCLIC void ip_concyc()
{
	/* generate time flag */
	if (oldMinute != gActData.general.time.minute)
	{
		newMinute = ACTIVE;
		dayMinute = (UDINT)gActData.general.time.hour * 60 + (UDINT)gActData.general.time.minute;
		oldMinute = gActData.general.time.minute;
	}
	else
	{
		newMinute = 0;
	}


	/* apply recipe parameter if allowed */
	if (gCfgData.parLock == INACTIVE)
	{
		memcpy( &rcpPar, &gCfgData.rcpPar.irrigation, sizeof(rcpPar) );
	}


	/********************************************************************/
	/*** WATER SEGMENT HANDLING                                       ***/
	/********************************************************************/
	cmdPumpOn = INACTIVE;		/* assume pump is not active any more */
	for ( segmentIndex = 0; segmentIndex < NB_SEGMENT; segmentIndex++ )
	{
		/* segment manually switched off */
		if (rcpPar.segment[segmentIndex].mode == MODE_OFF)
		{
			gActData.irrigation.segment[segmentIndex].state = INACTIVE;
		}
		/* segment manually switched on */
		else if (rcpPar.segment[segmentIndex].mode == MODE_ON)
		{
			gActData.irrigation.segment[segmentIndex].state = ACTIVE;
			
			/* switch off segment after some time assuming user forgot to switch it off */
			segmentWatchdogTimer[segmentIndex] += newMinute;
			if (segmentWatchdogTimer[segmentIndex] >= SEGMENT_WATCHDOG_TIME)
			{
				rcpPar.segment[segmentIndex].mode = MODE_OFF;
			}
		}
		/* segment in automatic mode -> check start time and duration */
		else
		{
			gActData.irrigation.segment[segmentIndex].state = INACTIVE;			/*default: not supposed to be active */
			for ( timeIndex = 0; timeIndex < NB_IRRIGATION_START_TIME; timeIndex++ )
			{
				/* start time reached and within duration */
				if ( (dayMinute >= rcpPar.segment[segmentIndex].startTime[timeIndex]) && (dayMinute < rcpPar.segment[segmentIndex].startTime[timeIndex] + rcpPar.segment[segmentIndex].duration[timeIndex]) )
				{
					gActData.irrigation.segment[segmentIndex].state = ACTIVE;
				}
			}
		}
		
		/* reset watchdog if not switched on */
		if (rcpPar.segment[segmentIndex].mode != MODE_ON)
		{
			segmentWatchdogTimer[segmentIndex] = 0;
		}
		
		/* statistics */
		if ( stateOld[segmentIndex] != gActData.irrigation.segment[segmentIndex].state )
		{
			gActData.statistics.irrigation.valve[segmentIndex]++;
			stateOld[segmentIndex] = gActData.irrigation.segment[segmentIndex].state;
		}

		/* switch on pump if valve is open */
		if (gActData.irrigation.segment[segmentIndex].state == ACTIVE)
		{
			cmdPumpOn = ACTIVE;
		}
		
		/* set valve output */	
		BMS_IO_SET_IRRIGATION_VALVE(segmentIndex);
	} /* for ( segmentIndex = 0; segmentIndex < NB_SEGMENT; segmentIndex++ ) */	

	/* switch pump on after some time -> filter frequent change of user input */
	if ( (cmdPumpOn == ACTIVE) && (pumpOnTimer >= IRRIGATION_PUMP_ON_DELAY) )
	{
		doPump = ACTIVE;
	}
	else if (cmdPumpOn == ACTIVE)
	{
		pumpOnTimer += cycT;
		doPump = INACTIVE;
	}
	else
	{
		pumpOnTimer = 0;
		doPump = INACTIVE;
	}
	
	
	/* generate level of tank */
	if ( (diTankLevelHigh == ACTIVE) && (diTankLevelLow == ACTIVE) )
	{
		gActData.irrigation.tankLevel = 9;
	}
	else if ( (diTankLevelHigh == INACTIVE) && (diTankLevelLow == ACTIVE) )
	{
		gActData.irrigation.tankLevel = 5;
	}
	else if ( (diTankLevelHigh == INACTIVE) && (diTankLevelLow == INACTIVE) )
	{
		gActData.irrigation.tankLevel = 2;
	}

	/* statistics */
	if ( (doPump == ACTIVE) && (newMinute) )
	{
		gActData.statistics.irrigation.onTimePump++;
	}
}	/* _CYCLIC void ip_concyc() */