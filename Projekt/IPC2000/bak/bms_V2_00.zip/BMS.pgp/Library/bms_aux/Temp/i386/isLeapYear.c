#include	<bur\plc.h>

void isLeapYear(void) {};
