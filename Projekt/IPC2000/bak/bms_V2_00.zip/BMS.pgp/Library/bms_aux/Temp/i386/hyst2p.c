#include	<bur\plc.h>

void hyst2p(void) {};
