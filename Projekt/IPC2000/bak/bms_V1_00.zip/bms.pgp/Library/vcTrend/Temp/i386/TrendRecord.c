#include	<bur\plc.h>

void TrendRecord(void) {};
