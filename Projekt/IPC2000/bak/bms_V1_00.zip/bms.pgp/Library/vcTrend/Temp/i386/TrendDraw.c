#include	<bur\plc.h>

void TrendDraw(void) {};
