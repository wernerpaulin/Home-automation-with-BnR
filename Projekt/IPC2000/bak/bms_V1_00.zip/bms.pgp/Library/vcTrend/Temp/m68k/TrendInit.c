#include	<bur\plc.h>

_FUNDEF(TrendInit);
