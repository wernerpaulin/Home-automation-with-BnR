#include	<bur\plc.h>

void TrendDrwSingle(void) {};
