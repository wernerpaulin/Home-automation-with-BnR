#include	<bur\plc.h>

void TR_redraw(void) {};
