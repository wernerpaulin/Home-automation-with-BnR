#include	<bur\plc.h>

void TrendAdd(void) {};
