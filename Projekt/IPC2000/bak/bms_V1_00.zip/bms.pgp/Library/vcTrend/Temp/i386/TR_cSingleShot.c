#include	<bur\plc.h>

void TR_cSingleShot(void) {};
