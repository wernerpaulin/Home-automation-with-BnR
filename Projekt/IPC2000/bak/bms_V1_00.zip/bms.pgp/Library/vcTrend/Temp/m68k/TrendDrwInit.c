#include	<bur\plc.h>

_FUNDEF(TrendDrwInit);
