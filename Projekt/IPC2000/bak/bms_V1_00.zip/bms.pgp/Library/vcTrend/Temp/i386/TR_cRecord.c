#include	<bur\plc.h>

void TR_cRecord(void) {};
