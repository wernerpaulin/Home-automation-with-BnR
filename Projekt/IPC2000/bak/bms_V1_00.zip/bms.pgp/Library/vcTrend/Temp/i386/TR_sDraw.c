#include	<bur\plc.h>

void TR_sDraw(void) {};
