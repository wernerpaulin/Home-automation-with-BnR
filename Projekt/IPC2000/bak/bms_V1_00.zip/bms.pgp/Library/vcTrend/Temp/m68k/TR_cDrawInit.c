#include	<bur\plc.h>

_FUNDEF(TR_cDrawInit);
