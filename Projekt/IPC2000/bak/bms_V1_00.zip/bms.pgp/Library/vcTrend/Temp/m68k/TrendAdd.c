#include	<bur\plc.h>

_FUNDEF(TrendAdd);
