#include	<bur\plc.h>

void TrendDrwInit(void) {};
