#include	<bur\plc.h>

void TR_addCurve(void) {};
