/*********************************************************************************************
*  Copyright: 2001 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Managment System                                                    *
*    Purpose    Main Process of Building Management System                                   *
*                                                                                            *
*    Filename   mp_bms.c                                                                     *
*--------------------------------------------------------------------------------------------*
*  Description :                                                                             *
*   - configuration of general issues                                                        *
*   - acquisition of statistical data                                                        *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  History :                                                                                 *
*  Version       Datum         Autor                                                         *
*  01.00         05.07.01      W. Paulin     Created                                         *
*  01.01         23.12.01      W. Paulin     - calibration of touch with API functions       *
*                                            - saving statistical info just every hour       *
*********************************************************************************************/

#include <bur/plctypes.h>
#include <bms_gn.h>

_LOCAL DTGetTime_typ    fDTgetTime;
_LOCAL DTSetTime_typ    fDTsetTime;
_LOCAL USINT            newHour;
_LOCAL USINT            oldHour;
_LOCAL USINT            newMinute;
_LOCAL USINT            oldMinute;
_LOCAL UDINT            cycT;
_LOCAL RTInfo_typ       fRTInfo;

_LOCAL dataObjInf_s     dataObjBMS;

_LOCAL DatObjCreate_typ fDatObjCreate;
_LOCAL DatObjInfo_typ   fDatObjInfo;
_LOCAL DatObjWrite_typ  fDatObjWrite;

_LOCAL USINT            oldPictNr;

_LOCAL UDINT			vcHandle;
_LOCAL UINT				status;

_INIT void mp_bmsini(void)
{
 fRTInfo.enable = 1; 
 RTInfo(&fRTInfo);
 
 cycT = fRTInfo.cycle_time / 1000;					/* transform cycle time us -> ms */


 /* get current time /Begin */
 fDTgetTime.enable = 1;
 DTGetTime(&fDTgetTime);
 if (fDTgetTime.status == 0)
   {
    DT_TO_DTStructure(fDTgetTime.DT1, (UDINT)&CurrentTime);
   }
 /* get current time /end */


 /* get saved statistic information /Begin */
 fDatObjInfo.enable = 1;
 fDatObjInfo.pName = (UDINT)BMS_STATISTIC_INFO_DO_NAME;
 
 DatObjInfo(&fDatObjInfo);												
 
 /* if it does not exist -> create it */
 if ( (fDatObjInfo.status == ERR_OK) && (sizeof(BMSstatistic) == fDatObjInfo.len) )
   {
    dataObjBMS.pData     = fDatObjInfo.pDatObjMem;								/* pointer to statistic information */
    dataObjBMS.doIdent   = fDatObjInfo.ident;									/* ident of data object containing statistic information */
    dataObjBMS.doLength  = fDatObjInfo.len;										/* length of data in data object */
    dataObjBMS.doMemType = fDatObjInfo.MemType;									/* memory of data object containing statistic information */
    dataObjBMS.doOption  = fDatObjInfo.Option;									/* additional options of data object containing statistic information */
    
    memcpy( &BMSstatistic, (void*)dataObjBMS.pData, sizeof(BMSstatistic) );		/* copy last statistic information to structure */
   }
 else
   {
    fDatObjCreate.enable   = 1;
    fDatObjCreate.pName    = (UDINT)BMS_STATISTIC_INFO_DO_NAME;
    fDatObjCreate.len      = sizeof(BMSstatistic);
    fDatObjCreate.MemType  = doUSRROM;
    fDatObjCreate.Option   = 0;
    fDatObjCreate.pCpyData = (UDINT)&BMSstatistic;
    
    DatObjCreate(&fDatObjCreate);

    if (fDatObjCreate.status == ERR_OK)
      { 		
       dataObjBMS.pData     = fDatObjCreate.pDatObjMem;							/* pointer to segment information */
       dataObjBMS.doIdent   = fDatObjCreate.ident;								/* ident of data object containing schedule */
       dataObjBMS.doLength  = fDatObjCreate.len;								/* length of data in data object */
       dataObjBMS.doMemType = fDatObjCreate.MemType;							/* memory of data object containing schedule */
       dataObjBMS.doOption  = fDatObjCreate.Option;								/* additional options of data object containing schedule */
      }
   }
 /* get saved statistic information /End */
}


_CYCLIC void mp_bmscyc(void)
{
 /* get current time /Begin */
 fDTgetTime.enable = 1;
 DTGetTime(&fDTgetTime);
 if (fDTgetTime.status == 0)
   {
    DT_TO_DTStructure(fDTgetTime.DT1, (UDINT)&CurrentTime);
   }
 /* get current time /end */


 /* generate new hour and new minute time flags */
 getTimeFlags( &CurrentTime, &newHour, &oldHour, &newMinute, &oldMinute, 0, 0);

 /***********************************************************************************************************************/
 /*** VISU INTERFACE                                                                                                  ***/
 /***********************************************************************************************************************/
 if (vcHandle == 0)
   vcHandle = VA_Setup(1, "visu");


 /* picture "Allgemeine Einstellungen" */
 if (VisuInterface.curPictNr == ALLG_EINST)
   {
    if (VisuInterface.curPictNr != oldPictNr)
      VisuInterface.newTime = CurrentTime;
      
    if (VisuInterface.setTime == 1)
      {
       fDTsetTime.enable = 1;
       fDTsetTime.DT1 = DTStructure_TO_DT((UDINT)&VisuInterface.newTime);
 
       DTSetTime(&fDTsetTime);
    
       VisuInterface.setTime = 0;
      }
   }

 if (newMinute)
   {
    /* convert operating minutes in hours */
    VisuInterface.rainWaterPumpHour          = (REAL)BMSstatistic.irrigationStatistic.onTimeRainWaterPump       / 60;
    VisuInterface.firingHour                 = (REAL)BMSstatistic.heatingStatistic.onTimeFiring                 / 60;
    VisuInterface.boilerPumpHour             = (REAL)BMSstatistic.heatingStatistic.onTimeBoilerPump             / 60;
    VisuInterface.heatingCirculationPumpHour = (REAL)BMSstatistic.heatingStatistic.onTimeHeatingCirculationPump / 60;
   }
 
 /* Touch calibration /Begin */
 if (VisuInterface.doTouchCalibration != TOUCH_CALIBRATION_DONE) 
   {
    if ( VA_Saccess(1, vcHandle) == 0 )
      {
       switch (VisuInterface.doTouchCalibration)
       {
        case CHANGE_TO_TOUCH_CALIBRATION_PICTURE:
          VisuInterface.newPictNr = TOUCH_CAL;
          VisuInterface.doTouchCalibration = START_TOUCH_CALIBRATION;
        break;

        case START_TOUCH_CALIBRATION:
          if (VisuInterface.curPictNr == TOUCH_CAL)
            {
             VA_StartTouchCal(1, vcHandle);
             VisuInterface.doTouchCalibration = GET_TOUCH_CALIBRATION_STATUS;
            }
        break;
        
        case GET_TOUCH_CALIBRATION_STATUS:
          status = VA_GetCalStatus (1, vcHandle);
          
          if ((status == 0) || (status == 0xFFFF))				/* all done or a general error occured */
            {
             VisuInterface.doTouchCalibration = TOUCH_CALIBRATION_DONE;
             VisuInterface.newPictNr          = ALLG_EINST;
            }
        break;
       }
      }

    VA_Srelease(1, vcHandle);
   }
 /* Touch calibration /End */

 
  
 #warning: CAN nodes �berwachen und Fehlermeldung f�r VISU
 #warning: Batterie-Zustand auslesen
 
 /***********************************************************************************************************************/
 /*** SAVE DATA                                                                                                       ***/
 /***********************************************************************************************************************/
 /* save statistical information every hour /Begin */
 if ((newHour == 1) || (dataObjBMS.lstWrErr))
   {
    fDatObjWrite.enable  = 1;
    fDatObjWrite.ident   = dataObjBMS.doIdent;
    fDatObjWrite.Offset  = 0;
    fDatObjWrite.pSource = (UDINT)&BMSstatistic;
    fDatObjWrite.len     = sizeof(BMSstatistic);
    
    DatObjWrite(&fDatObjWrite);
    
    if (fDatObjWrite.status != ERR_OK)
      {
       dataObjBMS.nbWrErr++;
       dataObjBMS.lstWrErr = fDatObjWrite.status;

       ERRxwarning(fDatObjWrite.status, 0, "write statistics");
      }
   }
 /* save statistical information every hour /End */


 oldPictNr = VisuInterface.curPictNr;
}	
