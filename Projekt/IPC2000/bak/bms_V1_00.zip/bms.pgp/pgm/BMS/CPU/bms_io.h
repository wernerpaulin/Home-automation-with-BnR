/****************************************************************************
**********                   I/O Declaration()	  	               **********
****************************************************************************/

#ifndef _BMS_IO_H_
#define _BMS_IO_H_

#include <bur/plctypes.h>


/*** IRRIGATION PLANT /Begin ***/
/* Valves */
_GLOBAL BOOL oValveSeg1;
_GLOBAL BOOL oValveSeg2;
_GLOBAL BOOL oValveSeg3;
_GLOBAL BOOL oValveSeg4;
_GLOBAL BOOL oValveSeg5;
_GLOBAL BOOL oValveSeg6;
_GLOBAL BOOL oValveServiceWater;

_GLOBAL BOOL iValveStateSeg1;
_GLOBAL BOOL iValveStateSeg2;
_GLOBAL BOOL iValveStateSeg3;
_GLOBAL BOOL iValveStateSeg4;
_GLOBAL BOOL iValveStateSeg5;
_GLOBAL BOOL iValveStateSeg6;
_GLOBAL BOOL iValveStateServiceWater;			

/* misc. outputs */
_GLOBAL BOOL oRainWaterPump;


/* humidity sensors */
_GLOBAL BOOL iHumKitchenGarden1;
_GLOBAL BOOL iHumFlowerGarden1;

/* misc. inputs */
_GLOBAL BOOL iWaterPressure;
/*** IRRIGATION PLANT /End ***/

/*** HEATING SYSTEM /Begin ***/
_GLOBAL BOOL oFiring;							/* activates burner */
_GLOBAL BOOL oBoilerPump;						/* activates pump for boiler */
_GLOBAL BOOL oHeatingCirculationPump;			/* activates circulation pump of heating system */
_GLOBAL BOOL oMixerOpen;						/* forces mixer to open */
_GLOBAL BOOL oMixerClose;						/* forces mixer to close */

_GLOBAL UINT  iOutsideTemp;						/* outside temperature */
_GLOBAL UINT  iFiringTemp;						/* temperature inside burner */
_GLOBAL UINT  iBoilerTemp;						/* temperature inside hot water boiler */
_GLOBAL UINT  iFlowPipeTemp;					/* temperature of heating pipe after mixer */
_GLOBAL UINT  oAT324cfgWord14;					/* AT324 configuration */


/*** HEATING SYSTEM /End ***/






#endif