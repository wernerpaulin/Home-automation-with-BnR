/*********************************************************************************************
*  Copyright: 2001 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Managment System                                                    *
*    Purpose    additional functions for Irrigation Plant Manager                             *
*                                                                                            *
*    Filename   ip_func.c                                                                    *
*********************************************************************************************/

#include <bur/plctypes.h>
#include <bms_gn.h>

/****************************************************************************
**********                	CheckIrrigationSchedule()              **********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     checks irrigation schedule and set .state to pending if segment should*
*     set active                                                            *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       pSchedule	 : Basepointer to schedule of irrigation plant          *
*       pSegmentInf  : Basepointer to segment information                   *
*       pCurrentTime : Pointer to current time                              *
*                                                                           *
*    Output:                                                                *
*       status                                                              *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       06.07.01    W. Paulin     created 							*
*   01.01       23.06.02    W. Paulin     default: segment inactive         *
****************************************************************************/
UINT CheckIrrigationSchedule(ipDaySchedule_s *pSchedule, segment_s *pSegment, DTStructure *pCurrentTime)
{
 UINT segmentNr          = 0;
 UINT periodeNr          = 0; 
 UINT currentMinMidnight = 0;
 UINT periodeMinMidnight = 0;

 currentMinMidnight = pCurrentTime->hour * 60 + pCurrentTime->minute;		/* get current minutes since midnight */

 for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++)
 {
  pSegment[segmentNr].state = SEGMENT_INACTIVE;								/* default segment is not active */
  
  /* check if any configured periode is currently active */
  for (periodeNr = 0; periodeNr < NB_PERIODS_PER_DAY; periodeNr++)
  {
   periodeMinMidnight =   pSchedule->ipSegmentSchedule[segmentNr].periode[periodeNr].start.hour * 60 
                        + pSchedule->ipSegmentSchedule[segmentNr].periode[periodeNr].start.minute;
   
   /* set state to "ready for active" if start time has been already passed and duration is not yet exceeded */                     
   if ( (currentMinMidnight >= periodeMinMidnight) && 
       (currentMinMidnight < periodeMinMidnight + pSchedule->ipSegmentSchedule[segmentNr].periode[periodeNr].duration) )
     {
      pSegment[segmentNr].state         = SEGMENT_READY_FOR_ACTIVE;
      pSegment[segmentNr].curPeriodeNr  = periodeNr;
     }
  }
 }

 return(ERR_BMS_NO_ERR);
}


