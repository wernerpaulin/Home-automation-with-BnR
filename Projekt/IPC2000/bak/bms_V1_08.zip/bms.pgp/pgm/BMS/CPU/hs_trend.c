/*********************************************************************************************
*  Copyright: 2002 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Managment System                                                    *
*    Purpose    trend handling of heating system                                             *
*                                                                                            *
*    Filename   hs_trend.c                                                                   *
*--------------------------------------------------------------------------------------------*
*  Description :                                                                             *
*    Picture 30.0: outside temp./feed temp. chart                                            *
*    Picture 30.1: outside temp./feed temp. chart original curve adjustment                  *
*    Picture 30.5: day temp. (today/yesterday) chart                                         *
*    Picture 30.6: outside temp. and heating minutes chart                                   *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  History :                                                                                 *
*  Version       Datum         Autor                                                         *
*  01.00         08.06.02      W. Paulin     Created                                         *
*  01.01         01.12.02      W. Paulin     add elements for picture 30.7                   *
*                                            new vcTrend Library                             *
*  01.02         31.12.02      W. Paulin     save heating minutes at 23:59 (same day)        *
*  01.03         01.01.03      W. Paulin     picture 30.6->30.5 and 30.7->30.6               *
*  01.04         06.01.03      W. Paulin     average temperature of today and yesterday      *
*  01.05         30.08.03      W. Paulin     new colors for year trend (colorIndex)          *
*                                            show actual and last year in year trend as      *
*                                            default                                         *
*                                            PIC_30_5 and 30_6 changed (day-, year trend)    *
*  01.06         01.01.04      W. Paulin     average temperature / total heating hours a year*
*  01.07         03.01.04      W. Paulin     min/max temperature for year trend              *
*********************************************************************************************/

#include <bur/plctypes.h>
#include <bms_gn.h>

/* prototyping */
void getTempTrendDataNoon();
void getTempTrendDataMin();
void getTempTrendDataMax();
void getHeatTrendData();

_LOCAL dataObjInf_s 		dataObjOutFeedTemp;
_LOCAL dataObjInf_s 		dataObjTempYearNoon;
_LOCAL dataObjInf_s 		dataObjTempYearMin;
_LOCAL dataObjInf_s 		dataObjTempYearMax;
_LOCAL dataObjInf_s 		dataObjHeatYear;
_LOCAL DatObjInfo_typ		fDatObjInfo;
_LOCAL DatObjWrite_typ		fDatObjWrite;
_LOCAL DatObjCreate_typ		fDatObjCreateHeat;
_LOCAL DatObjCreate_typ		fDatObjCreateTempNoon;
_LOCAL DatObjCreate_typ		fDatObjCreateTempMin;
_LOCAL DatObjCreate_typ		fDatObjCreateTempMax;

_LOCAL RTInfo_typ			fRTInfo;

_LOCAL UDINT 				vcHandle;
_LOCAL UDINT 				loopIndex;
_LOCAL UDINT 				subLoopIndex;
_LOCAL UDINT 				colorIndex;

_LOCAL REAL 				oldManTempOffset;
_LOCAL REAL 				oldDayOffset;
_LOCAL REAL 				oldNightOffset;
_LOCAL REAL 				oldNotAtHomeOffset;

_LOCAL trendChartInf_s		outFeedChartInf;
_LOCAL trendCurveInf_s		originalCurveInf;
_LOCAL trendCurveInf_s		dayCurveInf;
_LOCAL trendCurveInf_s		nightCurveInf;
_LOCAL trendCurveInf_s		notAtHomeCurveInf;

_LOCAL REAL					chartXmin;
_LOCAL REAL					chartXmiddle;
_LOCAL REAL					chartXmax;

_LOCAL USINT				oldPictNr;
       
_LOCAL trendChartInf_s		tempChartInf;
_LOCAL trendCurveInf_s		tempCurveInf[CHART_YEAR_TREND_MAX_CURVE];

_LOCAL trendChartInf_s		heatChartInf;
_LOCAL trendCurveInf_s		heatCurveInf[CHART_YEAR_TREND_MAX_CURVE];

_LOCAL yearTrendInf_s		yearTrendInf[CHART_YEAR_TREND_MAX_CURVE];

_LOCAL trendChartInf_s		dayTempChartInf;
_LOCAL trendCurveInf_s		dayTempCurveInf[CHART_DAY_TREND_MAX_CURVE];
_LOCAL DINT					*pDayTempCurveShadowData;
_LOCAL UINT					minuteIndex;
_LOCAL USINT				fourMinutesCounter;
_LOCAL USINT				fourMinutesElapsed;

_LOCAL USINT				trendDOname[8+1];

_LOCAL UINT					status;

_LOCAL UDINT				cycT;

_LOCAL USINT            	newHour;
_LOCAL USINT            	oldHour;
_LOCAL USINT            	newMinute;
_LOCAL USINT            	oldMinute;
_LOCAL UDINT 				heatingMinutesPerDay;
_LOCAL UDINT				oldOnTimeFiring;

_LOCAL UDINT				onTimeNormalMode;
_LOCAL UDINT				onTimeTotal;

_LOCAL REAL					todaySumOutsideTemp;

_LOCAL USINT				tempDebug;
_LOCAL UINT					catDayOfYear;
_LOCAL REAL					catReadTemp;
_LOCAL REAL					catWriteTemp;
_LOCAL DatObjRead_typ		fDatObjRead;
_LOCAL USINT				catWriteTrigger;
_LOCAL USINT				heatDebug;
_LOCAL UDINT				catReadHeat;
_LOCAL UDINT				catWriteHeat;

_LOCAL REAL					sumYearTemp;
_LOCAL UINT					maxDay;
_LOCAL REAL					minTempDay;
_LOCAL REAL					maxTempDay;

_INIT void hs_trendini(void)
{
 fRTInfo.enable = 1; 
 RTInfo(&fRTInfo);
 
 cycT = fRTInfo.cycle_time / 1000;					/* transform cycle time us -> ms */

 /* get chart of feed temperature according to outside temperature /Begin */
 fDatObjInfo.enable = 1;
 fDatObjInfo.pName = (UDINT)CHART_OUTSIDE_FEED_TEMP_DO_NAME;
 
 DatObjInfo(&fDatObjInfo);										/* get schedule */
 
 if (fDatObjInfo.status == ERR_OK)								/* error ? */
   {
    dataObjOutFeedTemp.pData     = fDatObjInfo.pDatObjMem;		/* pointer to chart */
    dataObjOutFeedTemp.doIdent   = fDatObjInfo.ident;			/* ident of data object containing chart */
    dataObjOutFeedTemp.doLength  = fDatObjInfo.len;				/* length of data in data object */
    dataObjOutFeedTemp.doMemType = fDatObjInfo.MemType;			/* memory of data object containing chart */
    dataObjOutFeedTemp.doOption  = fDatObjInfo.Option;			/* additional options of data object containing chart */
   }
 else
   {
    memset( &dataObjOutFeedTemp, 0, sizeof(dataObjOutFeedTemp) );
    VisuInterface.heatingAlarm[HEATING_OUTSIDE_FEED_DO_ERROR] = 1;
   }
 /* get chart of feed temperature according to outside temperature /End */
 
 /* check if there are enough elements in VisuInterface to store Data Object Information */
 if ((dataObjOutFeedTemp.doLength / sizeof(xyChartElement_s)) > (sizeof(VisuInterface.hsAdjOutFeedTemp) / sizeof(xyChartElement_s))) 
   ERRxfatal(dataObjOutFeedTemp.doLength , sizeof(VisuInterface.hsAdjOutFeedTemp), "hs_trend: hsAdjOutFeedTemp too small");

 /* allocate data buffer for temperature trend */
 for (loopIndex = 0; loopIndex < CHART_YEAR_TREND_MAX_CURVE; loopIndex++)
 {
  status = TMP_alloc( CHART_YEAR_TREND_MAX_DAYS * sizeof(DINT), (void**)&tempCurveInf[loopIndex].pData );
  if (status) 
    ERRxwarning(status, loopIndex, "hs_trend: allocate temperature buffer");
  else if (tempCurveInf[loopIndex].pData)
    memset( tempCurveInf[loopIndex].pData, 0, CHART_YEAR_TREND_MAX_DAYS * sizeof(DINT) );
 }
 
 /* allocate data buffer for heating minutes trend */
 for (loopIndex = 0; loopIndex < CHART_YEAR_TREND_MAX_CURVE; loopIndex++)
 {
  status = TMP_alloc( CHART_YEAR_TREND_MAX_DAYS * sizeof(DINT), (void**)&heatCurveInf[loopIndex].pData );
  if (status) 
    ERRxwarning(status, loopIndex, "hs_trend: allocate heating buffer");
  else if (heatCurveInf[loopIndex].pData)
    memset( heatCurveInf[loopIndex].pData, 0, CHART_YEAR_TREND_MAX_DAYS * sizeof(DINT) );
 }
 
 /* get temperature trend data of current year */
 getTempTrendDataNoon();
 getTempTrendDataMin();
 getTempTrendDataMax();

 /* get heating minutes trend data of current year */
 getHeatTrendData();
 
 
 /* allocate data buffer for day temperature trend /Begin */
 /* index 0 ...actual day - allocation will be done by TR_addCurve() */
 dayTempCurveInf[HS_TREND_DAY_CURVE].pData = 0;
 
 /* index 1 ...yesterday  - buffer has to be allocated because of static trend */
 status = TMP_alloc( CHART_DAY_TREND_MAX_MINUTES * sizeof(DINT), (void**)&dayTempCurveInf[HS_TREND_YESTERDAY_CURVE].pData );
 if (status) 
   ERRxwarning(status, 0, "hs_trend: allocate day buffer");
 else if (dayTempCurveInf[HS_TREND_YESTERDAY_CURVE].pData)
   memset( dayTempCurveInf[HS_TREND_YESTERDAY_CURVE].pData, 0, CHART_DAY_TREND_MAX_MINUTES * sizeof(DINT) );
 
 /* shadow buffer to store all temperature values of actual day */
 status = TMP_alloc( CHART_DAY_TREND_MAX_MINUTES * sizeof(DINT), (void**)&pDayTempCurveShadowData );
 if (status) 
   ERRxwarning(status, 0, "hs_trend: allocate shadow buffer");
 else if (pDayTempCurveShadowData)
   memset( pDayTempCurveShadowData, 0, CHART_DAY_TREND_MAX_MINUTES * sizeof(DINT) );
 /* allocate data buffer for day temperature trend /End */

 
 /* initialize drag indicators */
 minTempDay = +100.0;
 maxTempDay = -100.0;

 oldOnTimeFiring = BMSstatistic.heatingStatistic.onTimeFiring;					/* in case of boot up: minimize error by keeping current value in mind */
}


_CYCLIC void hs_trendcyc(void)
{
 /* generate new hour and new minute time flags */
 getTimeFlags( &CurrentTime, &newHour, &oldHour, &newMinute, &oldMinute, 0, 0 );

 if (newMinute)
   fourMinutesCounter++;
 
 if (fourMinutesCounter >= 4)
   {
    fourMinutesCounter = 0;
    fourMinutesElapsed = 1;
   }
 else
   {
    fourMinutesElapsed = 0;
   }

 /* get handle to vc interpreter */
 if (vcHandle == 0)
   vcHandle = VA_Setup(1, "visu");

 if (tempDebug)
   {
    fDatObjRead.enable = 1;
    
    /* select temperature data object */
    if (tempDebug == 2)
      fDatObjRead.ident = dataObjTempYearMin.doIdent;
    else if (tempDebug == 3)
      fDatObjRead.ident = dataObjTempYearMax.doIdent;
    else
      fDatObjRead.ident = dataObjTempYearNoon.doIdent;

    fDatObjRead.Offset = sizeof(REAL) * (catDayOfYear - 1);
    fDatObjRead.pDestination = (UDINT)&catReadTemp; 
    fDatObjRead.len    = sizeof(catReadTemp);
 
    DatObjRead(&fDatObjRead);

    if (catWriteTrigger)
      {
       fDatObjWrite.enable  = 1;
       fDatObjWrite.ident   = fDatObjRead.ident;
       fDatObjWrite.Offset  = sizeof(REAL) * (catDayOfYear - 1);
       fDatObjWrite.pSource = (UDINT)&catWriteTemp;
       fDatObjWrite.len     = sizeof(catWriteTemp);
    
       DatObjWrite(&fDatObjWrite);
    
       catWriteTrigger = 0;
      }
   }

 if (heatDebug)
   {
    fDatObjRead.enable = 1;
    fDatObjRead.ident  = dataObjHeatYear.doIdent;
    fDatObjRead.Offset = sizeof(REAL) * (catDayOfYear - 1);
    fDatObjRead.pDestination = (UDINT)&catReadHeat; 
    fDatObjRead.len    = sizeof(catReadHeat);
 
    DatObjRead(&fDatObjRead);

    if (catWriteTrigger)
      {
       fDatObjWrite.enable  = 1;
       fDatObjWrite.ident   = dataObjHeatYear.doIdent;
       fDatObjWrite.Offset  = sizeof(REAL) * (catDayOfYear - 1);
       fDatObjWrite.pSource = (UDINT)&catWriteHeat;
       fDatObjWrite.len     = sizeof(catWriteHeat);
    
       DatObjWrite(&fDatObjWrite);
    
       catWriteTrigger = 0;
      }
   }


 /* check every hour if year is still the same -> take care about new year! */
 if ( (newHour)                                    || 
      (dataObjTempYearNoon.status == ERR_FUB_BUSY) || 
      (dataObjTempYearMin.status  == ERR_FUB_BUSY) || 
      (dataObjTempYearMax.status  == ERR_FUB_BUSY) || 
      (dataObjHeatYear.status     == ERR_FUB_BUSY) )
   {
    /* get temperature trend data of current year */
    getTempTrendDataNoon();
    getTempTrendDataMin();
    getTempTrendDataMax();

    /* get heating minutes trend data of current year */
    getHeatTrendData();
   }

 /***********************************************************************************************************************/
 /*** ACQUISITION OF STATISTICAL DATA                                                                                 ***/
 /***********************************************************************************************************************/
 /* update drag indicators for minimum and maximum temperatures /Begin */
 if (fourMinutesElapsed)
   {
   	if (HsMgrInf.outsideTemp < minTempDay)
   	  {
   	   minTempDay = HsMgrInf.outsideTemp;
   	  }
   	  
   	if (HsMgrInf.outsideTemp > maxTempDay)
   	  {
   	   maxTempDay = HsMgrInf.outsideTemp;
   	  }
   }
 /* update drag indicators for minimum and maximum temperatures /Begin */
 

 /* store temperature per day every day at 12:00 o'clock noon */
 if ((CurrentTime.hour == 12) && (newHour))
   {
    fDatObjWrite.enable  = 1;
    fDatObjWrite.ident   = dataObjTempYearNoon.doIdent;
    fDatObjWrite.Offset  = sizeof(REAL) * (getDayOfYear(&CurrentTime) - 1);
    fDatObjWrite.pSource = (UDINT)&HsMgrInf.outsideTemp;
    fDatObjWrite.len     = sizeof(HsMgrInf.outsideTemp);
    
    DatObjWrite(&fDatObjWrite);
    
    if (fDatObjWrite.status != ERR_OK) 
      {
       dataObjTempYearNoon.nbWrErr++;
       dataObjTempYearNoon.lstWrErr = fDatObjWrite.status;
       VisuInterface.heatingAlarm[HEATING_TREND_TEMPERATUR_DO_ERROR] = 1;
       ERRxwarning(fDatObjWrite.status, 0, "write temp. trend data");
      }
   }

 if ((CurrentTime.hour == 23) && (CurrentTime.minute == 59) && (newMinute))
   {
    /* store heating minutes per day at 23:59 to ensure to store minutes at last day */
    /* minutes per day = actual value - value of the day before */
    heatingMinutesPerDay = BMSstatistic.heatingStatistic.onTimeFiring - oldOnTimeFiring;
    oldOnTimeFiring      = BMSstatistic.heatingStatistic.onTimeFiring;

    /* write heating minutes in Data Object */
    fDatObjWrite.enable  = 1;
    fDatObjWrite.ident   = dataObjHeatYear.doIdent;
    fDatObjWrite.Offset  = sizeof(UDINT) * (getDayOfYear(&CurrentTime) - 1);
    fDatObjWrite.pSource = (UDINT)&heatingMinutesPerDay;
    fDatObjWrite.len     = sizeof(heatingMinutesPerDay);
    
    DatObjWrite(&fDatObjWrite);
    
    if (fDatObjWrite.status != ERR_OK) 
      {
       dataObjHeatYear.nbWrErr++;
       dataObjHeatYear.lstWrErr = fDatObjWrite.status;
       VisuInterface.heatingAlarm[HEATING_TREND_HEATING_DO_ERROR] = 1;
       ERRxwarning(fDatObjWrite.status, 0, "write heat. trend data");
      }
    
    
    /* minimum temperature of this day */    
    fDatObjWrite.enable  = 1;
    fDatObjWrite.ident   = dataObjTempYearMin.doIdent;
    fDatObjWrite.Offset  = sizeof(REAL) * (getDayOfYear(&CurrentTime) - 1);
    fDatObjWrite.pSource = (UDINT)&minTempDay;
    fDatObjWrite.len     = sizeof(minTempDay);
    
    DatObjWrite(&fDatObjWrite);
    
    if (fDatObjWrite.status != ERR_OK) 
      {
       dataObjTempYearMin.nbWrErr++;
       dataObjTempYearMin.lstWrErr = fDatObjWrite.status;
       VisuInterface.heatingAlarm[HEATING_TREND_TEMPERATUR_DO_ERROR] = 1;
       ERRxwarning(fDatObjWrite.status, 0, "write temp. trend data");
      }


    /* maximum temperature of this day */    
    fDatObjWrite.enable  = 1;
    fDatObjWrite.ident   = dataObjTempYearMax.doIdent;
    fDatObjWrite.Offset  = sizeof(REAL) * (getDayOfYear(&CurrentTime) - 1);
    fDatObjWrite.pSource = (UDINT)&maxTempDay;
    fDatObjWrite.len     = sizeof(maxTempDay);
    
    DatObjWrite(&fDatObjWrite);
    
    if (fDatObjWrite.status != ERR_OK) 
      {
       dataObjTempYearMax.nbWrErr++;
       dataObjTempYearMax.lstWrErr = fDatObjWrite.status;
       VisuInterface.heatingAlarm[HEATING_TREND_TEMPERATUR_DO_ERROR] = 1;
       ERRxwarning(fDatObjWrite.status, 0, "write temp. trend data");
      }
      
    /* reset drag indicators */
    minTempDay = +100.0;
    maxTempDay = -100.0;
   }
 

 /* record actual outside temperature every four minute to trend buffer */
 if (fourMinutesElapsed)
   {
    /* today temperature is a continous trend */
    if (dayTempCurveInf[HS_TREND_DAY_CURVE].enable)
      {
       dayTempCurveInf[HS_TREND_DAY_CURVE].liveValue = round( HsMgrInf.outsideTemp );
       dayTempChartInf.status = TR_record( 1, dayTempChartInf.id );
      }

    /* increment index of every 4 minutes in a day - stop at midnight */
	if (minuteIndex < CHART_DAY_TREND_MAX_MINUTES) 
	  minuteIndex++;  
	
	/* save temperature in in shadow buffer - to be displayes next day as yesterday trend */
    if ( (dayTempCurveInf[HS_TREND_YESTERDAY_CURVE].enable) && (pDayTempCurveShadowData) )
      pDayTempCurveShadowData[minuteIndex - 1] = dayTempCurveInf[HS_TREND_DAY_CURVE].liveValue;

    /* get average temperature of this day up to now */
    todaySumOutsideTemp += dayTempCurveInf[HS_TREND_DAY_CURVE].liveValue;
    if (minuteIndex != 0) VisuInterface.todayAvOutsideTemp = todaySumOutsideTemp / minuteIndex;
   }
 
 /* midnight: copy collected temperature of this day to yesterday buffer */
 if ( (CurrentTime.hour == 0) && (newHour) )
   {
    /* copy shadow buffer to yesterday buffer if curve is enabled */
    if ( (dayTempCurveInf[HS_TREND_YESTERDAY_CURVE].enable) && 
         (dayTempCurveInf[HS_TREND_YESTERDAY_CURVE].pData)  &&
         (pDayTempCurveShadowData) )       
      {
       memcpy( dayTempCurveInf[HS_TREND_YESTERDAY_CURVE].pData, pDayTempCurveShadowData, CHART_DAY_TREND_MAX_MINUTES * sizeof(DINT) );
       memset( pDayTempCurveShadowData, 0, CHART_DAY_TREND_MAX_MINUTES * sizeof(DINT) ); 
      }

    /* keep average temperature of to day in mind */
    VisuInterface.yesterdayAvOutsideTemp = VisuInterface.todayAvOutsideTemp;

    /* reset continous trend of todays outside temperature */
    dayTempChartInf.status = TR_reset( 1, dayTempChartInf.id );

    /* release curves - wait after power up until midnight before starting day trend */
    dayTempCurveInf[HS_TREND_DAY_CURVE].enable       = 1;
    dayTempCurveInf[HS_TREND_YESTERDAY_CURVE].enable = 1;
    
    /* reset minute counter */
    minuteIndex = 0;
    
    /* reset sum counter of average calculation of temperature */
    todaySumOutsideTemp = 0;
   }


 /* separate on-time of firing device in normal operational mode */
 if ( (newMinute) && (HsMgrInf.activeHeatingMode == HEATING_MODE_AUTO) && (HsFireInf.firingInf.lcOutput > 0) ) 
   {
    /* on-time of firing device while normal (day) operational mode */
    if ( HsLoopInf.lcHeatingInf.setTempOffset == (HsMgrInf.dayOffset + HsMgrInf.manTempOffset) )
      {
       onTimeNormalMode++;
      }
    
    onTimeTotal++;    				/* base for calculation: total time is on-time in automatic mode */
   }

 /* analyze heating minutes for display */
 if ( (CurrentTime.hour == 0) && (newHour) )
   {
    /* scaling to bar graph: 0-65535 */
    if (onTimeTotal > 0)
      {
       VisuInterface.onTimeNormalBarGraph = (UINT)((onTimeNormalMode * 65535) / onTimeTotal);
       VisuInterface.onTimeNormalMode     = (REAL)onTimeNormalMode / 60;
       VisuInterface.onTimeTotal          = (REAL)onTimeTotal      / 60;

       VisuInterface.onTimeDropMode       = VisuInterface.onTimeTotal - VisuInterface.onTimeNormalMode;
      }
    
    /* reset on-time measurement */
    onTimeNormalMode = 0;
    onTimeTotal      = 0;
   }


 
 /***********************************************************************************************************************/
 /*** CHART ADJUSTMENT in 30.1                                                                                        ***/
 /***********************************************************************************************************************/
 if (VisuInterface.curPictNr == PIC_30_1)
   {
    if ( (VisuInterface.curPictNr != oldPictNr) && (dataObjOutFeedTemp.pData) )				/* if entered */
      {
       /* copy current xy-point information in buffer to be adjusted by visualisation */
       memcpy( &VisuInterface.hsAdjOutFeedTemp[0], (void*)dataObjOutFeedTemp.pData, sizeof(VisuInterface.hsAdjOutFeedTemp) );
      }
         
    /* force redraw if value has been entered */
    if (VisuInterface.hsXyChartElementInputCompletion)
      {
       outFeedChartInf.forceChartDraw                = 1;
       VisuInterface.hsXyChartElementInputCompletion = 0;
      }

    /* undo user changes */
    if ( (VisuInterface.hsChartUndo == 1) && (dataObjOutFeedTemp.pData) )
      {
       VisuInterface.hsChartUndo      = 0;
       outFeedChartInf.forceChartDraw = 1;
       memcpy( &VisuInterface.hsAdjOutFeedTemp[0], (void*)dataObjOutFeedTemp.pData, sizeof(VisuInterface.hsAdjOutFeedTemp) );
      }
      
    /* save chart data /Begin */
    if (VisuInterface.hsChartSave == 1) 
      {
       fDatObjWrite.enable  = 1;
       fDatObjWrite.ident   = dataObjOutFeedTemp.doIdent;
       fDatObjWrite.Offset  = 0;
       fDatObjWrite.pSource = (UDINT)&VisuInterface.hsAdjOutFeedTemp;
       fDatObjWrite.len     = sizeof(VisuInterface.hsAdjOutFeedTemp);
    
       DatObjWrite(&fDatObjWrite);
    
       if (fDatObjWrite.status != ERR_OK) 
         {
          dataObjOutFeedTemp.nbWrErr++;
          dataObjOutFeedTemp.lstWrErr = fDatObjWrite.status;
          VisuInterface.heatingAlarm[HEATING_OUTSIDE_FEED_DO_ERROR] = 1;
          ERRxwarning(fDatObjWrite.status, 0, "write chart out/feed temp.");
         }
      }

    /* animation - progress bar */
    if (VisuInterface.hsChartSave == 1)
      {
       VisuInterface.progressBarInf.index = 1;											/* start progress bar */
       VisuInterface.hsChartSave = 0;
      }
    else if ( (VisuInterface.progressBarInf.index > 0) && 
              (VisuInterface.progressBarInf.index < VisuInterface.progressBarInf.nbElements - 1) ) 									/* start progress bar if save has been actived */
      {
       if (VisuInterface.progressBarInf.timer >= VisuInterface.progressBarInf.duration)
         {
          VisuInterface.progressBarInf.timer = 0;
          VisuInterface.progressBarInf.index++;											/* next bitmap to increase progress bar */
         }
       else
         {
          VisuInterface.progressBarInf.timer += cycT;
         }
      }
    /* save chart data /End */
   }


 /***********************************************************************************************************************/
 /*** CHART CONTROL in 30.0                                                                                           ***/
 /***********************************************************************************************************************/
 /* set up chart for feed temperature according to outside temperature if not yet done /Begin */
 if ( (outFeedChartInf.id == 0) && (dataObjOutFeedTemp.pData) )
   {
    outFeedChartInf.nbValues   = dataObjOutFeedTemp.doLength / sizeof(xyChartElement_s);

    /* dynamic axis labeling for x-axis */
    chartXmin    = ((xyChartElement_s *)dataObjOutFeedTemp.pData)[0].x;
    chartXmiddle = ((xyChartElement_s *)dataObjOutFeedTemp.pData)[outFeedChartInf.nbValues / 2].x;
    chartXmax    = ((xyChartElement_s *)dataObjOutFeedTemp.pData)[outFeedChartInf.nbValues - 1].x;

    /* set width of samples according to width of chart and how many values should fit in chart */
    outFeedChartInf.samplesWidth = (CHART_OUTSIDE_FEED_TEMP_WIDTH - 1) / outFeedChartInf.nbValues;

    /* convert X grid width from �C to pixel according width of chart and value range */
    outFeedChartInf.gridX = CHART_OUTSIDE_FEED_TEMP_WIDTH / 														/* width of chart */
                            ( 
                             (( ((xyChartElement_s *)dataObjOutFeedTemp.pData)[outFeedChartInf.nbValues - 1].x - 	/* value range */
                               ((xyChartElement_s *)dataObjOutFeedTemp.pData)[0].x ) /
                             CHART_OUTSIDE_FEED_TEMP_GRID_X) + 1													/* grid with in �C */
                            );													


    /* convert Y grid width from �C to pixel according to height of chart and value range */
    outFeedChartInf.gridY = CHART_OUTSIDE_FEED_TEMP_HEIGHT / 														/* height of chart */
                            (
                             (CHART_OUTSIDE_FEED_TEMP_MAX_Y - CHART_OUTSIDE_FEED_TEMP_MIN_Y) /						/* value range */
                              CHART_OUTSIDE_FEED_TEMP_GRID_Y														/* grid with in �C */		
                            );									


    outFeedChartInf.status = TR_init( &outFeedChartInf.id, 							/* init trend */
                                       outFeedChartInf.nbValues,
                                       CHART_OUTSIDE_FEED_TEMP_UPPER_LEFT_X, 
                                       CHART_OUTSIDE_FEED_TEMP_UPPER_LEFT_Y, 
                                       outFeedChartInf.samplesWidth, 
                                       CHART_OUTSIDE_FEED_TEMP_HEIGHT,
                                       CHART_OUTSIDE_FEED_TEMP_BACK_COLOR );

                                        
    if (outFeedChartInf.status == 0)												/* if init ok -> add all curves to chart */
      {
	   outFeedChartInf.status = TR_addGrid( outFeedChartInf.id,						/* add grid to chart */
                                            outFeedChartInf.gridX, 
                                            outFeedChartInf.gridY, 
                                            CHART_OUTSIDE_FEED_TEMP_GRID_COLOR );

       if (outFeedChartInf.status)
         ERRxwarning( (UINT)outFeedChartInf.status, 0, "hs_trend: add grid original curve");


       /* original curve */
       outFeedChartInf.status = TR_addCurve(  outFeedChartInf.id, 
                                              0,									/* static trend */ 
                                              (UDINT *)&originalCurveInf.pData,
                                             &originalCurveInf.enable, 
                                              CHART_OUTSIDE_FEED_TEMP_MIN_Y, 
                                              CHART_OUTSIDE_FEED_TEMP_MAX_Y, 
                                              CHART_OUTSIDE_FEED_TEMP_ORIGINAL_CURVE_COLOR );
       if (outFeedChartInf.status)
         ERRxwarning( (UINT)outFeedChartInf.status, 0, "hs_trend: add original curve");

       /* day curve */
       outFeedChartInf.status = TR_addCurve(  outFeedChartInf.id, 
                                              0,									/* static trend */ 
                                              (UDINT *)&dayCurveInf.pData,
                                             &dayCurveInf.enable, 
                                              CHART_OUTSIDE_FEED_TEMP_MIN_Y, 
                                              CHART_OUTSIDE_FEED_TEMP_MAX_Y, 
                                              CHART_OUTSIDE_FEED_TEMP_DAY_CURVE_COLOR );
       if (outFeedChartInf.status)
         ERRxwarning( (UINT)outFeedChartInf.status, 0, "hs_trend: add day curve");

       /* night curve */
       outFeedChartInf.status = TR_addCurve(  outFeedChartInf.id, 
                                              0,									/* static trend */ 
                                              (UDINT *)&nightCurveInf.pData,
                                             &nightCurveInf.enable, 
                                              CHART_OUTSIDE_FEED_TEMP_MIN_Y, 
                                              CHART_OUTSIDE_FEED_TEMP_MAX_Y, 
                                              CHART_OUTSIDE_FEED_TEMP_NIGHT_CURVE_COLOR );
       if (outFeedChartInf.status)
         ERRxwarning( (UINT)outFeedChartInf.status, 0, "hs_trend: add night curve");

       /* not at home curve */
       outFeedChartInf.status = TR_addCurve(  outFeedChartInf.id, 
                                              0,									/* static trend */ 
                                              (UDINT *)&notAtHomeCurveInf.pData,
                                             &notAtHomeCurveInf.enable, 
                                              CHART_OUTSIDE_FEED_TEMP_MIN_Y, 
                                              CHART_OUTSIDE_FEED_TEMP_MAX_Y, 
                                              CHART_OUTSIDE_FEED_TEMP_NOT_AT_HOME_CURVE_COLOR );
       if (outFeedChartInf.status)
         ERRxwarning( (UINT)outFeedChartInf.status, 0, "hs_trend: add not at home curve");
      }
    else
      {
       ERRxwarning( (UINT)outFeedChartInf.status, 0, "hs_trend: TR_init chart");
      } /* if (outFeedChartInf.status == 0) */
   } /* if (outFeedChartInf.id == 0) */
 /* set up chart for feed temperature according to outside temperature if not yet done /End */


 /* draw chart only in 30.0 or 30.1 and if handle to vc interpreter exists /Begin */
 if ( ((VisuInterface.curPictNr == PIC_30_0) || (VisuInterface.curPictNr == PIC_30_1)) && 
      (vcHandle != 0)            &&
      (dataObjOutFeedTemp.pData) && 
      (originalCurveInf.pData)   && 
      (dayCurveInf.pData)        && 
      (nightCurveInf.pData)		 &&
      (notAtHomeCurveInf.pData) )
   {
    if ( (VisuInterface.curPictNr  != oldPictNr)        ||			/* draw chart if entered           */
         (HsMgrInf.manTempOffset   != oldManTempOffset) ||			/* user changed manual offset      */
         (HsMgrInf.dayOffset       != oldDayOffset)	    ||			/* user changed day offset         */
         (HsMgrInf.nightOffset     != oldNightOffset)   ||			/* user changed night offset       */
         (HsMgrInf.notAtHomeOffset != oldNotAtHomeOffset) )			/* user changed not at home offset */
      {
       outFeedChartInf.forceChartDraw = 1;
       oldManTempOffset   = HsMgrInf.manTempOffset;
       oldDayOffset       = HsMgrInf.dayOffset;
       oldNightOffset     = HsMgrInf.nightOffset;
       oldNotAtHomeOffset = HsMgrInf.notAtHomeOffset;
      }

    /* or any change by user or problems during last drawing (immediately after entering 30.0) */
    if (outFeedChartInf.forceChartDraw)
      {
       outFeedChartInf.forceChartDraw = 0;

       /* prepare curves for display (visible, data) /Begin */
       switch (VisuInterface.curPictNr)    
       {
        case PIC_30_0:
          originalCurveInf.enable    = 1;
          dayCurveInf.enable         = 1;
          nightCurveInf.enable       = 1;
          notAtHomeCurveInf.enable   = 1;

          /* copy curve data in buffer */
          for ( loopIndex = 0; 
               (loopIndex < outFeedChartInf.nbValues) && (originalCurveInf.pData != 0) && (dayCurveInf.pData != 0) && (nightCurveInf.pData != 0) && (notAtHomeCurveInf.pData != 0) && (dataObjOutFeedTemp.pData != 0); 
                loopIndex++ 
              )
            {
             originalCurveInf.pData[loopIndex]  = round( ((xyChartElement_s *)dataObjOutFeedTemp.pData)[loopIndex].y );
             dayCurveInf.pData[loopIndex]       = round( ((xyChartElement_s *)dataObjOutFeedTemp.pData)[loopIndex].y + HsMgrInf.dayOffset       + HsMgrInf.manTempOffset );
             nightCurveInf.pData[loopIndex]     = round( ((xyChartElement_s *)dataObjOutFeedTemp.pData)[loopIndex].y + HsMgrInf.nightOffset     + HsMgrInf.manTempOffset );
             notAtHomeCurveInf.pData[loopIndex] = round( ((xyChartElement_s *)dataObjOutFeedTemp.pData)[loopIndex].y + HsMgrInf.notAtHomeOffset + HsMgrInf.manTempOffset );
            }
        break;
        
        case PIC_30_1:
          originalCurveInf.enable    = 1;
          dayCurveInf.enable         = 0;
          nightCurveInf.enable       = 0;
          notAtHomeCurveInf.enable   = 0;

          /* copy curve data in buffer */
          for ( loopIndex = 0; 
               (loopIndex < outFeedChartInf.nbValues) && (originalCurveInf.pData != 0); 
                loopIndex++ 
              )
            {
             originalCurveInf.pData[loopIndex] = round( VisuInterface.hsAdjOutFeedTemp[loopIndex].y );
            }
        break;
       }
       /* prepare curves for display (visible, data) /End */
       
       /* draw chart */
       outFeedChartInf.status = TR_draw( 1, outFeedChartInf.id, vcHandle );
       if (outFeedChartInf.status != 0) outFeedChartInf.forceChartDraw = 1;		/* on error - once again */
       
      } /* if (outFeedChartInf.forceChartDraw) */
   } /* if ( ((VisuInterface.curPictNr == PIC_30_0) || (VisuInterface.curPictNr == PIC_30_1)) && (vcHandle != 0) ) */
 /* draw chart only in 30.0 or 30.1 and if handle to vc interpreter exists /End */

 /***********************************************************************************************************************/
 /*** CHART CONTROL in 30.5                                                                                           ***/
 /***********************************************************************************************************************/
 /* set up chart for temperature trend if not yet done /Begin */
 if (tempChartInf.id == 0)
   {
    tempChartInf.nbValues   = CHART_YEAR_TREND_MAX_DAYS;
    
    /* set width of samples according to width of chart and how many values should fit in chart */
    tempChartInf.samplesWidth = (CHART_YEAR_TEMP_TREND_WIDTH - 1) / (tempChartInf.nbValues - 1);

    /* convert X grid width from day to pixel according width of chart and value range */
    tempChartInf.gridX = CHART_YEAR_TEMP_TREND_WIDTH / 									/* width of chart */
                         ( 
                          (CHART_YEAR_TREND_MAX_DAYS /									/* day per year */
                          CHART_YEAR_TEMP_TREND_GRID_X) 								/* grid with in days */
                         ) + 1;													

    /* convert Y grid width from �C to pixel according to height of chart and value range */
    tempChartInf.gridY = CHART_YEAR_TEMP_TREND_HEIGHT / 											/* height of chart */
                            (
                             (CHART_YEAR_TEMP_TREND_MAX_Y - CHART_YEAR_TEMP_TREND_MIN_Y) /			/* value range */
                              CHART_YEAR_TEMP_TREND_GRID_Y											/* grid with in �C */		
                            );									


    tempChartInf.status = TR_init( &tempChartInf.id, 									/* init trend */
                                    tempChartInf.nbValues,
                                    CHART_YEAR_TEMP_TREND_UPPER_LEFT_X, 
                                    CHART_YEAR_TEMP_TREND_UPPER_LEFT_Y, 
                                    tempChartInf.samplesWidth, 
                                    CHART_YEAR_TEMP_TREND_HEIGHT,
                                    CHART_YEAR_TEMP_TREND_BACK_COLOR );
                                        
    if (tempChartInf.status == 0)														/* if init ok -> add all curves to chart */
      {
       tempChartInf.status = TR_addGrid( tempChartInf.id,								/* add grid to chart */
                                         tempChartInf.gridX, 
                                         tempChartInf.gridY, 
                                         CHART_YEAR_TEMP_TREND_GRID_COLOR);

       if (tempChartInf.status)
         ERRxwarning( (UINT)tempChartInf.status, 0, "hs_trend: add grid temperature curve");

       for (loopIndex = 0; loopIndex < CHART_YEAR_TREND_MAX_CURVE; loopIndex++)
       {
		/* choose color for trend */
		switch (loopIndex)
		{
			case 0:
		        colorIndex = 0;			/* black */
			break;
			
			case 1:
				colorIndex = 49;		/* orange */
			break;
			
			default:
				colorIndex = loopIndex;
			break;
		}
        tempChartInf.status = TR_addCurve(  tempChartInf.id, 
                                            0,											/* static trend */ 
                                            (UDINT *)&tempCurveInf[loopIndex].pData,
                                           &tempCurveInf[loopIndex].enable, 
                                            CHART_YEAR_TEMP_TREND_MIN_Y, 
                                            CHART_YEAR_TEMP_TREND_MAX_Y, 
                                            (USINT)colorIndex );
        if (tempChartInf.status)
          ERRxwarning( (UINT)tempChartInf.status, loopIndex, "hs_trend: add temperature curve");
       }
      }
    else
      {
       ERRxwarning( (UINT)heatChartInf.status, 0, "hs_trend: TR_init heating");
      } /* if (tempChartInf.status == 0) */
   } /* if (tempChartInf.id == 0) */
 /* set up chart for temperature trend if not yet done /End */


 /* set up chart for heating minutes trend if not yet done /Begin */
 if (heatChartInf.id == 0)
   {
    heatChartInf.nbValues   = CHART_YEAR_TREND_MAX_DAYS;
    
    /* set width of samples according to width of chart and how many values should fit in chart */
    heatChartInf.samplesWidth = (CHART_YEAR_HEAT_TREND_WIDTH - 1)/ (heatChartInf.nbValues - 1);

    /* convert X grid width from day to pixel according width of chart and value range */
    heatChartInf.gridX = CHART_YEAR_HEAT_TREND_WIDTH / 									/* width of chart */
                         ( 
                          (CHART_YEAR_TREND_MAX_DAYS /									/* day per year */
                          CHART_YEAR_HEAT_TREND_GRID_X)									/* grid with in days */
                         ) + 1;													

    /* convert Y grid width from minutes to pixel according to height of chart and value range */
    heatChartInf.gridY = CHART_YEAR_HEAT_TREND_HEIGHT / 								/* height of chart */
                         (
                          (CHART_YEAR_HEAT_TREND_MAX_Y - CHART_YEAR_HEAT_TREND_MIN_Y) /	/* value range */
                           CHART_YEAR_HEAT_TREND_GRID_Y									/* grid with in minutes */		
                         );									



    heatChartInf.status = TR_init( &heatChartInf.id, 									/* init trend */
                                    heatChartInf.nbValues,
                                    CHART_YEAR_HEAT_TREND_UPPER_LEFT_X, 
                                    CHART_YEAR_HEAT_TREND_UPPER_LEFT_Y, 
                                    heatChartInf.samplesWidth, 
                                    CHART_YEAR_HEAT_TREND_HEIGHT,
                                    CHART_YEAR_HEAT_TREND_BACK_COLOR );

    if (heatChartInf.status == 0)														/* if init ok -> add all curves to chart */
      {
       heatChartInf.status = TR_addGrid( heatChartInf.id,								/* add grid to chart */
                                         heatChartInf.gridX, 
                                         heatChartInf.gridY, 
                                         CHART_YEAR_HEAT_TREND_GRID_COLOR );

       if (heatChartInf.status)
         ERRxwarning( (UINT)heatChartInf.status, 0, "hs_trend: add grid heating curve");

       for (loopIndex = 0; loopIndex < CHART_YEAR_TREND_MAX_CURVE; loopIndex++)
       {
		/* choose color for trend */
		switch (loopIndex)
		{
			case 0:
		        colorIndex = 0;			/* black */
			break;
			
			case 1:
				colorIndex = 49;		/* orange */
			break;
			
			default:
				colorIndex = loopIndex;
			break;
		}
        heatChartInf.status = TR_addCurve(  heatChartInf.id, 
                                            0,											/* static trend */ 
                                            (UDINT *)&heatCurveInf[loopIndex].pData,
                                           &heatCurveInf[loopIndex].enable, 
                                            CHART_YEAR_HEAT_TREND_MIN_Y, 
                                            CHART_YEAR_HEAT_TREND_MAX_Y, 
                                            (USINT)colorIndex );
        if (heatChartInf.status)
          ERRxwarning( (UINT)heatChartInf.status, loopIndex, "hs_trend: add heating curve");
       }
      }
    else
      {
       ERRxwarning( (UINT)heatChartInf.status, 0, "hs_trend: TR_init heating");
      } /* if (heatChartInf.status == 0) */
   } /* if (heatChartInf.id == 0) */
 /* set up chart for heating minutes trend if not yet done /End */


 /* search for existing temperature trend data objects on user input /Begin */
 for (loopIndex = 0; loopIndex < CHART_YEAR_TREND_MAX_CURVE; loopIndex++)
 {
  if (yearTrendInf[loopIndex].inputCompleted)
    {
     yearTrendInf[loopIndex].inputCompleted = 0;
     heatChartInf.forceChartDraw            = 1;
     tempChartInf.forceChartDraw            = 1;

     /* generate new temperature curve type according to user input /Begin */
     if (VisuInterface.yearTempCurveTypeSelect[loopIndex] == 1)
       {
        if (++yearTrendInf[loopIndex].tempCurveType >= MAX_TEMP_CURVE_TYPES)
          yearTrendInf[loopIndex].tempCurveType = TEMP_CURVE_NOON;

        VisuInterface.yearTempCurveTypeSelect[loopIndex] = 0;
       }
     /* generate new temperature curve type according to user input /End */


     /* prepare temperature trend /Begin */
     if (yearTrendInf[loopIndex].tempCurveType == TEMP_CURVE_NOON)
       strcpy( &trendDOname[0], TEMP_NOON_TREND_DO_NAME_TEMPLATE );				/* "temp_xx" */
     else if (yearTrendInf[loopIndex].tempCurveType == TEMP_CURVE_MIN)  
       strcpy( &trendDOname[0], TEMP_MIN_TREND_DO_NAME_TEMPLATE );				/* "templxx" */
     else if (yearTrendInf[loopIndex].tempCurveType == TEMP_CURVE_MAX)  
       strcpy( &trendDOname[0], TEMP_MAX_TREND_DO_NAME_TEMPLATE );				/* "temphxx" */
     else 
       memset( &trendDOname[0], 0, sizeof(trendDOname) );

     trendDOname[5] = (yearTrendInf[loopIndex].date.year % 100) / 10 + '0';	/* 2002 -> 0 -> '0' */
     trendDOname[6] = (yearTrendInf[loopIndex].date.year % 100) % 10 + '0';	/* 2002 -> 2 -> '2' */
  
     fDatObjInfo.enable = 1;
     fDatObjInfo.pName  = (UDINT)&trendDOname[0];
 
     DatObjInfo(&fDatObjInfo);											/* get schedule */
 
     if ( (fDatObjInfo.status == ERR_OK) && (yearTrendInf[loopIndex].date.year >= 2000) )				/* error or before year 2000? */
       {
        tempCurveInf[loopIndex].enable = 1;

		/* in case of actual year -> limit calculation to yesterday (< maxDay) */
        if (yearTrendInf[loopIndex].date.year == CurrentTime.year)
          maxDay = getDayOfYear(&CurrentTime);
        else
          maxDay = CHART_YEAR_TREND_MAX_DAYS;

        /* reset sum value of temperature */
        sumYearTemp = 0;

        /* fill up trend buffer */
        for (subLoopIndex = 0; subLoopIndex < CHART_YEAR_TREND_MAX_DAYS; subLoopIndex++)
        {
         tempCurveInf[loopIndex].pData[subLoopIndex] = round( ((REAL*)fDatObjInfo.pDatObjMem)[subLoopIndex] );

         /* calculate total heating hours in a year */
       	 if (subLoopIndex < maxDay)
           sumYearTemp += ((REAL*)fDatObjInfo.pDatObjMem)[subLoopIndex];
        }
        
        /* calculate average temperature */
        if (maxDay > 0)
          yearTrendInf[loopIndex].yearTemp = sumYearTemp / maxDay;
        else
          yearTrendInf[loopIndex].yearTemp = 0;
       }
     else
       {
        tempCurveInf[loopIndex].enable = 0;
       }
     /* prepare temperature trend /End */


     /* get exact temperature if valid date is given and data object exists /Begin */  
     if ( (tempCurveInf[loopIndex].enable == 1) && (yearTrendInf[loopIndex].date.day > 0) && (yearTrendInf[loopIndex].date.month > 0) )
       {
        /* get number of day and access Data Object and read out integer value of data object */
        yearTrendInf[loopIndex].dayTemp = ((REAL*)fDatObjInfo.pDatObjMem)[(getDayOfYear(&yearTrendInf[loopIndex].date) - 1)]; 
       }
     /* get exact temperature if valid date is given and data object exists /End */  

     /* prepare heating minutes trend /Begin */
     strcpy( &trendDOname[0], HEAT_TREND_DO_NAME_TEMPLATE );				/* "heat_xx" */
     trendDOname[5] = (yearTrendInf[loopIndex].date.year % 100) / 10 + '0';	/* 2002 -> 0 -> '0' */
     trendDOname[6] = (yearTrendInf[loopIndex].date.year % 100) % 10 + '0';	/* 2002 -> 2 -> '2' */
  
     fDatObjInfo.enable = 1;
     fDatObjInfo.pName  = (UDINT)&trendDOname[0];
 
     DatObjInfo(&fDatObjInfo);											/* get schedule */
 
     if ( (fDatObjInfo.status == ERR_OK) && (yearTrendInf[loopIndex].date.year >= 2000) )				/* error or before year 2000? */
       {
        heatCurveInf[loopIndex].enable = 1;

		/* in case of actual year -> limit calculation to yesterday (< maxDay) */
        if (yearTrendInf[loopIndex].date.year == CurrentTime.year)
          maxDay = getDayOfYear(&CurrentTime);
        else
          maxDay = CHART_YEAR_TREND_MAX_DAYS;

        /* reset total hour counter */
        yearTrendInf[loopIndex].yearHeatingHours = 0;

        /* fill up trend buffer */
        for (subLoopIndex = 0; subLoopIndex < CHART_YEAR_TREND_MAX_DAYS; subLoopIndex++)
        {
       	 heatCurveInf[loopIndex].pData[subLoopIndex] = ((UDINT*)fDatObjInfo.pDatObjMem)[subLoopIndex];

         /* calculate total heating hours in a year */
       	 if (subLoopIndex < maxDay)
       	   yearTrendInf[loopIndex].yearHeatingHours += heatCurveInf[loopIndex].pData[subLoopIndex];
       	}
        
        /* hours -> minutes */
        yearTrendInf[loopIndex].yearHeatingHours /= 60;
       }
     else
       {
        heatCurveInf[loopIndex].enable = 0;
       }
     /* prepare heating minutes trend /End */

     /* get exact temperature if valid date is given and data object exists /Begin */  
     if ( (heatCurveInf[loopIndex].enable == 1) && (yearTrendInf[loopIndex].date.day > 0) && (yearTrendInf[loopIndex].date.month > 0) )
       {
        /* get number of day and access Data Object and read out integer value of data object */
        yearTrendInf[loopIndex].dayHeatingHours = (REAL)( ((UDINT*)fDatObjInfo.pDatObjMem)[(getDayOfYear(&yearTrendInf[loopIndex].date) - 1)] ) / 60; 
       }
     /* get exact temperature if valid date is given and data object exists /End */  

     /* mark input field if no curve can be displayed */     
     if ( (tempCurveInf[loopIndex].enable == 0) && (heatCurveInf[loopIndex].enable == 0) )
       yearTrendInf[loopIndex].date.year = 10000;						/* display: "****" because of four digits in visu */
    } /* if (yearTrendInf[loopIndex].inputCompleted) */
 } /* for (loopIndex = 0; loopIndex < CHART_YEAR_TREND_MAX_CURVE; loopIndex++) */
 /* search for existing temperature trend data objects on user input /End */



 /* draw chart only in 30.6 and if handle to vc interpreter exists /Begin */
 if ( (VisuInterface.curPictNr == PIC_30_6) && (vcHandle != 0) )
   {
    /* on entering 30.6: default trend of current year as first chart if not yet occopied */
    if (VisuInterface.curPictNr != oldPictNr)
      {
       for (loopIndex = 0; loopIndex < CHART_YEAR_TREND_MAX_CURVE; loopIndex++)
       {
        yearTrendInf[loopIndex].inputCompleted = 1;
       }

       /* assign default years if no year assigned */
       if ( (heatCurveInf[0].enable == 0) && (tempCurveInf[0].enable == 0) )
         {
          yearTrendInf[0].date.year = CurrentTime.year - 1;
         }

       if ( (heatCurveInf[1].enable == 0) && (tempCurveInf[1].enable == 0) )
         {
          yearTrendInf[1].date.year = CurrentTime.year;
         }
      }

    /* or any change by user or problems during last drawing (immediately after entering 30.5) */
    if (tempChartInf.forceChartDraw)
      {
       tempChartInf.forceChartDraw = 0;
    
       /* draw chart */
       tempChartInf.status = TR_draw( 1, tempChartInf.id, vcHandle );
       if (tempChartInf.status != 0) tempChartInf.forceChartDraw = 1;		/* on error - once again */

      } /* if (tempChartInf.forceChartDraw) */

    if (heatChartInf.forceChartDraw)
      {
       heatChartInf.forceChartDraw = 0;
    
       /* draw chart */
       heatChartInf.status = TR_draw( 1, heatChartInf.id, vcHandle );
       if (heatChartInf.status != 0) heatChartInf.forceChartDraw = 1;		/* on error - once again */

      } /* if (heatChartInf.forceChartDraw) */
   } /* if ( (VisuInterface.curPictNr == PIC_30_6) && (vcHandle != 0) ) */
 /* draw chart only in 30.6 and if handle to vc interpreter exists /End */



 /***********************************************************************************************************************/
 /*** CHART CONTROL in 30.6                                                                                           ***/
 /***********************************************************************************************************************/
 /* set up chart for temperature trend if not yet done /Begin */
 if (dayTempChartInf.id == 0)
   {
    dayTempChartInf.nbValues   = CHART_DAY_TREND_MAX_MINUTES;
    
    /* set width of samples according to width of chart and how many values should fit in chart */
    dayTempChartInf.samplesWidth = (CHART_DAY_TEMP_TREND_WIDTH - 1) / (dayTempChartInf.nbValues - 1);

    /* convert X grid width from minutes to pixel according width of chart and value range */
    dayTempChartInf.gridX = CHART_DAY_TEMP_TREND_WIDTH / 									/* width of chart */
                            ( 
                             (CHART_DAY_TREND_MAX_MINUTES /									/* minutes per day */
                              CHART_DAY_TEMP_TREND_GRID_X) 									/* grid within minutes */
                            );													

    /* convert Y grid width from �C to pixel according to height of chart and value range */
    dayTempChartInf.gridY = CHART_DAY_TEMP_TREND_HEIGHT / 									/* height of chart */
                            (
                             (CHART_DAY_TEMP_TREND_MAX_Y - CHART_DAY_TEMP_TREND_MIN_Y) /	/* value range */
                              CHART_DAY_TEMP_TREND_GRID_Y									/* grid with in �C */		
                            );									


    dayTempChartInf.status = TR_init( &dayTempChartInf.id, 									/* init trend */
                                       dayTempChartInf.nbValues,
                                       CHART_DAY_TEMP_TREND_UPPER_LEFT_X, 
                                       CHART_DAY_TEMP_TREND_UPPER_LEFT_Y, 
                                       dayTempChartInf.samplesWidth, 
                                       CHART_DAY_TEMP_TREND_HEIGHT,
                                       CHART_DAY_TEMP_TREND_BACK_COLOR );
                                        
    if (dayTempChartInf.status == 0)														/* if init ok -> add all curves to chart */
      {
       dayTempChartInf.status = TR_addGrid( dayTempChartInf.id,								/* add grid to chart */
                                            dayTempChartInf.gridX, 
                                            dayTempChartInf.gridY, 
                                            CHART_DAY_TEMP_TREND_GRID_COLOR);

       if (dayTempChartInf.status)
         ERRxwarning( (UINT)dayTempChartInf.status, loopIndex, "hs_trend: add grid temperature curve");

       /* temperature of today  */
       dayTempChartInf.status = TR_addCurve(  dayTempChartInf.id, 
                                             &dayTempCurveInf[HS_TREND_DAY_CURVE].liveValue,/* continous trend */ 
                                              (UDINT *)&dayTempCurveInf[HS_TREND_DAY_CURVE].pData,
                                             &dayTempCurveInf[HS_TREND_DAY_CURVE].enable, 
                                              CHART_YEAR_TEMP_TREND_MIN_Y, 
                                              CHART_YEAR_TEMP_TREND_MAX_Y, 
                                              CHART_DAY_TEMP_TODAY_CURVE_COLOR );
        if (dayTempChartInf.status)
          ERRxwarning( (UINT)dayTempChartInf.status, 0, "hs_trend: add day temp. curve");

       /* temperature of yesterday */
       dayTempChartInf.status = TR_addCurve(  dayTempChartInf.id, 
                                              0,											/* static trend */ 
                                              (UDINT *)&dayTempCurveInf[HS_TREND_YESTERDAY_CURVE].pData,
                                             &dayTempCurveInf[HS_TREND_YESTERDAY_CURVE].enable, 
                                              CHART_YEAR_TEMP_TREND_MIN_Y, 
                                              CHART_YEAR_TEMP_TREND_MAX_Y, 
                                              CHART_DAY_TEMP_YESTERDAY_CURVE_COLOR );
        if (dayTempChartInf.status)
          ERRxwarning( (UINT)dayTempChartInf.status, 0, "hs_trend: add yesterday temp. curve");
      }
    else
      {
       ERRxwarning( (UINT)dayTempChartInf.status, 0, "hs_trend: TR_init day");
      } /* if (dayTempChartInf.status == 0) */
   } /* if (dayTempChartInf.id == 0) */
 /* set up chart for temperature trend if not yet done /End */




 /* draw chart only in 30.5 and if handle to vc interpreter exists /Begin */
 if ( (VisuInterface.curPictNr == PIC_30_5) && (vcHandle != 0) )
   {
  	/* draw chart every minute or if 30.5 entered */
    if ( (newMinute) || (VisuInterface.curPictNr != oldPictNr) )        	      
      {
       dayTempChartInf.forceChartDraw = 1;
      }

    /* or any change by user or problems during last drawing */
    if (dayTempChartInf.forceChartDraw)
      {
       dayTempChartInf.forceChartDraw = 0;
    
       /* draw chart */
       dayTempChartInf.status = TR_draw( 1, dayTempChartInf.id, vcHandle );
       if (dayTempChartInf.status != 0) dayTempChartInf.forceChartDraw = 1;		/* on error - once again */
      }
   } /* if ( (VisuInterface.curPictNr == PIC_30_5) && (vcHandle != 0) ) */
 /* draw chart only in 30.5 and if handle to vc interpreter exists /End */

 oldPictNr = VisuInterface.curPictNr;  
}



/* get noon temperature trend data of current year /Begin */
void getTempTrendDataNoon()
{
 fDatObjInfo.enable = 1;

 strcpy( &trendDOname[0], TEMP_NOON_TREND_DO_NAME_TEMPLATE );			/* "temp_xx" */
 trendDOname[5] = (CurrentTime.year % 100) / 10 + '0';	/* 2001 -> 0 -> '0' */
 trendDOname[6] = (CurrentTime.year % 100) % 10 + '0';	/* 2001 -> 1 -> '1' */

 fDatObjInfo.pName = (UDINT)&trendDOname[0];
 
 DatObjInfo(&fDatObjInfo);												
 
 /* if it does not exist -> create it */
 if ( (fDatObjInfo.status == ERR_OK) && (CHART_YEAR_TREND_MAX_DAYS == fDatObjInfo.len / sizeof(REAL)) )
   {
    dataObjTempYearNoon.pData     = fDatObjInfo.pDatObjMem;							/* pointer to statistic information */
    dataObjTempYearNoon.doIdent   = fDatObjInfo.ident;								/* ident of data object containing statistic information */
    dataObjTempYearNoon.doLength  = fDatObjInfo.len;								/* length of data in data object */
    dataObjTempYearNoon.doMemType = fDatObjInfo.MemType;							/* memory of data object containing statistic information */
    dataObjTempYearNoon.doOption  = fDatObjInfo.Option;								/* additional options of data object containing statistic information */
    dataObjTempYearNoon.status    = fDatObjInfo.status;								/* return status */
   }
 else
   {
    fDatObjCreateTempNoon.enable   = 1;
    fDatObjCreateTempNoon.pName    = fDatObjInfo.pName;
    fDatObjCreateTempNoon.len      = CHART_YEAR_TREND_MAX_DAYS * sizeof(REAL);
    fDatObjCreateTempNoon.MemType  = doUSRROM;
    fDatObjCreateTempNoon.Option   = 0;
    fDatObjCreateTempNoon.pCpyData = 0;
    
    DatObjCreate(&fDatObjCreateTempNoon);

    if (fDatObjCreateTempNoon.status == ERR_OK)
      { 		
       dataObjTempYearNoon.pData     = fDatObjCreateTempNoon.pDatObjMem;				/* pointer to segment information */
       dataObjTempYearNoon.doIdent   = fDatObjCreateTempNoon.ident;						/* ident of data object containing schedule */
       dataObjTempYearNoon.doLength  = fDatObjCreateTempNoon.len;						/* length of data in data object */
       dataObjTempYearNoon.doMemType = fDatObjCreateTempNoon.MemType;					/* memory of data object containing schedule */
       dataObjTempYearNoon.doOption  = fDatObjCreateTempNoon.Option;					/* additional options of data object containing schedule */
      }

    dataObjTempYearNoon.status = fDatObjCreateTempNoon.status ;							/* return status */
   }
}
/* get noon temperature trend data of current year /End */


/* get minimum temperature trend data of current year /Begin */
void getTempTrendDataMin()
{
 fDatObjInfo.enable = 1;

 strcpy( &trendDOname[0], TEMP_MIN_TREND_DO_NAME_TEMPLATE );			/* "templxx" */
 trendDOname[5] = (CurrentTime.year % 100) / 10 + '0';	/* 2001 -> 0 -> '0' */
 trendDOname[6] = (CurrentTime.year % 100) % 10 + '0';	/* 2001 -> 1 -> '1' */

 fDatObjInfo.pName = (UDINT)&trendDOname[0];
 
 DatObjInfo(&fDatObjInfo);												
 
 /* if it does not exist -> create it */
 if ( (fDatObjInfo.status == ERR_OK) && (CHART_YEAR_TREND_MAX_DAYS == fDatObjInfo.len / sizeof(REAL)) )
   {
    dataObjTempYearMin.pData     = fDatObjInfo.pDatObjMem;							/* pointer to statistic information */
    dataObjTempYearMin.doIdent   = fDatObjInfo.ident;								/* ident of data object containing statistic information */
    dataObjTempYearMin.doLength  = fDatObjInfo.len;									/* length of data in data object */
    dataObjTempYearMin.doMemType = fDatObjInfo.MemType;								/* memory of data object containing statistic information */
    dataObjTempYearMin.doOption  = fDatObjInfo.Option;								/* additional options of data object containing statistic information */
    dataObjTempYearMin.status    = fDatObjInfo.status;								/* return status */
   }
 else
   {
    fDatObjCreateTempMin.enable   = 1;
    fDatObjCreateTempMin.pName    = fDatObjInfo.pName;
    fDatObjCreateTempMin.len      = CHART_YEAR_TREND_MAX_DAYS * sizeof(REAL);
    fDatObjCreateTempMin.MemType  = doUSRROM;
    fDatObjCreateTempMin.Option   = 0;
    fDatObjCreateTempMin.pCpyData = 0;
    
    DatObjCreate(&fDatObjCreateTempMin);

    if (fDatObjCreateTempMin.status == ERR_OK)
      { 		
       dataObjTempYearMin.pData     = fDatObjCreateTempMin.pDatObjMem;					/* pointer to segment information */
       dataObjTempYearMin.doIdent   = fDatObjCreateTempMin.ident;						/* ident of data object containing schedule */
       dataObjTempYearMin.doLength  = fDatObjCreateTempMin.len;						/* length of data in data object */
       dataObjTempYearMin.doMemType = fDatObjCreateTempMin.MemType;					/* memory of data object containing schedule */
       dataObjTempYearMin.doOption  = fDatObjCreateTempMin.Option;						/* additional options of data object containing schedule */
      }

    dataObjTempYearMin.status = fDatObjCreateTempMin.status ;							/* return status */
   }
}
/* get minimum temperature trend data of current year /End */


/* get maximum temperature trend data of current year /Begin */
void getTempTrendDataMax()
{
 fDatObjInfo.enable = 1;

 strcpy( &trendDOname[0], TEMP_MAX_TREND_DO_NAME_TEMPLATE );						/* "temphxx" */
 trendDOname[5] = (CurrentTime.year % 100) / 10 + '0';	/* 2001 -> 0 -> '0' */
 trendDOname[6] = (CurrentTime.year % 100) % 10 + '0';	/* 2001 -> 1 -> '1' */

 fDatObjInfo.pName = (UDINT)&trendDOname[0];
 
 DatObjInfo(&fDatObjInfo);												
 
 /* if it does not exist -> create it */
 if ( (fDatObjInfo.status == ERR_OK) && (CHART_YEAR_TREND_MAX_DAYS == fDatObjInfo.len / sizeof(REAL)) )
   {
    dataObjTempYearMax.pData     = fDatObjInfo.pDatObjMem;							/* pointer to statistic information */
    dataObjTempYearMax.doIdent   = fDatObjInfo.ident;								/* ident of data object containing statistic information */
    dataObjTempYearMax.doLength  = fDatObjInfo.len;									/* length of data in data object */
    dataObjTempYearMax.doMemType = fDatObjInfo.MemType;								/* memory of data object containing statistic information */
    dataObjTempYearMax.doOption  = fDatObjInfo.Option;								/* additional options of data object containing statistic information */
    dataObjTempYearMax.status    = fDatObjInfo.status;								/* return status */
   }
 else
   {
    fDatObjCreateTempMax.enable   = 1;
    fDatObjCreateTempMax.pName    = fDatObjInfo.pName;
    fDatObjCreateTempMax.len      = CHART_YEAR_TREND_MAX_DAYS * sizeof(REAL);
    fDatObjCreateTempMax.MemType  = doUSRROM;
    fDatObjCreateTempMax.Option   = 0;
    fDatObjCreateTempMax.pCpyData = 0;
    
    DatObjCreate(&fDatObjCreateTempMax);

    if (fDatObjCreateTempMax.status == ERR_OK)
      { 		
       dataObjTempYearMax.pData     = fDatObjCreateTempMax.pDatObjMem;					/* pointer to segment information */
       dataObjTempYearMax.doIdent   = fDatObjCreateTempMax.ident;						/* ident of data object containing schedule */
       dataObjTempYearMax.doLength  = fDatObjCreateTempMax.len;						/* length of data in data object */
       dataObjTempYearMax.doMemType = fDatObjCreateTempMax.MemType;					/* memory of data object containing schedule */
       dataObjTempYearMax.doOption  = fDatObjCreateTempMax.Option;						/* additional options of data object containing schedule */
      }

    dataObjTempYearMax.status = fDatObjCreateTempMax.status ;							/* return status */
   }
}
/* get maximum temperature trend data of current year /End */


 
/* get heating minutes trend data of current year /Begin */
void getHeatTrendData()
{
 fDatObjInfo.enable = 1;

 strcpy( &trendDOname[0], HEAT_TREND_DO_NAME_TEMPLATE );			/* "heat_xx" */
 trendDOname[5] = (CurrentTime.year % 100) / 10 + '0';	/* 2001 -> 0 -> '0' */
 trendDOname[6] = (CurrentTime.year % 100) % 10 + '0';	/* 2001 -> 1 -> '1' */

 fDatObjInfo.pName = (UDINT)&trendDOname[0];
 
 DatObjInfo(&fDatObjInfo);												
 
 /* if it does not exist -> create it */
 if ( (fDatObjInfo.status == ERR_OK) && (CHART_YEAR_TREND_MAX_DAYS == fDatObjInfo.len / sizeof(UDINT)) )
   {
    dataObjHeatYear.pData     = fDatObjInfo.pDatObjMem;							/* pointer to statistic information */
    dataObjHeatYear.doIdent   = fDatObjInfo.ident;								/* ident of data object containing statistic information */
    dataObjHeatYear.doLength  = fDatObjInfo.len;								/* length of data in data object */
    dataObjHeatYear.doMemType = fDatObjInfo.MemType;							/* memory of data object containing statistic information */
    dataObjHeatYear.doOption  = fDatObjInfo.Option;								/* additional options of data object containing statistic information */

    dataObjHeatYear.status    = fDatObjInfo.status;								/* return status */
   }
 else
   {
    fDatObjCreateHeat.enable   = 1;
    fDatObjCreateHeat.pName    = fDatObjInfo.pName;
    fDatObjCreateHeat.len      = CHART_YEAR_TREND_MAX_DAYS * sizeof(UDINT);
    fDatObjCreateHeat.MemType  = doUSRROM;
    fDatObjCreateHeat.Option   = 0;
    fDatObjCreateHeat.pCpyData = 0;
    
    DatObjCreate(&fDatObjCreateHeat);

    if (fDatObjCreateHeat.status == ERR_OK)
      { 		
       dataObjHeatYear.pData     = fDatObjCreateHeat.pDatObjMem;				/* pointer to segment information */
       dataObjHeatYear.doIdent   = fDatObjCreateHeat.ident;						/* ident of data object containing schedule */
       dataObjHeatYear.doLength  = fDatObjCreateHeat.len;						/* length of data in data object */
       dataObjHeatYear.doMemType = fDatObjCreateHeat.MemType;					/* memory of data object containing schedule */
       dataObjHeatYear.doOption  = fDatObjCreateHeat.Option;					/* additional options of data object containing schedule */
      }

    dataObjHeatYear.status = fDatObjCreateHeat.status;							/* return status */
   }
}
/* get heating minutes trend data of current year /End */

