/*********************************************************************************************
*  Copyright: 2001 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Managment System                                                    *
*    Purpose    Main Process of Building Management System                                   *
*                                                                                            *
*    Filename   mp_bms.c                                                                     *
*--------------------------------------------------------------------------------------------*
*  Description :                                                                             *
*   - configuration of general issues                                                        *
*   - acquisition of statistical data                                                        *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  History :                                                                                 *
*  Version       Datum         Autor                                                         *
*  01.00         05.07.01      W. Paulin     Created                                         *
*  01.01         23.12.01      W. Paulin     - calibration of touch with API functions       *
*                                            - saving statistical info just every hour       *
*  01.02         09.12.02      W. Paulin     - Save data simplified                          *
*  01.03         03.05.03      W. Paulin     - Communication Animation implemented           *
*  01.04         23.05.03      W. Paulin     - NewDataObject() used for data object init.    *
*                                              WEPA20030523                                  *
*********************************************************************************************/

#include <bur/plctypes.h>
#include <bms_gn.h>

_LOCAL DTGetTime_typ    fDTgetTime;
_LOCAL DTSetTime_typ    fDTsetTime;
_LOCAL USINT            newHour;
_LOCAL USINT            oldHour;
_LOCAL USINT            newMinute;
_LOCAL USINT            oldMinute;
_LOCAL UDINT            cycT;
_LOCAL RTInfo_typ       fRTInfo;

_LOCAL dataObjInf_s     dataObjBMS;

_LOCAL DatObjCreate_typ fDatObjCreate;
_LOCAL DatObjInfo_typ   fDatObjInfo;
_LOCAL DatObjWrite_typ  fDatObjWrite;
_LOCAL DatObjDelete_typ	fDatObjDelete;

_LOCAL USINT            oldPictNr;

_LOCAL UDINT			vcHandle;
_LOCAL UINT				status;

_LOCAL UINT				sComAnimation;
_LOCAL animationInf_s   *pComAnimation;
_LOCAL USINT			cmdCntUp;


#define sCOM_ANIMATION_INIT				0
#define sCOM_ANIMATION_LAPTOP			10
#define sCOM_ANIMATION_UPLINK			20
#define sCOM_ANIMATION_DOWNLINK			30
#define sCOM_ANIMATION_MODEM			40
#define sCOM_ANIMATION_CROSS_TRAFFIC	50


/* prototyping */
void initComAnimation();
void runComAnimation();



_INIT void mp_bmsini(void)
{
 fRTInfo.enable = 1; 
 RTInfo(&fRTInfo);
 
 cycT = fRTInfo.cycle_time / 1000;					/* transform cycle time us -> ms */


 /* get current time /Begin */
 fDTgetTime.enable = 1;
 DTGetTime(&fDTgetTime);
 if (fDTgetTime.status == 0)
   {
    DT_TO_DTStructure(fDTgetTime.DT1, (UDINT)&CurrentTime);
   }
 /* get current time /end */


 /* get saved statistic information /Begin */
 do		/* WEPA20030523 */
 {
  status = NewDataObject( &fDatObjCreate, &fDatObjDelete, BMS_STATISTIC_INFO_DO_NAME, doUSRROM, 0, &BMSstatistic, sizeof(BMSstatistic), &dataObjBMS);
 } while (status == ERR_FUB_BUSY);
 if (status != ERR_OK) VisuInterface.messageAlarm[BMS_STATISTIC_DO_ERROR] = 1;
 /* get saved statistic information /End */
}


_CYCLIC void mp_bmscyc(void)
{
 /* get current time /Begin */
 fDTgetTime.enable = 1;
 DTGetTime(&fDTgetTime);
 if (fDTgetTime.status == 0)
   {
    DT_TO_DTStructure(fDTgetTime.DT1, (UDINT)&CurrentTime);
   }
 /* get current time /end */


 /* generate new hour and new minute time flags */
 getTimeFlags( &CurrentTime, &newHour, &oldHour, &newMinute, &oldMinute, 0, 0);

 /***********************************************************************************************************************/
 /*** VISU INTERFACE                                                                                                  ***/
 /***********************************************************************************************************************/
 if (vcHandle == 0)
   vcHandle = VA_Setup(1, "visu");


 /* picture "Allgemeine Einstellungen" */
 if (VisuInterface.curPictNr == ALLG_EINST)
   {
    if (VisuInterface.curPictNr != oldPictNr)
      VisuInterface.newTime = CurrentTime;
      
    if (VisuInterface.setTime == 1)
      {
       fDTsetTime.enable = 1;
       fDTsetTime.DT1 = DTStructure_TO_DT((UDINT)&VisuInterface.newTime);
 
       DTSetTime(&fDTsetTime);
    
       VisuInterface.setTime = 0;
      }
   }

 if (newMinute)
   {
    /* convert operating minutes in hours */
    VisuInterface.rainWaterPumpHour          = (REAL)BMSstatistic.irrigationStatistic.onTimeRainWaterPump       / 60;
    VisuInterface.firingHour                 = (REAL)BMSstatistic.heatingStatistic.onTimeFiring                 / 60;
    VisuInterface.boilerPumpHour             = (REAL)BMSstatistic.heatingStatistic.onTimeBoilerPump             / 60;
    VisuInterface.heatingCirculationPumpHour = (REAL)BMSstatistic.heatingStatistic.onTimeHeatingCirculationPump / 60;
   }
 
 /* Touch calibration /Begin */
 if (VisuInterface.doTouchCalibration != TOUCH_CALIBRATION_DONE) 
   {
    if ( VA_Saccess(1, vcHandle) == 0 )
      {
       switch (VisuInterface.doTouchCalibration)
       {
        case CHANGE_TO_TOUCH_CALIBRATION_PICTURE:
          VisuInterface.newPictNr = TOUCH_CAL;
          VisuInterface.doTouchCalibration = START_TOUCH_CALIBRATION;
        break;

        case START_TOUCH_CALIBRATION:
          if (VisuInterface.curPictNr == TOUCH_CAL)
            {
             VA_StartTouchCal(1, vcHandle);
             VisuInterface.doTouchCalibration = GET_TOUCH_CALIBRATION_STATUS;
            }
        break;
        
        case GET_TOUCH_CALIBRATION_STATUS:
          status = VA_GetCalStatus (1, vcHandle);
          
          if ((status == 0) || (status == 0xFFFF))				/* all done or a general error occured */
            {
             VisuInterface.doTouchCalibration = TOUCH_CALIBRATION_DONE;
             VisuInterface.newPictNr          = ALLG_EINST;
            }
        break;
       }
      }

    VA_Srelease(1, vcHandle);
   }
 /* Touch calibration /End */

 
 /***********************************************************************************************************************/
 /*** SAVE DATA                                                                                                       ***/
 /***********************************************************************************************************************/
 /* save statistical information every hour /Begin */
 if (newHour)
   {
    fDatObjWrite.enable  = 1;
    fDatObjWrite.ident   = dataObjBMS.doIdent;
    fDatObjWrite.Offset  = 0;
    fDatObjWrite.pSource = (UDINT)&BMSstatistic;
    fDatObjWrite.len     = sizeof(BMSstatistic);
    
    DatObjWrite(&fDatObjWrite);
    
    if (fDatObjWrite.status != ERR_OK)
      {
       dataObjBMS.nbWrErr++;
       dataObjBMS.lstWrErr = fDatObjWrite.status;
       ERRxwarning(fDatObjWrite.status, 0, "write statistics");
      }
   }
 /* save statistical information every hour /End */

 /* communication animation /Begin */
 if (VisuInterface.curPictNr == COMMUNICATION)
   {
    /* init once on entry */
    if (oldPictNr != VisuInterface.curPictNr)			
      {
       initComAnimation();
      }
  
    /* run it */
    runComAnimation();
   } /* if (VisuInterface.curPictNr == COMMUNICATION) */
 /* communication animation /End */

 oldPictNr = VisuInterface.curPictNr;
}	


void initComAnimation()
{
 /* Laptop */
 VisuInterface.comLaptopAnimation.timer             = 0;
 VisuInterface.comLaptopAnimation.duration          = 200;
 VisuInterface.comLaptopAnimation.index             = 0;
 VisuInterface.comLaptopAnimation.nbElements        = 8;

 /* Uplink */
 VisuInterface.comUplinkAnimation.timer             = 0;
 VisuInterface.comUplinkAnimation.duration          = 60;
 VisuInterface.comUplinkAnimation.index             = 0;
 VisuInterface.comUplinkAnimation.nbElements        = 14;

 /* Downlink */
 VisuInterface.comDownlinkAnimation.timer           = 0;
 VisuInterface.comDownlinkAnimation.duration        = 60;
 VisuInterface.comDownlinkAnimation.index           = 0;
 VisuInterface.comDownlinkAnimation.nbElements      = 20;

 /* Modem */
 VisuInterface.comModemAnimation.timer              = 0;
 VisuInterface.comModemAnimation.duration           = 200;
 VisuInterface.comModemAnimation.index              = 0;
 VisuInterface.comModemAnimation.nbElements         = 10;

 /* Cross Traffic */
 VisuInterface.comCrossTrafficAnimation.timer       = 0;
 VisuInterface.comCrossTrafficAnimation.duration    = 200;
 VisuInterface.comCrossTrafficAnimation.index       = 0;
 VisuInterface.comCrossTrafficAnimation.nbElements  = 13;

 /* Heating */
 VisuInterface.comHeatingAnimation.timer            = 0;
 VisuInterface.comHeatingAnimation.duration         = 200;
 VisuInterface.comHeatingAnimation.index            = 0;
 VisuInterface.comHeatingAnimation.nbElements       = 6;

 /* Irrigation */
 VisuInterface.comIrrigationAnimation.timer         = 0;
 VisuInterface.comIrrigationAnimation.duration      = 150;
 VisuInterface.comIrrigationAnimation.index         = 0;
 VisuInterface.comIrrigationAnimation.nbElements    = 6;
 
 
 /* state machine */
 sComAnimation = sCOM_ANIMATION_INIT;
 
 /* misc */
 cmdCntUp = 1;
} /* void initComAnimation() */


void runComAnimation()
{
 switch (sComAnimation)
 {
  case sCOM_ANIMATION_INIT:
    initComAnimation();
    
    sComAnimation = sCOM_ANIMATION_LAPTOP;
  break;
 
  case sCOM_ANIMATION_LAPTOP:
    pComAnimation = &VisuInterface.comLaptopAnimation;
    
    /* switch to next animation area if last picture will be displayed */
    pComAnimation->timer += cycT;
    if ( pComAnimation->timer >= pComAnimation->duration )
      {
       pComAnimation->timer = 0;
     
       if ( ++pComAnimation->index >= pComAnimation->nbElements ) 
         {
          pComAnimation->index = 0;
          sComAnimation        = sCOM_ANIMATION_UPLINK;
         }
      }
  break;

  case sCOM_ANIMATION_UPLINK:
    pComAnimation = &VisuInterface.comUplinkAnimation;

    /* switch to next animation area if last picture will be displayed */
    pComAnimation->timer += cycT;
    if ( pComAnimation->timer >= pComAnimation->duration )
      {
       pComAnimation->timer = 0;
     
       if ( ++pComAnimation->index >= pComAnimation->nbElements ) 
         {
          pComAnimation->index = 0;
          sComAnimation        = sCOM_ANIMATION_DOWNLINK;
         }
      }
  break;

  case sCOM_ANIMATION_DOWNLINK:
    pComAnimation = &VisuInterface.comDownlinkAnimation;
    
    /* switch to next animation area if last picture will be displayed */
    pComAnimation->timer += cycT;
    if ( pComAnimation->timer >= pComAnimation->duration )
      {
       pComAnimation->timer = 0;
     
       if ( ++pComAnimation->index >= pComAnimation->nbElements ) 
         {
          pComAnimation->index = 0;
          sComAnimation        = sCOM_ANIMATION_MODEM;
         }
      }
  break;

  case sCOM_ANIMATION_MODEM:
    pComAnimation = &VisuInterface.comModemAnimation;
    
    /* switch to next animation area if last picture will be displayed */
    pComAnimation->timer += cycT;
    if ( pComAnimation->timer >= pComAnimation->duration )
      {
       pComAnimation->timer = 0;
     
       if ( ++pComAnimation->index >= pComAnimation->nbElements ) 
         {
          pComAnimation->index = 0;
          sComAnimation        = sCOM_ANIMATION_CROSS_TRAFFIC;
         }
      }
  break;
  
  case sCOM_ANIMATION_CROSS_TRAFFIC:
    pComAnimation = &VisuInterface.comCrossTrafficAnimation;
    
    /* switch to next animation area if last picture will be displayed */
    pComAnimation->timer += cycT;
    if ( pComAnimation->timer >= pComAnimation->duration )
      {
       pComAnimation->timer = 0;
     
       /* stay between heating and irrigation device */
       if (cmdCntUp)
       {
        if ( pComAnimation->index < (pComAnimation->nbElements - 1) ) 
          {
           pComAnimation->index++;
          }
        else
          {
           cmdCntUp = 0;
          }
       }
       else
       {
        if ( pComAnimation->index > 8 ) 
          {
           pComAnimation->index--;
          }
        else
          {
           cmdCntUp = 1;
          }
       }
         
       /* restart if heating and irrigiation animation has been finished */
       if ( VisuInterface.comHeatingAnimation.index == (VisuInterface.comHeatingAnimation.nbElements - 1) )
         {
          sComAnimation = sCOM_ANIMATION_INIT;
          break;
         }
      }
    
    /* heating animation when ever walking point is at heating device */  
    if ( (pComAnimation->index == 8) && (pComAnimation->timer == 0) )
    {
     if ( VisuInterface.comHeatingAnimation.index < (VisuInterface.comHeatingAnimation.nbElements - 1) )
       VisuInterface.comHeatingAnimation.index++;
    }
    
    /* irrigation animation if walking point reaches heating device */  
    if (pComAnimation->index >= 8)
    {
     VisuInterface.comIrrigationAnimation.timer += cycT;
     
     if (VisuInterface.comIrrigationAnimation.timer >= VisuInterface.comIrrigationAnimation.duration)
       {
        VisuInterface.comIrrigationAnimation.timer = 0;
        
        if ( ++VisuInterface.comIrrigationAnimation.index >= VisuInterface.comIrrigationAnimation.nbElements )
          VisuInterface.comIrrigationAnimation.index = 0;
       }
    }
  break;
 } /* switch (sComAnimation) */
 
} /* void runComAnimation() */