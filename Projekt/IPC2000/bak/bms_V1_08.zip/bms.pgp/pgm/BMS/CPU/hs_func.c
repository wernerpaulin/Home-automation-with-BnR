/*********************************************************************************************
*  Copyright: 2002 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Managment System                                                    *
*    Purpose    additional functions for heating system                                      *
*                                                                                            *
*    Filename   hs_func.c                                                                    *
*********************************************************************************************/

#include <bur/plctypes.h>
#include <bms_gn.h>

#define pidMAX(a,b)	( (a) > (b)? (a):(b) ) 		/* find maximum */
#define pidMIN(a,b)	( (a) < (b)? (a):(b) ) 		/* find minimum */


/****************************************************************************
**********                     	   lc2Point()                      **********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     Controls set and actual value including hysteresis with a two point   *
*     loop control                                                          *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       setValue       : set value                                          *
*       actValue       : actual value                                       *
*       highHysteresis : number of units in positive direction will be      *
*                        considered as hysteresis                           *
*       lowHysteresis  : number of units in negative direction will be      *
*                        considered as hysteresis                           *
*       pOutput        : pointer to output value (result of loop control):  *
*                        0 ...actValue > setValue + hysteresis              *
*                        1 ...actValue < setValue - hysteresis              *
*                                                                           *
*    Output:                                                                *
*       status                                                              *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       17.02.02    W. Paulin     created 							*
*   02.00       24.12.02    W. Paulin     separate values for hysteresis	*
*   02.01       25.12.02    W. Paulin     >= and <=                         *
****************************************************************************/
void lc2Point(REAL setValue, REAL actValue, REAL highHysteresis, REAL lowHysteresis, USINT *pOutput)
{
 if (actValue >= setValue + highHysteresis)					/* actual value to high and above hysteresis */
   *pOutput = 0;
 else if (actValue <= setValue - lowHysteresis)				/* actual value to low and below hysteresis */
   *pOutput = 1;
}

/****************************************************************************
**********                     		   lcPI()                      **********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     Controls set and actual value with a PI closed loop controller        *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       w		   : set value                                              *
*       x		   : actual value                                           *
*       pE		   : pointer to control deviation                           *
*       eMax	   : maximal control deviation for anti windup calculation  *
*       pY		   : pointer to output variable of controller               *
*       kp         : proportional factor                                    *
*       ki         : integral factor                                        *
*       pIntPart   : pointer to integral part                               *
*       loLimit    : minimum value                                          *
*       hiLimit    : maximum value                                          *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       17.02.02    W. Paulin     created 							*
*   01.01       06.07.02    W. Paulin     anti windup for int.-part impl.   *
*   01.02       13.07.02    W. Paulin     int. part without pPart           *
*   01.10       27.12.03    W. Paulin     new anti windup interface         *
****************************************************************************/
void lcPI(REAL w, REAL x, REAL *pE, REAL eMax, REAL *pY, REAL kp, REAL ki, REAL *pIntPart, REAL loLimit, REAL hiLimit)
{
 REAL pPart;
 
 if ((!pY) || (!pIntPart)) return;						/* nil pointer check */
 
 *pE = (w - x);											/* control deviation */

 pPart = *pE * kp;

 *pIntPart += *pE * ki;									/* calculate integral part */
 lcLimit(pIntPart, loLimit, hiLimit);					/* limit integral part */
 lcAntiWindup(pIntPart, eMax * kp, pPart);				/* anti windup of integral part*/

 *pY = pPart + *pIntPart;								/* add proportional and integral part */

 lcLimit(pY, loLimit, hiLimit);							/* limit new controller output value */
}


/****************************************************************************
**********                     	   lcLimit()                       **********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     Limits a given value within minimum and maximum values                *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       pValue     : pointer to value to be limited                         *
*       minValue   : lower limit value                                      *
*       maxValue   : upper limit value                                      *
*                                                                           *
*    Output:                                                                *
*       status                                                              *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       17.02.02    W. Paulin     created 							*
*   01.01       24.01.03    W. Paulin     NIL pointer check implemented	    *
****************************************************************************/
void lcLimit(REAL *pValue, REAL minValue, REAL maxValue)
{
 if (!pValue) return;
 
 if (*pValue > maxValue)
   *pValue = maxValue;
 else if (*pValue < minValue)
   *pValue = minValue;
}


/****************************************************************************
**********                    lcAntiWindup()                       **********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     Limits a given I-part according to actual control deviation           *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       pIntPart   : pointer to integral part                               *
*       iMax	   : maximal integral part                                  *
*       yp	       : proportional part of controller                        *
*                                                                           *
*    Output:                                                                *
*       status                                                              *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       06.07.02    W. Paulin     created 							*
*   02.00       27.12.03    W. Paulin     simplified, new interface 		*
****************************************************************************/
void lcAntiWindup(REAL *pIntPart, REAL iMax, REAL yp)
{
 REAL iLimit = 0;

 iLimit = pidMAX(iMax - abs(yp), 0);				/* get anti windup limit of i-part according control deviation */

 lcLimit(pIntPart, -iLimit, iLimit);				/* limit i-part */
}



/****************************************************************************
**********                   HeatingHotWaterMgr()                  **********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     Manages heating and hot water preparation                             *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       pBasicProgramm        : pointer heating and hot water information   *
*       pCurrentTime          : pointer to current time                     *
*       pHsMgrInf             : pointer to task info structure of hs_mgr    *
*       pHsLoopInf            : pointer to task info structure of hs_loop   *
*       pVisuInterface        : pointer to interface variable of visu       *
*                                                                           *
*    Output:                                                                *
*       status                                                              *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       03.03.02    W. Paulin     created 							*
*   01.01       29.06.02    W. Paulin     break if hotwater phase found		*
*   01.02       19.09.02    W. Paulin     add pVisuInterface		        *
****************************************************************************/
void HeatingHotWaterMgr(basicProgrammInf_s *pBasicProgramm, DTStructure *pCurrentTime, hsMgrInf_s *pHsMgrInf, hsLoopInf_s *pHsLoopInf, visuInterface_s *pVisuInterface)
{
 DTStructure 	currentTimeAdj;
 USINT 			hotWaterEnable = 0;
 USINT 			loopIndex = 0;
 
 currentTimeAdj = *pCurrentTime;									/* apply current time to local time in order to allow adjustments */
 

 /* heating /Begin */
 if ( TimeIsValid(&pBasicProgramm->heating.startTime, &pBasicProgramm->heating.endTime) ) 
   {
    pHsLoopInf->lcHeatingInf.enable = 1;

    /* if it is below -15�C outside -> start one hour earlier with heating */
    if (pHsMgrInf->outsideTemp <= SHIFT_HEATING_START_TEMPERATURE)  	
      {
       if (currentTimeAdj.hour == 23)
         currentTimeAdj.hour = 0;
       else
         currentTimeAdj.hour = currentTimeAdj.hour + 1;				/* simultate one hour earlier */
      }

    /* select either day or night offset depending on current time and offset for manual override */
    if ( TimeWithinBeginEnd(&pBasicProgramm->heating.startTime, &pBasicProgramm->heating.endTime, &currentTimeAdj) == TIME_IN_RANGE )
      pHsLoopInf->lcHeatingInf.setTempOffset = pHsMgrInf->dayOffset + pHsMgrInf->manTempOffset;
    else
      pHsLoopInf->lcHeatingInf.setTempOffset = pHsMgrInf->nightOffset + pHsMgrInf->manTempOffset;
   }
 else
   {
    pHsLoopInf->lcHeatingInf.enable = 0;
   }       
 /* heating /End */


 /* hot water  /Begin */
 hotWaterEnable = 0;
 for (loopIndex = 0; loopIndex < NB_HOT_WATER_PHASES; loopIndex++)
   {
    /* check which phase is within schedule */
    if ( TimeIsValid(&pBasicProgramm->hotWaterPhase[loopIndex].startTime, &pBasicProgramm->hotWaterPhase[loopIndex].endTime) ) 
      {
       if ( TimeWithinBeginEnd(&pBasicProgramm->hotWaterPhase[loopIndex].startTime, &pBasicProgramm->hotWaterPhase[loopIndex].endTime, &currentTimeAdj) == TIME_IN_RANGE )
         {
          hotWaterEnable = 1;
          pHsLoopInf->lcHotWaterInf.setTemp = pHsMgrInf->hotWaterSetTemp;
          break;
         }
       else
         {
          hotWaterEnable = 0;
         }
      }
    else
      {
       hotWaterEnable = 0;
      }       
   }
 
 /* heat up water once a week to critical temperature in order to kill bacteria */
 if ( (pCurrentTime->wday == 0) && (hotWaterEnable == 1) )
   {
    pHsLoopInf->lcHotWaterInf.setTemp = HS_KILL_BACTERIA_TEMP;
    pVisuInterface->messageAlarm[HEATING_KILL_BACTERIA_ACTIVE] = 1;
   }
 else
   {
    pVisuInterface->messageAlarm[HEATING_KILL_BACTERIA_ACTIVE] = 0;
   }  

   
 pHsLoopInf->lcHotWaterInf.enable = hotWaterEnable;
 /* hot water /End */
}

/****************************************************************************
**********                  	 mixerControl()    	               **********
*****************************************************************************
*                                                                           *
*  Description:                                                             *
*     controls mixer for heating system                                     *
*     if referencing is active, mixer will be close by running 20% more     *
*     then "fullyOpenTime" to close positon.                                *
*     Changes of set position during movement will be accepted              *
*                                                                           *
*  Interface:                                                               *
*     Input:                                                                *
*       pCmdHoming            : pointer of command to readust 0% position   *
*       setPosition           : desired postion of mixer in %               *
*       pOldSetPosition       : set position at start of movement in %      *
*       pActPosition          : pointer actual position of mixer in %       *
*       pStartPosition        : pointer to start position before movement % *
*       fullyOpenTime         : time which is needed for fully open pipe    *
*       deadTime              : time before mixer start real movement       *
*       pMoveTimer            : pointer to timer for position control       *
*       pSetPosTime           : time to get to set position                 *
*       pDir                  : pointer to direction output:                *
*                               -1 ...close                                 *
*                                0 ...stop                                  *
*                                1 ...open                                  *
*       cycT                  : cycle time of mixerControl()                *
*                                                                           *
*---------------------------------------------------------------------------*
*   History                                                                 *
*   Version     Date        Autor                                           *
*   01.00       24.03.02    W. Paulin     created 							*
*   01.01       05.04.02    W. Paulin     continuous calculation of actual  *
*                                         position                          *
*   01.02       06.04.02    W. Paulin     no online change of set position  *
*                                         deadTime no define any longer     *
*   01.03       30.06.02    W. Paulin     online change of set position re  *
*                                         implemented                       *
*   01.08       11.08.02    W. Paulin     online change only if direction   *
*                                         has changed                       *
****************************************************************************/
void mixerControl(USINT *pCmdHoming, USINT setPosition, USINT *pOldSetPosition, USINT *pActPosition, USINT *pStartPosition, UDINT fullyOpenTime, UDINT deadTime, UDINT *pPosTimer, UDINT *pSetPosTime, SINT *pDir, UDINT cycT)
{
 /* initial settings */
 if (*pPosTimer == 0)														/* referencing not yet started */
   {
    if (*pCmdHoming == HS_MIXER_DO_HOMING)									/* homing requested ? */
      {
       *pCmdHoming   = HS_MIXER_HOMING_ACTIVE;								/* acknowledge: homing in process */
       *pSetPosTime  = fullyOpenTime * 1.2;									/* take 20% more time to be sure to reach end position */
       *pSetPosTime += deadTime;											/* take care about dead time of mechanical construction of mixer */
       *pDir         = HS_MIXER_CLOSE;										/* use close position for referencing */
       *pPosTimer    = cycT;												/* don't loose a cycle and if case won't be executed next time */
      }
    else if (setPosition > *pActPosition )									/* new positive position to go to... */
      {
       if ( (setPosition - *pActPosition) > MIXER_MIN_DELTA_POSITON )
         {
          *pOldSetPosition = setPosition;
          *pSetPosTime     = (*pOldSetPosition - *pActPosition) * (fullyOpenTime / ONE_HUNDRED_PERCENT);
          *pSetPosTime    += deadTime;										/* take care about dead time of mechanical construction of mixer */
          *pDir            = HS_MIXER_OPEN;									/* -> open pipe */
          *pPosTimer       = cycT;											/* don't loose a cycle and if case won't be executed next time */
          *pStartPosition  = *pActPosition;									/* keep start position for continuous actual position in mind */    
         }
      }
    else if (setPosition < *pActPosition)									/* new negative position to go to... */
      {
       if ( (*pActPosition - setPosition) > MIXER_MIN_DELTA_POSITON )
         {
          *pOldSetPosition = setPosition;
          *pSetPosTime     = (*pActPosition - *pOldSetPosition) * (fullyOpenTime / ONE_HUNDRED_PERCENT);
          *pSetPosTime    += deadTime;						/* take care about dead time of mechanical construction of mixer */
          *pDir            = HS_MIXER_CLOSE;								/* -> close pipe */
          *pPosTimer       = cycT;											/* don't loose a cycle and if case won't be executed next time */
          *pStartPosition  = *pActPosition;									/* keep start position for continuous actual position in mind */    
         }
      }
   }


 /* follow online change during movement (*pPosTimer != 0) if set position changed and homing not active /Begin */
 if ( (*pOldSetPosition != setPosition) && (*pPosTimer != 0) && (*pCmdHoming == HS_MIXER_HOMING_DONE) )
   {
    if ( ((*pDir == HS_MIXER_OPEN)  && (setPosition < *pActPosition)) ||	/* mixer opens and new set position is before actual position */
         ((*pDir == HS_MIXER_CLOSE) && (setPosition > *pActPosition)) )   	/* mixer closes and new set position is beyond actual position */
      {
       *pDir = HS_MIXER_STOP;
       *pPosTimer = 0;
      }
   }
 /* follow online change during movement (*pPosTimer != 0) if set position changed and homing not active /Begin */

 
 /* continue in set direction as long as set postion is no yet reached */    
 if (*pPosTimer >= *pSetPosTime)				
   {
    *pDir = HS_MIXER_STOP;
    *pPosTimer = 0;

    if (*pCmdHoming == HS_MIXER_HOMING_ACTIVE) 
      {
       *pCmdHoming  = HS_MIXER_HOMING_DONE;
       *pActPosition = 0;
      }
    else
      {
       *pActPosition = *pOldSetPosition;
      }
   }
 else if (*pPosTimer > 0)
   {
    *pPosTimer += cycT;
  
    /* calculating actual position only if homing already done (not active) /Begin */
    if (*pCmdHoming == HS_MIXER_HOMING_DONE) 
      {
       if (*pDir == HS_MIXER_OPEN)
         *pActPosition = *pStartPosition + ( *pPosTimer / (fullyOpenTime / ONE_HUNDRED_PERCENT) );
       else
         *pActPosition = *pStartPosition - ( *pPosTimer / (fullyOpenTime / ONE_HUNDRED_PERCENT) );
      }
    /* calculating actual position only if homing already done (not active) /End */
   }
}

