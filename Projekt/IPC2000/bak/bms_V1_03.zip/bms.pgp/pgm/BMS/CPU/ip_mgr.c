/*********************************************************************************************
*  Copyright: 2001 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Managment System                                                    *
*    Purpose    Irrigation Plant Manager                                                     *
*                                                                                            *
*    Filename   ip_mgr.c                                                                     *
*--------------------------------------------------------------------------------------------*
*  Description :                                                                             *
*    handles irrigation of garden                                                            *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  Structures  :                                                                             *
*    segment_s                                                                               *
*             .beginDate         date after which activation of segment is generaly possible *
*                                (only month and day are decisive)                           *
*             .endDate           date until which activation of segment is generaly possible *
*                                (only month and day are decisive)                           *
*             .force             flag for manual control:                                    *
*                                  0 ...automatic mode                                       *
*                                  1 ...segment manually set inactive                        *
*                                  2 ...segment manually set active                          *
*             .useHumidity       determine whether humidity is taken in considuration or not:*
*                                  0 ...segment will be activated independent from humidity  *
*                                  1 ...humidity sensor No. 1 (kitchen garden) will be used  *
*                                  2 ...humidity sensor No. 2 (flower garden) will be used   *
*             .waterSource       determine the source of water for irrigation:               *
*                                  0 ...automatic mode (priority is on rainwater)            *
*                                  1 ...only rain water will be used (if not available       *
*                                       segment won't be activated)                          *
*                                  2 ...only service water will be used (if not available    *
*                                       segment won't be activated)                          *
*             .state             current state of segment:                                   *
*                                  0 ...segment is inactive                                  *
*                                  1 ...segment is ready to be activated according to        *
*                                       schedule                                             *
*                                  2 ...segment is active                                    *
*             .durationTimer     timer in minutes to calculated duration of active state     *
*             .pOutputValve      pointer to output variable of valve (assigned during        *
*                                INIT-SP)                                                    *
*             .oldOutputValve    old condition of output to detect edges (state checking)    *
*             .res0              reserved - not yet used                                     *
*             .valveStateTimer   timer to check after certain delay state of valve           *
*             .curPeriodNr       number of periode which is currently used                   *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  History :                                                                                 *
*  Version       Datum         Autor                                                         *
*  01.00         05.07.01      W. Paulin     Created                                         *
*  01.01         23.12.01      W. Paulin     modification due to new visualisation           *
*  01.02         03.02.02      W. Paulin     progress bar for saving implemented             *
*  01.03         02.05.02      W. Paulin     bugfix: valve check: no segmentNr variable      *
*  01.04         18.05.02      W. Paulin     bugfix: water source selection: WEPA 20020518   *
*  01.05         23.06.02      W. Paulin     check schedule only every once per minute       *
*  01.06         07.07.02      W. Paulin     automatic change from rain to service water dis.*
*                                            because of malfunction of valve?!               *
*                                            no switch off of valve is water source is not   *
*                                            available (may be sensor brocken but still work)*
*  01.07         12.07.02      W. Paulin     time out for forceing segments to active        *
*  01.08         09.12.02      W. Paulin     Life Guarding for CX408 implemented             *
*  01.09         23.12.02      W. Paulin     dry-alarms only if connection to CX408          *
*********************************************************************************************/

#include <bur/plctypes.h>
#include <bms_gn.h>
#include <bms_io.h>


_LOCAL segment_s         irrigationSegments[NB_SEGMENTS];
_LOCAL valveStateCheck_s valveStateCheck[NB_VALVES];

_LOCAL ipDaySchedule_s   ipDaySchedule[DAYS_OF_WEEK];
_LOCAL UINT              segmentNr;
_LOCAL UINT              valveNr;
_LOCAL UINT              status;

_LOCAL waterSourceInf_s  waterSourceInf;
_LOCAL RTInfo_typ        fRTInfo;
_LOCAL UDINT             pressDelayTimer;
_LOCAL UDINT             pressDelayTO;
_LOCAL UDINT             cycT;
_LOCAL UINT              valveNr;

_LOCAL dataObjInf_s      dataObjUserSchedule;
_LOCAL dataObjInf_s      dataObjDefaultSchedule;
_LOCAL dataObjInf_s      dataObjSegment;

_LOCAL USINT             defSegmentName[32];

_LOCAL DatObjInfo_typ    fDatObjInfo; 
_LOCAL DatObjCreate_typ  fDatObjCreate;
_LOCAL DatObjWrite_typ   fDatObjWriteSegInf;
_LOCAL DatObjWrite_typ   fDatObjWriteUserSchedule;
_LOCAL UINT              nbSegInfWrErr;
_LOCAL UINT              overviewIndex;

_LOCAL USINT             oldPictNr;

_LOCAL USINT 			 visuDayOfWeek;

_LOCAL USINT             newMinute;
_LOCAL USINT             oldMinute;

_LOCAL USINT			 sCX408lifeGuarding;
_LOCAL USINT 			 cmdStartCX408lifeGuarding;

_LOCAL USINT			 cmdBuffer[8];
_LOCAL USINT			 resBuffer[8];
_LOCAL CANIOcmd_typ      fCANIOcmd;


_INIT void ip_mgrini(void)
{
 fRTInfo.enable = 1; 
 RTInfo(&fRTInfo);
 
 cycT = fRTInfo.cycle_time / 1000;					/* transform cycle time us -> ms */
 
 pressDelayTimer   = 0;								/* delay timer for checking pressure after aktivating water source */
 pressDelayTO      = CHECK_PRESSURE_DELAY;			/* time out for checking pressure */
 
 /* read out schedule /Begin */
 fDatObjInfo.enable = 1;
 fDatObjInfo.pName = (UDINT)IP_SCHEDULE_USER_DO_NAME;
 
 DatObjInfo(&fDatObjInfo);													/* get schedule */
 
 if (fDatObjInfo.status != ERR_OK)											/* on error: try default schedule */
   {
    fDatObjInfo.enable = 1;
    fDatObjInfo.pName = (UDINT)IP_SCHEDULE_DEFAULT_DO_NAME;
 
    DatObjInfo(&fDatObjInfo);
  
    /* is either user specific or default schedule available ? */
    if (fDatObjInfo.status == ERR_OK) 
      {
       dataObjDefaultSchedule.pData     = fDatObjInfo.pDatObjMem;			/* pointer to schedule */
       dataObjDefaultSchedule.doIdent   = fDatObjInfo.ident;				/* ident of data object containing schedule */
       dataObjDefaultSchedule.doLength  = fDatObjInfo.len;					/* length of data in data object */
       dataObjDefaultSchedule.doMemType = fDatObjInfo.MemType;				/* memory of data object containing schedule */
       dataObjDefaultSchedule.doOption  = fDatObjInfo.Option;				/* additional options of data object containing schedule */
     
       memcpy( &ipDaySchedule[0], (void*)dataObjDefaultSchedule.pData, sizeof(ipDaySchedule) );		/* initialize schedule */
      }
    else
      {
       memset( &ipDaySchedule[0], 0, sizeof(ipDaySchedule) );				/* no valid schedule available */
       ERRxwarning(ERR_BMS_NO_IP_SCHEDULE, 0, "no schedule available");
      }
   }
 else
   {
    dataObjUserSchedule.pData     = fDatObjInfo.pDatObjMem;					/* pointer to schedule */
    dataObjUserSchedule.doIdent   = fDatObjInfo.ident;						/* ident of data object containing schedule */
    dataObjUserSchedule.doLength  = fDatObjInfo.len;						/* length of data in data object */
    dataObjUserSchedule.doMemType = fDatObjInfo.MemType;					/* memory of data object containing schedule */
    dataObjUserSchedule.doOption  = fDatObjInfo.Option;						/* additional options of data object containing schedule */
     
    memcpy( &ipDaySchedule[0], (void*)dataObjUserSchedule.pData, sizeof(ipDaySchedule) );		/* initialize schedule */
   }
   
 /* read out schedule /End */
 

 /* read out segment information /Begin */
 fDatObjInfo.enable = 1;
 fDatObjInfo.pName = (UDINT)IP_SEGMENT_INFO_DO_NAME;
 
 DatObjInfo(&fDatObjInfo);												/* get segment information */
 
 /* is either user specific or default schedule available and valid? */
 if ( (fDatObjInfo.status == ERR_OK) && (sizeof(irrigationSegments) == fDatObjInfo.len) )
   {
    dataObjSegment.pData     = fDatObjInfo.pDatObjMem;					/* pointer to segment information */
    dataObjSegment.doIdent   = fDatObjInfo.ident;						/* ident of data object containing schedule */
    dataObjSegment.doLength  = fDatObjInfo.len;							/* length of data in data object */
    dataObjSegment.doMemType = fDatObjInfo.MemType;						/* memory of data object containing schedule */
    dataObjSegment.doOption  = fDatObjInfo.Option;						/* additional options of data object containing schedule */
    
    memcpy( &irrigationSegments[0], (void*)dataObjSegment.pData, sizeof(irrigationSegments) );		/* initalize segment information structure */

    /* reset manual active to automatic mode */
    for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++)
    {
     if (irrigationSegments[segmentNr].force == SEGMENT_MAN_ACTIVE)
       irrigationSegments[segmentNr].force = SEGMENT_MODE_AUTO;

     VisuInterface.segmentNewForce[segmentNr] = irrigationSegments[segmentNr].force;
     
     irrigationSegments[segmentNr].state = SEGMENT_INACTIVE; 

     if ( (irrigationSegments[segmentNr].beginDate.month == 0) ||
          (irrigationSegments[segmentNr].beginDate.day   == 0) ||
          (irrigationSegments[segmentNr].endDate.month   == 0) ||
          (irrigationSegments[segmentNr].endDate.day     == 0) )
       {
        irrigationSegments[segmentNr].beginDate.month = 4;
        irrigationSegments[segmentNr].beginDate.day   = 1;
        irrigationSegments[segmentNr].endDate.month   = 10;
        irrigationSegments[segmentNr].endDate.day     = 1;
       }
    }

   }
 else
   {
    memset( &irrigationSegments[0], 0, sizeof(irrigationSegments) );	/* no segment information available */

    /* preinitilaizise segment information structures /Begin */
    for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++)
    {
     switch (segmentNr)
     {
      case 0: strcpy(&irrigationSegments[0].name[0], "Rasen"); 					break;
      case 1: strcpy(&irrigationSegments[1].name[0], "beide Grander"); 			break;
      case 2: strcpy(&irrigationSegments[2].name[0], "Gemuesegarten - oben");	break;
      case 3: strcpy(&irrigationSegments[3].name[0], "Gemuesegarten - unten"); 	break;
      case 4: strcpy(&irrigationSegments[4].name[0], "Gemuesegarten - mitte"); 	break;
      case 5: strcpy(&irrigationSegments[5].name[0], "Blumenhang"); 			break;
     }
        
     irrigationSegments[segmentNr].beginDate.month = 4;
     irrigationSegments[segmentNr].beginDate.day   = 1;
     irrigationSegments[segmentNr].endDate.month   = 10;
     irrigationSegments[segmentNr].endDate.day     = 1;
     irrigationSegments[segmentNr].force           = SEGMENT_MODE_AUTO;
     
     if (segmentNr == 5)
       irrigationSegments[segmentNr].useHumidity     = HUMIDITY_KITCHEN_GARDEN;
     else
       irrigationSegments[segmentNr].useHumidity     = HUMIDITY_FLOWER_GARDEN;
    
     irrigationSegments[segmentNr].waterSource     = WATER_SOURCE_RAIN; 
    }
    /* preinitilaizise segment information structures /End */

    fDatObjCreate.enable   = 1;
    fDatObjCreate.pName    = (UDINT)IP_SEGMENT_INFO_DO_NAME;
    fDatObjCreate.len      = sizeof(irrigationSegments);

    fDatObjCreate.MemType  = doUSRROM;
    fDatObjCreate.Option   = 0;
    fDatObjCreate.pCpyData = (UDINT)&irrigationSegments[0];
    
    DatObjCreate(&fDatObjCreate);

    if (fDatObjCreate.status == ERR_OK)
      { 
       dataObjSegment.pData     = fDatObjCreate.pDatObjMem;					/* pointer to segment information */
       dataObjSegment.doIdent   = fDatObjCreate.ident;						/* ident of data object containing schedule */
       dataObjSegment.doLength  = fDatObjCreate.len;						/* length of data in data object */
       dataObjSegment.doMemType = fDatObjCreate.MemType;					/* memory of data object containing schedule */
       dataObjSegment.doOption  = fDatObjCreate.Option;						/* additional options of data object containing schedule */
      }
   }
 /* read out segment information /End */



 /* assigne valve outputs to segment structure /Begin */
 irrigationSegments[0].pOutputValve   = &oValveSeg1;
 irrigationSegments[1].pOutputValve   = &oValveSeg2;
 irrigationSegments[2].pOutputValve   = &oValveSeg3;
 irrigationSegments[3].pOutputValve   = &oValveSeg4;
 irrigationSegments[4].pOutputValve   = &oValveSeg5;
 irrigationSegments[5].pOutputValve   = &oValveSeg6;
 /* assigne valve outputs to segment structure /Begin */

 /* prepare valve check /Begin */
 valveStateCheck[0].valveStateDelayTO = CHECK_VALVE_STATE_DELAY;
 valveStateCheck[1].valveStateDelayTO = CHECK_VALVE_STATE_DELAY;
 valveStateCheck[2].valveStateDelayTO = CHECK_VALVE_STATE_DELAY;
 valveStateCheck[3].valveStateDelayTO = CHECK_VALVE_STATE_DELAY;
 valveStateCheck[4].valveStateDelayTO = CHECK_VALVE_STATE_DELAY;
 valveStateCheck[5].valveStateDelayTO = CHECK_VALVE_STATE_DELAY;
 valveStateCheck[6].valveStateDelayTO = CHECK_VALVE_STATE_DELAY;

 valveStateCheck[0].pInputValveState  = &iValveStateSeg1;
 valveStateCheck[1].pInputValveState  = &iValveStateSeg2;
 valveStateCheck[2].pInputValveState  = &iValveStateSeg3;
 valveStateCheck[3].pInputValveState  = &iValveStateSeg4;
 valveStateCheck[4].pInputValveState  = &iValveStateSeg5;
 valveStateCheck[5].pInputValveState  = &iValveStateSeg6;
 valveStateCheck[6].pInputValveState  = &iValveStateServiceWater;

 valveStateCheck[0].pOutputValve   = &oValveSeg1;
 valveStateCheck[1].pOutputValve   = &oValveSeg2;
 valveStateCheck[2].pOutputValve   = &oValveSeg3;
 valveStateCheck[3].pOutputValve   = &oValveSeg4;
 valveStateCheck[4].pOutputValve   = &oValveSeg5;
 valveStateCheck[5].pOutputValve   = &oValveSeg6;
 valveStateCheck[6].pOutputValve   = &oValveServiceWater;

 valveStateCheck[0].oldOutputValve = oValveSeg1;
 valveStateCheck[1].oldOutputValve = oValveSeg2;
 valveStateCheck[2].oldOutputValve = oValveSeg3;
 valveStateCheck[3].oldOutputValve = oValveSeg4;
 valveStateCheck[4].oldOutputValve = oValveSeg5;
 valveStateCheck[5].oldOutputValve = oValveSeg6;
 valveStateCheck[6].oldOutputValve = oValveServiceWater;
 /* prepare valve check /End */


 /* animation - Rasen */
 VisuInterface.ipAnimationInf[0].timer      = 0;
 VisuInterface.ipAnimationInf[0].duration   = 150;
 VisuInterface.ipAnimationInf[0].index      = 0; 
 VisuInterface.ipAnimationInf[0].nbElements = 5;
 
 /* animation - Blumentrog */
 VisuInterface.ipAnimationInf[1].timer      = 0;
 VisuInterface.ipAnimationInf[1].duration   = 150;
 VisuInterface.ipAnimationInf[1].index      = 0; 
 VisuInterface.ipAnimationInf[1].nbElements = 5;
 
 /* animation - Gem�segarten oben */
 VisuInterface.ipAnimationInf[2].timer      = 0;
 VisuInterface.ipAnimationInf[2].duration   = 350;
 VisuInterface.ipAnimationInf[2].index      = 0; 
 VisuInterface.ipAnimationInf[2].nbElements = 4;

 /* animation - Gem�segarten unten */
 VisuInterface.ipAnimationInf[3].timer      = 0;
 VisuInterface.ipAnimationInf[3].duration   = 350;
 VisuInterface.ipAnimationInf[3].index      = 0; 
 VisuInterface.ipAnimationInf[3].nbElements = 4;
 
 /* animation - Gem�segarten mitte */
 VisuInterface.ipAnimationInf[4].timer      = 0;
 VisuInterface.ipAnimationInf[4].duration   = 350;
 VisuInterface.ipAnimationInf[4].index      = 0; 
 VisuInterface.ipAnimationInf[4].nbElements = 4;

 /* animation - Blumenhang */
 VisuInterface.ipAnimationInf[5].timer      = 0;
 VisuInterface.ipAnimationInf[5].duration   = 150;
 VisuInterface.ipAnimationInf[5].index      = 0; 
 VisuInterface.ipAnimationInf[5].nbElements = 7;
 
 /* animation - progress bar */
 VisuInterface.progressBarInf.timer         = 0; 
 VisuInterface.progressBarInf.duration      = 50; 
 VisuInterface.progressBarInf.index         = 0; 
 VisuInterface.progressBarInf.nbElements    = 11;
 
 VisuInterface.ipAlarmGroup      = IRRIGATION_ALARM_GROUP;
 VisuInterface.ipAlarmFilterCtrl = VC_ALARM_FILTER_TYPE_GROUP;
 VisuInterface.segmentForceTimeout = IRRIGATION_SEGMENT_FORCE_TIMEOUT;
}




_CYCLIC void ip_mgrcyc(void)
{
 /* generate new hour and new minute time flags */
 getTimeFlags( &CurrentTime, 0, 0, &newMinute, &oldMinute, 0, 0);

 
 /***********************************************************************************************************************/
 /*** AUTOMATIC MODE                                                                                                  ***/
 /***********************************************************************************************************************/
 status = CheckIrrigationSchedule(&ipDaySchedule[CurrentTime.wday], &irrigationSegments[0], &CurrentTime);

 /* set segment to state ACTIVE if it is on schedule and other conditions are given */
 if (status == ERR_BMS_NO_ERR) 
   {
    for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++)
    {
     if (irrigationSegments[segmentNr].force != SEGMENT_MODE_AUTO)        continue;		/* segment is not configured for automatic operation */

     if (irrigationSegments[segmentNr].state != SEGMENT_READY_FOR_ACTIVE) continue;		/* wrong state -> not to be activated */
    
     if (DateIsValid(&irrigationSegments[segmentNr].beginDate , &irrigationSegments[segmentNr].endDate) == DATE_INVALID) continue;
     
     if (DateWithinBeginEnd(&irrigationSegments[segmentNr].beginDate , &irrigationSegments[segmentNr].endDate , &CurrentTime) == DATE_OUT_OF_RANGE) continue;
     
     if (irrigationSegments[segmentNr].useHumidity != NO_HUMIDITY_CHECK)
       {
        switch (irrigationSegments[segmentNr].useHumidity)
          {
           case HUMIDITY_KITCHEN_GARDEN:
             if (iHumKitchenGarden1 == 1) continue;				/* kitchen garden is still to wet */
           break;
             
           case HUMIDITY_FLOWER_GARDEN:
             if (iHumFlowerGarden1 == 1) continue;				/* flower garden is still to wet */
           break;
          }
       }
     
     /* no more reasons to avoid beeing activated */
     irrigationSegments[segmentNr].state = SEGMENT_ACTIVE;
     waterSourceInf.type = irrigationSegments[segmentNr].waterSource;
    }
 } /* if (status == ERR_BMS_NO_ERR) */


 
 /***********************************************************************************************************************/
 /*** MANUAL MODE                                                                                                     ***/
 /***********************************************************************************************************************/
 for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++)
 {
  /* switch of force if it is too long switched on */
  if ( (irrigationSegments[segmentNr].durationTimer >= VisuInterface.segmentForceTimeout) &&
       (irrigationSegments[segmentNr].force         == SEGMENT_MAN_ACTIVE) )
    {
     irrigationSegments[segmentNr].force = SEGMENT_MAN_INACTIVE;
    }
     
  /* segment switch off manually */
  if (irrigationSegments[segmentNr].force == SEGMENT_MAN_INACTIVE)
    {
     irrigationSegments[segmentNr].state = SEGMENT_INACTIVE;
    }
  else if (irrigationSegments[segmentNr].force == SEGMENT_MAN_ACTIVE)
    {
     irrigationSegments[segmentNr].state = SEGMENT_ACTIVE;
     waterSourceInf.type    = irrigationSegments[segmentNr].waterSource;
    }
 } /* for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++) */


 /***********************************************************************************************************************/
 /*** DURATION                                                                                                        ***/
 /***********************************************************************************************************************/
 for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++)
 {
  if (irrigationSegments[segmentNr].state == SEGMENT_ACTIVE)
    {
     if (newMinute)
       irrigationSegments[segmentNr].durationTimer++;
    }
  else
    {
     irrigationSegments[segmentNr].durationTimer = 0;
    }
 }


 /***********************************************************************************************************************/
 /*** ANIMATED BITMAP FOR SIMULATION OF IRRIGATION                                                                    ***/
 /***********************************************************************************************************************/
 for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++)
   {
    if (VisuInterface.ipAnimationInf[segmentNr].timer >= VisuInterface.ipAnimationInf[segmentNr].duration)
      {
       VisuInterface.ipAnimationInf[segmentNr].timer = 0;
 
       if (irrigationSegments[segmentNr].state == SEGMENT_ACTIVE)
          {
           VisuInterface.ipAnimationInf[segmentNr].index++;								/* next bitmap to keep irrgation alive */
 
           if (VisuInterface.ipAnimationInf[segmentNr].index >= VisuInterface.ipAnimationInf[segmentNr].nbElements)
             VisuInterface.ipAnimationInf[segmentNr].index = 1;
          }
        else
          {
           VisuInterface.ipAnimationInf[segmentNr].index = 0;
          }
      }
    else
      {
       VisuInterface.ipAnimationInf[segmentNr].timer += cycT;
      }
   } /* for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++) */


 /***********************************************************************************************************************/
 /*** NEED SOME WATER?                                                                                                ***/
 /***********************************************************************************************************************/
 waterSourceInf.request = 0;
 for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++)
 {
  if (irrigationSegments[segmentNr].state == SEGMENT_ACTIVE)
    { 
     waterSourceInf.request = 1;										/* water is need - at least one segment is active */
     break;
    }
 }
 
 
  
 /***********************************************************************************************************************/
 /*** SELECT WATER SOURCE                                                                                             ***/
 /***********************************************************************************************************************/
 /* handle water request /Begin */
 if (waterSourceInf.request == 1)
   { 
    switch (waterSourceInf.type)
    {
#warning: Automatische Umschaltung zu Nutzwasser deaktiviert (Nutzwasser fliesst nicht -> Sperrventil vermutl. falsch eingebaut)
#if 0
     case WATER_SOURCE_AUTO:
       /* priority is on rain water if not yet desided */
       if (waterSourceInf.available == WATER_SOURCE_UNKNOWN)
         {
          oValveServiceWater  = 0;
          oRainWaterPump      = 1;
         }

       /* use service water if rain water is not available */
       if ( (oRainWaterPump == 1) && (oValveServiceWater == 0) && (waterSourceInf.available == WATER_SOURCE_NOT_AVAILABLE) )
         {
          oValveServiceWater = 1;
          oRainWaterPump     = 0;
         }
     break;
#endif

     case WATER_SOURCE_RAIN:											
       oValveServiceWater    = 0;
       oRainWaterPump        = 1;
     break;

     case WATER_SOURCE_SERVICE:											
       oValveServiceWater    = 1;
       oRainWaterPump        = 0;
     break;

     default:															
       oValveServiceWater    = 0;
       oRainWaterPump        = 1;
     break;
    }
   }
 else
   {
    oValveServiceWater       = 0;
    oRainWaterPump           = 0;
    pressDelayTimer          = 0;										/* reset timer if no request pending */  /* WEPA 20020518 */
   }
   
 if ( (oRainWaterPump == 1) && (newMinute == 1) )	
   BMSstatistic.irrigationStatistic.onTimeRainWaterPump++;				/* statistics: on time of rain water pump in minutes */
 /* handle water request /End */

 /* determine condition of water source /Begin */
 if (iWaterPressure == 1)
   {
    waterSourceInf.available = WATER_SOURCE_AVAILABLE;
   }
 else if ( (pressDelayTimer >= pressDelayTO) && (iWaterPressure == 0) && ( (oRainWaterPump == 1) || (oValveServiceWater == 1) ) )
   {
    waterSourceInf.available = WATER_SOURCE_NOT_AVAILABLE;
   }
  else
   {
    pressDelayTimer += cycT;
    waterSourceInf.available = WATER_SOURCE_UNKNOWN;
   }
 /* determine condition of water source /End */




 /***********************************************************************************************************************/
 /*** CONTROL VALVES                                                                                                  ***/
 /***********************************************************************************************************************/
 /* control outputs /Begin */
 for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++)
 {
  if (irrigationSegments[segmentNr].state == SEGMENT_ACTIVE)
    *(irrigationSegments[segmentNr].pOutputValve) = 1;
  else
    *(irrigationSegments[segmentNr].pOutputValve) = 0;

#if 0
  /* close valve in automatic mode if water source is not available */
  if ( (irrigationSegments[segmentNr].force == SEGMENT_MODE_AUTO) && (waterSourceInf.available == WATER_SOURCE_NOT_AVAILABLE) )
    {
     *(irrigationSegments[segmentNr].pOutputValve) = 0;					
    }
#endif
 } /* for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++) */
 
 /* control outputs /End */

 
 /* valve check /Begin */
 for (valveNr = 0; valveNr < NB_VALVES; valveNr++)
 {
  /* reset timer with every edge of output */
  if ( *(valveStateCheck[valveNr].pOutputValve) != valveStateCheck[valveNr].oldOutputValve ) 
    {
     valveStateCheck[valveNr].valveStateTimer = 0;
     valveStateCheck[valveNr].oldOutputValve = *(valveStateCheck[valveNr].pOutputValve);
     BMSstatistic.irrigationStatistic.nbSwitchValve[valveNr]++;			/* statistics: number switches */
    }

  if (valveStateCheck[valveNr].valveStateTimer <= valveStateCheck[valveNr].valveStateDelayTO)
    valveStateCheck[valveNr].valveStateTimer += cycT;
  else if ( *(valveStateCheck[valveNr].pOutputValve) != *(valveStateCheck[valveNr].pInputValveState) )
    {
     switch (valveNr)
     {
      case 0: VisuInterface.irrigationAlarm[IRRIGATION_NO_ENDPOS_VALVE_1] = 1; break;
      case 1: VisuInterface.irrigationAlarm[IRRIGATION_NO_ENDPOS_VALVE_2] = 1; break;
      case 2: VisuInterface.irrigationAlarm[IRRIGATION_NO_ENDPOS_VALVE_3] = 1; break;
      case 3: VisuInterface.irrigationAlarm[IRRIGATION_NO_ENDPOS_VALVE_4] = 1; break;
      case 4: VisuInterface.irrigationAlarm[IRRIGATION_NO_ENDPOS_VALVE_5] = 1; break;
      case 5: VisuInterface.irrigationAlarm[IRRIGATION_NO_ENDPOS_VALVE_6] = 1; break;
      case 6: VisuInterface.irrigationAlarm[IRRIGATION_NO_ENDPOS_VALVE_7] = 1; break;
     }
    }
  else if ( *(valveStateCheck[valveNr].pOutputValve) == *(valveStateCheck[valveNr].pInputValveState) )
    {
     switch (valveNr)
     {
      case 0: VisuInterface.irrigationAlarm[IRRIGATION_NO_ENDPOS_VALVE_1] = 0; break;
      case 1: VisuInterface.irrigationAlarm[IRRIGATION_NO_ENDPOS_VALVE_2] = 0; break;
      case 2: VisuInterface.irrigationAlarm[IRRIGATION_NO_ENDPOS_VALVE_3] = 0; break;
      case 3: VisuInterface.irrigationAlarm[IRRIGATION_NO_ENDPOS_VALVE_4] = 0; break;
      case 4: VisuInterface.irrigationAlarm[IRRIGATION_NO_ENDPOS_VALVE_5] = 0; break;
      case 5: VisuInterface.irrigationAlarm[IRRIGATION_NO_ENDPOS_VALVE_6] = 0; break;
      case 6: VisuInterface.irrigationAlarm[IRRIGATION_NO_ENDPOS_VALVE_7] = 0; break;
     }
    }
 }
 /* valve check /End */




 /***********************************************************************************************************************/
 /*** SAVE DATA                                                                                                       ***/
 /***********************************************************************************************************************/
 /* save segment status if user did some changes but only every minute /Begin */
 if ( (VisuInterface.ipSegmentInputCompletion == 1) && (newMinute) )
   {
    fDatObjWriteSegInf.enable  = 1;
    fDatObjWriteSegInf.ident   = dataObjSegment.doIdent;
    fDatObjWriteSegInf.Offset  = 0;
    fDatObjWriteSegInf.pSource = (UDINT)&irrigationSegments[0];
    fDatObjWriteSegInf.len     = sizeof(irrigationSegments);
    
    DatObjWrite(&fDatObjWriteSegInf);
    
    if (fDatObjWriteSegInf.status != ERR_OK)
      {
       dataObjSegment.nbWrErr++;
       dataObjSegment.lstWrErr = fDatObjWriteSegInf.status;
       ERRxwarning(fDatObjWriteSegInf.status, 0, "write segment info");
      }

    VisuInterface.ipSegmentInputCompletion = 0;
   }
 /* save segment status every minute /End */


 /***********************************************************************************************************************/
 /*** VISU INTERFACE for irrigation plant:                                                                            ***/
 /***********************************************************************************************************************/

 /* handle automatic mode and manual override /Begin */
 for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++)
 {
  /* evaluate new force state given by user */
  applyUserInput( &VisuInterface.segmentModeSelect[segmentNr], 
                   MAX_SEGMENT_MODES, 
                   SEGMENT_MODE_AUTO,
                  &VisuInterface.segmentNewForceTimer[segmentNr], 
                   USER_INPUT_APPLY_DELAY, 
                  &VisuInterface.segmentNewForce[segmentNr], 
                  &irrigationSegments[segmentNr].force, 
                  &VisuInterface.ipSegmentInputCompletion,
                   cycT );
 } /* for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++) */   
 /* handle automatic mode and manual override /End */


 /* Alarming /Begin */
 VisuInterface.irrigationAlarm[IRRIGATION_LOW_WATER_PREASURE] = !iWaterPressure & (oRainWaterPump | oValveServiceWater) & (waterSourceInf.available != WATER_SOURCE_UNKNOWN);
 VisuInterface.messageAlarm[IRRIGATION_KITCHEN_GARDEN_DRY]    = ( (iHumKitchenGarden1 == 0) && (VisuInterface.irrigationAlarm[IRRIGATION_NO_CONNECTION_CANIO] == 0) );
 VisuInterface.messageAlarm[IRRIGATION_FLOWER_GARDEN_DRY]     = ( (iHumFlowerGarden1  == 0) && (VisuInterface.irrigationAlarm[IRRIGATION_NO_CONNECTION_CANIO] == 0) );
 /* Alarming /End */
 
 
 /* picture 20.1 - 20.2 /Begin */
 for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++)
 {
  /* generate new humidity sensor type, due to user input /Begin */
  if (VisuInterface.humiditySelect[segmentNr] == 1)
    {
     if (++irrigationSegments[segmentNr].useHumidity >= MAX_HUMIDITY_SENSORS)
       irrigationSegments[segmentNr].useHumidity = NO_HUMIDITY_CHECK;
     
     VisuInterface.humiditySelect[segmentNr] = 0;
     VisuInterface.ipSegmentInputCompletion  = 1;
    }
  /* generate new humidity sensor type, due to user input /End */


  /* generate new water source type, due to user input /Begin */
  if (VisuInterface.waterSourceSelect[segmentNr] == 1)
    {
     if (++irrigationSegments[segmentNr].waterSource >= MAX_WATER_SOURCES)
       irrigationSegments[segmentNr].waterSource = WATER_SOURCE_AUTO;
     
     VisuInterface.waterSourceSelect[segmentNr] = 0;
     VisuInterface.ipSegmentInputCompletion  = 1;
    }
  /* generate new water source type, due to user input /End */
 }
 /* picture 20.1 - 20.2 /End */
 
 
 /* picture 20.3 - 20.9 (sunday til monday) /Begin */
 if ( (VisuInterface.curPictNr >= PIC_20_3) && (VisuInterface.curPictNr <= PIC_20_9) )
   {
    visuDayOfWeek = VisuInterface.curPictNr - PIC_20_3;									/* get day of week for configuration */
    
    if (VisuInterface.curPictNr != oldPictNr)
      {
       memcpy(&VisuInterface.ipDaySchedule[visuDayOfWeek], &ipDaySchedule[visuDayOfWeek], sizeof(VisuInterface.ipDaySchedule[visuDayOfWeek]));
       VisuInterface.progressBarInf.index = 0;											/* progress bar is invisble */
      }

    /* animation - progress bar */
    if ( (VisuInterface.saveSchedule == 1) || (VisuInterface.saveAllSchedule == 1) )
      {
       VisuInterface.progressBarInf.index = 1;											/* start progress bar */
      }
    else if ( (VisuInterface.progressBarInf.index > 0) && 
              (VisuInterface.progressBarInf.index < VisuInterface.progressBarInf.nbElements - 1) ) 									/* start progress bar if save has been actived */
      {
       if (VisuInterface.progressBarInf.timer >= VisuInterface.progressBarInf.duration)
         {
          VisuInterface.progressBarInf.timer = 0;
          VisuInterface.progressBarInf.index++;											/* next bitmap to increas progress bar */
         }
       else
         {
          VisuInterface.progressBarInf.timer += cycT;
         }
      }

    if (VisuInterface.cancelSchedule == 1)
      {
       VisuInterface.cancelSchedule = 0;
       memcpy(&VisuInterface.ipDaySchedule[visuDayOfWeek], &ipDaySchedule[visuDayOfWeek], sizeof(VisuInterface.ipDaySchedule[visuDayOfWeek]));
      } 

    if ( (VisuInterface.saveSchedule == 1) || (VisuInterface.saveAllSchedule == 1) )
      {
       /* save schedule for sunday */
       memcpy( &ipDaySchedule[visuDayOfWeek], &VisuInterface.ipDaySchedule[visuDayOfWeek], sizeof(ipDaySchedule[visuDayOfWeek]) );
       
       /* apply sunday schedule to all days */
       if (VisuInterface.saveAllSchedule == 1)
         {
          memcpy( &ipDaySchedule[1], &ipDaySchedule[0], sizeof(ipDaySchedule[0]) );
          memcpy( &ipDaySchedule[2], &ipDaySchedule[0], sizeof(ipDaySchedule[0]) );
          memcpy( &ipDaySchedule[3], &ipDaySchedule[0], sizeof(ipDaySchedule[0]) );
          memcpy( &ipDaySchedule[4], &ipDaySchedule[0], sizeof(ipDaySchedule[0]) );
          memcpy( &ipDaySchedule[5], &ipDaySchedule[0], sizeof(ipDaySchedule[0]) );
          memcpy( &ipDaySchedule[6], &ipDaySchedule[0], sizeof(ipDaySchedule[0]) );
         }

       fDatObjWriteUserSchedule.enable  = 1;
       fDatObjWriteUserSchedule.ident   = dataObjUserSchedule.doIdent;
       fDatObjWriteUserSchedule.Offset  = 0;
       fDatObjWriteUserSchedule.pSource = (UDINT)&ipDaySchedule[0];
       fDatObjWriteUserSchedule.len     = sizeof(ipDaySchedule);				/* save always complete schedule */
    
       DatObjWrite(&fDatObjWriteUserSchedule);
      
       if (fDatObjWriteUserSchedule.status != ERR_OK)
         {
          ERRxwarning(fDatObjWriteUserSchedule.status, 0, "write user schedule info");

          fDatObjCreate.enable   = 1;
          fDatObjCreate.pName    = (UDINT)IP_SCHEDULE_USER_DO_NAME;
          fDatObjCreate.len      = sizeof(ipDaySchedule);

          fDatObjCreate.MemType  = doUSRROM;
          fDatObjCreate.Option   = 0;
          fDatObjCreate.pCpyData = (UDINT)&ipDaySchedule[0];
    
          DatObjCreate(&fDatObjCreate);

          if (fDatObjCreate.status == ERR_OK)
            { 
             dataObjUserSchedule.pData     = fDatObjCreate.pDatObjMem;				/* pointer to segment information */
             dataObjUserSchedule.doIdent   = fDatObjCreate.ident;					/* ident of data object containing schedule */
             dataObjUserSchedule.doLength  = fDatObjCreate.len;						/* length of data in data object */
             dataObjUserSchedule.doMemType = fDatObjCreate.MemType;					/* memory of data object containing schedule */
             dataObjUserSchedule.doOption  = fDatObjCreate.Option;					/* additional options of data object containing schedule */
            
             VisuInterface.saveSchedule    = 0;
             VisuInterface.saveAllSchedule = 0;
            }
          else if (fDatObjCreate.status != ERR_FUB_BUSY)
            ERRxwarning(fDatObjWriteUserSchedule.status, 0, "create user schedule info");
         }
       else if (fDatObjWriteUserSchedule.status == ERR_OK)
         {
          VisuInterface.saveSchedule      = 0;
          VisuInterface.saveAllSchedule   = 0;
         } /* if ( (fDatObjWriteUserSchedule.status == doERR_ILLOBJECT) ... */
      } /* if ( (VisuInterface.saveSchedule == 1) || (VisuInterface.saveAllSchedule == 1) */
   } /* if ( (VisuInterface.curPictNr >= PIC_20_3) && (VisuInterface.curPictNr <= PIC_20_9) ) */
 /* picture 20.3 - 20.9 (sunday til monday) /End */



 /***********************************************************************************************************************/
 /*** CX408 LIFE GUARDING : Read Operating System Version                                                             ***/
 /***********************************************************************************************************************/
 /* cyclic check and configuration */
 if (newMinute) 
   cmdStartCX408lifeGuarding = 1;

 switch(sCX408lifeGuarding)
 {
  case sWAIT_START_LIFE_GUARDING:
    if (cmdStartCX408lifeGuarding == 1)
      sCX408lifeGuarding = sREAD_OS_VERSION;
  break;
  
  case sREAD_OS_VERSION:
    cmdBuffer[0] = 0;															/* free number in range 0-126 */
    cmdBuffer[1] = CANIO_READ_OS_VERSION;										/* 16 ...read operation system version */
    cmdBuffer[2] = 0;															/*  0 ...not used */
    cmdBuffer[3] = 0;															/*  0 ...not used */    

    cmdBuffer[4] = 0;															/*  0 ...not used */
    cmdBuffer[5] = 0;															/*  0 ...not used */
    cmdBuffer[6] = 0;															/*  0 ...not used */
    cmdBuffer[7] = 0;															/*  0 ...not used */

    fCANIOcmd.enable = 1;
    fCANIOcmd.busnr  = IRRIGATION_CX408_BUS_NUMBER;
    fCANIOcmd.nodenr = IRRIGATION_CX408_NODE_NUMBER;
    fCANIOcmd.cmd    = (UDINT)&cmdBuffer[0];
    fCANIOcmd.res    = (UDINT)&resBuffer[0];

    CANIOcmd(&fCANIOcmd);
    
    if (fCANIOcmd.status != ERR_FUB_BUSY)										/* all done,... */
      {
       /* if node is not responding or not (yet) active try again */
       if ( (fCANIOcmd.status == 8985) || (fCANIOcmd.status == 8979) )
         {
          VisuInterface.irrigationAlarm[IRRIGATION_NO_CONNECTION_CANIO] = 1;
         }
       else
         {
          VisuInterface.irrigationAlarm[IRRIGATION_NO_CONNECTION_CANIO] = 0;
         }
       
       cmdStartCX408lifeGuarding = 0;											/* automatic retry every minute */
       sCX408lifeGuarding = sWAIT_START_LIFE_GUARDING;
      }
  break;
 }

   
  oldPictNr = VisuInterface.curPictNr;
}
