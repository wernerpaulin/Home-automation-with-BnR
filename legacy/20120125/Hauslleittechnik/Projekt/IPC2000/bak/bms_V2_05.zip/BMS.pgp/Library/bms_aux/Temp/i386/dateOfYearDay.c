#include	<bur\plc.h>

void dateOfYearDay(void) {};
