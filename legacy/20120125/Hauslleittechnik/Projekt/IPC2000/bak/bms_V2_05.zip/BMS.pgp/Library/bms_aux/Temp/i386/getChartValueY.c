#include	<bur\plc.h>

void getChartValueY(void) {};
