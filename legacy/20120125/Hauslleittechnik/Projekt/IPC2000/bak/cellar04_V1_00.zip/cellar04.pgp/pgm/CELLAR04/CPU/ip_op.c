/*********************************************************************************************
*  Copyright: 2004 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Managment System - remote operation                                 *
*    Purpose    Irrigation Plant Operator                                                    *
*                                                                                            *
*    Filename   ip_op.c                                                                      *
*--------------------------------------------------------------------------------------------*
*  Description :                                                                             *
*    remote control of irrigation plant                                                      *
*                                                                                            *
*--------------------------------------------------------------------------------------------*
*  History :                                                                                 *
*  Version       Datum         Autor                                                         *
*  01.00         16.05.04      W. Paulin     Created                                         *
*********************************************************************************************/

#include <rem_op.h>

_LOCAL	UDINT			cycT;
_LOCAL	RTInfo_typ		fRTInfo;
_LOCAL	DTGetTime_typ	fDTgetTime;

_LOCAL	UINT			segmentNr;

_INIT void ip_opini()
{
	fRTInfo.enable = 1; 
	RTInfo(&fRTInfo);
	cycT = fRTInfo.cycle_time / 1000;					/* convert cycle time us -> ms */
	
	for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++)
	{
		gBmsCommData.segment[segmentNr].modeSelect          = 0;		
		gBmsCommData.segment[segmentNr].modeSelectOld       = 0;
		gBmsCommData.segment[segmentNr].modeInputTimer      = 0;
		
		gBmsCommData.segment[segmentNr].newMode             = 0;
		gBmsCommData.segment[segmentNr].modeInputCompletion = 0;
	}	/* for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++) */

	gBmsCommData.irrigOutputEnablePasswort = 0;			/* lock panel until connection to BMS has been established */
}	/* _INIT void ip_opini() */


_CYCLIC void ip_opcyc()
{
	/* get current time */
	fDTgetTime.enable = 1;
	DTGetTime(&fDTgetTime);
	if (fDTgetTime.status == 0)
	{
		DT_TO_DTStructure(fDTgetTime.DT1, (UDINT)&CurrentTime);
	}

	/* check whether irrigation control is allowed or not */
	if (gBmsCommData.irrigOutputEnablePasswort != IRRIGATION_OUTPUT_ENABLE_PASSWORT)
	{
		strcpy(&gVisuInterface.welcomeText[0], "* G E S P E R R T *");
	
		if ( (gVisuInterface.actPic != OP_PIC_FRONT_PAGE) && (gVisuInterface.setPic != OP_PIC_FRONT_PAGE) )
		{
			gVisuInterface.setPic = OP_PIC_FRONT_PAGE;
		}
		return;
	}
	
	/* set welcome text */
	if ( (CurrentTime.hour >= 4) && (CurrentTime.hour <= 9) )
	{
		strcpy( &gVisuInterface.welcomeText[0], "Guten Morgen Mutti!" );
	}
	else
	{
		memset( &gVisuInterface.welcomeText[0], 0, sizeof(gVisuInterface.welcomeText) );
	} 

	
	/********************************* SEGMENT CONTROL /Begin *********************************/
	for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++)
	{
		if (gBmsCommData.segment[segmentNr].modeSelect >= MAX_SEGMENT_MODES)
		{
			gBmsCommData.segment[segmentNr].modeSelect = 0;	/* ring selection */		
		}
		
		/* reset timer as long as mode is changing */
		if (gBmsCommData.segment[segmentNr].modeSelectOld != gBmsCommData.segment[segmentNr].modeSelect)
		{
			gBmsCommData.segment[segmentNr].modeSelectOld  = gBmsCommData.segment[segmentNr].modeSelect;
			gBmsCommData.segment[segmentNr].modeInputTimer = 0;
			gBmsCommData.segment[segmentNr].newMode        = 0;
		}
		
		/* indicate new valid user input if mode was not changed anymore within certain time */
		gBmsCommData.segment[segmentNr].modeInputTimer += cycT;
		if ( (gBmsCommData.segment[segmentNr].modeInputTimer >= 2*USER_INPUT_APPLY_DELAY) && 
		     (gBmsCommData.segment[segmentNr].modeInputCompletion == 1) )			/* avoid continous writing - only if new input was made */
		{
			gBmsCommData.segment[segmentNr].newMode             = 1;
			gBmsCommData.segment[segmentNr].modeInputCompletion = 0;
		}
	}	/* for (segmentNr = 0; segmentNr < NB_SEGMENTS; segmentNr++) */
	/********************************** SEGMENT CONTROL /End **********************************/
}	/* _CYCLIC void ip_opcyc() */