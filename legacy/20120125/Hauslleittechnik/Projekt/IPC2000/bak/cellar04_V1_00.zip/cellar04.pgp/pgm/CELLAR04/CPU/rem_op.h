/*********************************************************************************************
*  Copyright: 2004 by Paulin Werner                                                          *
*--------------------------------------------------------------------------------------------*
*  Identification:                                                                           *
*    System     Building Managment System - remote operation                                 *
*    Purpose    general include file                                                         *
*                                                                                            *
*    Filename   rem_op.h                                                                     *
*********************************************************************************************/

#ifndef _REM_OP_H_
#define _REM_OP_H_

#include <bur/plctypes.h>
#include <astime.h>
#include <sys_lib.h>
#include <brsystem.h>
#include <bms_gn.h>

/* defines */
enum OP_PIC_NUMBERS
{
	OP_PIC_FRONT_PAGE = 0,
};

/* datatypes */
typedef struct segmentCommData_typ
{
	USINT       name[32];
	USINT       modeSelect;
	USINT       modeSelectOld;
	USINT       newMode;
	USINT		modeInputCompletion;
	UINT		modeInputTimer;
	USINT       state;
}	segmentCommData_typ;

typedef struct bmsCommData_typ
{
	segmentCommData_typ	segment[NB_SEGMENTS];
	USINT				rainWaterPumpState;
	USINT				waterPressure;
	USINT				irrigOutputEnablePasswort;
	REAL  				outsideTemp;
	USINT				humidityKitchenGarden;
	USINT				humidityFlowerGarden;
}	bmsCommData_typ;

typedef struct visuInterface_typ
{
	UINT	setPic;
	UINT	actPic;
	USINT	welcomeText[32];
}	visuInterface_typ;




/* globals */
_GLOBAL	bmsCommData_typ		gBmsCommData;

#if __mc68000__
_GLOBAL	visuInterface_typ	gVisuInterface;
_GLOBAL DTStructure         CurrentTime;
#endif

#endif